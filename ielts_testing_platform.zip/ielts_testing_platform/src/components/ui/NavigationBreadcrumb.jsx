import React, { useMemo } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const NavigationBreadcrumb = ({ customBreadcrumbs = null }) => {
  const location = useLocation();
  const navigate = useNavigate();

  const testingPaths = [
    '/listening-test-interface',
    '/reading-test-interface', 
    '/writing-test-interface',
    '/speaking-test-interface'
  ];

  const isTestingContext = testingPaths.includes(location.pathname);

  const routeConfig = {
    '/test-results-dashboard': {
      label: 'Dashboard',
      icon: 'BarChart3',
      parent: null
    },
    '/listening-test-interface': {
      label: 'Listening Test',
      icon: 'Headphones',
      parent: '/test-results-dashboard'
    },
    '/reading-test-interface': {
      label: 'Reading Test',
      icon: 'BookOpen',
      parent: '/test-results-dashboard'
    },
    '/writing-test-interface': {
      label: 'Writing Test',
      icon: 'PenTool',
      parent: '/test-results-dashboard'
    },
    '/speaking-test-interface': {
      label: 'Speaking Test',
      icon: 'Mic',
      parent: '/test-results-dashboard'
    },
    '/user-profile-settings': {
      label: 'Profile Settings',
      icon: 'User',
      parent: '/test-results-dashboard'
    }
  };

  const breadcrumbs = useMemo(() => {
    if (customBreadcrumbs) {
      return customBreadcrumbs;
    }

    const currentPath = location.pathname;
    const currentRoute = routeConfig[currentPath];
    
    if (!currentRoute) {
      return [{ label: 'Dashboard', path: '/test-results-dashboard', icon: 'BarChart3' }];
    }

    const crumbs = [];
    let current = currentRoute;
    let currentPathKey = currentPath;

    while (current) {
      crumbs.unshift({
        label: current.label,
        path: currentPathKey,
        icon: current.icon,
        isActive: currentPathKey === currentPath
      });

      if (current.parent) {
        currentPathKey = current.parent;
        current = routeConfig[current.parent];
      } else {
        break;
      }
    }

    return crumbs;
  }, [location.pathname, customBreadcrumbs]);

  const handleNavigation = (path) => {
    navigate(path);
  };

  const handleBack = () => {
    if (breadcrumbs.length > 1) {
      const parentCrumb = breadcrumbs[breadcrumbs.length - 2];
      navigate(parentCrumb.path);
    } else {
      navigate('/test-results-dashboard');
    }
  };

  // Don't show breadcrumbs in testing context
  if (isTestingContext) {
    return null;
  }

  return (
    <nav className="flex items-center space-x-2 py-3" aria-label="Breadcrumb">
      {/* Back Button */}
      {breadcrumbs.length > 1 && (
        <Button
          variant="ghost"
          size="sm"
          iconName="ArrowLeft"
          onClick={handleBack}
          className="mr-2"
          aria-label="Go back"
        />
      )}

      {/* Desktop Breadcrumbs */}
      <div className="hidden sm:flex items-center space-x-2">
        {breadcrumbs.map((crumb, index) => (
          <React.Fragment key={crumb.path}>
            {index > 0 && (
              <Icon 
                name="ChevronRight" 
                size={16} 
                className="text-text-muted" 
              />
            )}
            
            <button
              onClick={() => !crumb.isActive && handleNavigation(crumb.path)}
              disabled={crumb.isActive}
              className={`flex items-center space-x-2 px-2 py-1 rounded-md text-sm transition-colors focus-ring ${
                crumb.isActive
                  ? 'text-text-primary font-medium cursor-default' :'text-text-secondary hover:text-text-primary hover:bg-surface'
              }`}
              aria-current={crumb.isActive ? 'page' : undefined}
            >
              <Icon name={crumb.icon} size={16} />
              <span>{crumb.label}</span>
            </button>
          </React.Fragment>
        ))}
      </div>

      {/* Mobile Breadcrumbs */}
      <div className="sm:hidden flex items-center space-x-2 w-full">
        {breadcrumbs.length > 1 && (
          <>
            <button
              onClick={() => handleNavigation(breadcrumbs[0].path)}
              className="flex items-center space-x-1 text-text-secondary hover:text-text-primary text-sm focus-ring px-1 py-1 rounded"
            >
              <Icon name={breadcrumbs[0].icon} size={14} />
              <span className="truncate max-w-20">{breadcrumbs[0].label}</span>
            </button>
            
            <Icon name="ChevronRight" size={14} className="text-text-muted flex-shrink-0" />
            
            {breadcrumbs.length > 2 && (
              <>
                <button
                  onClick={() => {}}
                  className="text-text-muted text-sm px-1"
                  disabled
                >
                  ...
                </button>
                <Icon name="ChevronRight" size={14} className="text-text-muted flex-shrink-0" />
              </>
            )}
          </>
        )}
        
        <div className="flex items-center space-x-2 text-text-primary font-medium text-sm">
          <Icon name={breadcrumbs[breadcrumbs.length - 1].icon} size={16} />
          <span className="truncate">{breadcrumbs[breadcrumbs.length - 1].label}</span>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="ml-auto flex items-center space-x-1">
        {location.pathname === '/test-results-dashboard' && (
          <Button
            variant="primary"
            size="sm"
            iconName="Play"
            onClick={() => handleNavigation('/listening-test-interface')}
            className="hidden sm:flex"
          >
            Start Test
          </Button>
        )}
        
        {location.pathname === '/user-profile-settings' && (
          <Button
            variant="outline"
            size="sm"
            iconName="Save"
            onClick={() => {}}
            className="hidden sm:flex"
          >
            Save Changes
          </Button>
        )}
      </div>
    </nav>
  );
};

export default NavigationBreadcrumb;