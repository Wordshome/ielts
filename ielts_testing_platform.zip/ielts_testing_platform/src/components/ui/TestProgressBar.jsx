import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import Icon from '../AppIcon';

const TestProgressBar = ({ 
  currentSection = 0, 
  totalSections = 4, 
  sectionProgress = 0,
  onSectionChange,
  timeRemaining = 0,
  totalTime = 0
}) => {
  const location = useLocation();
  const [isVisible, setIsVisible] = useState(false);

  const testingPaths = [
    '/listening-test-interface',
    '/reading-test-interface', 
    '/writing-test-interface',
    '/speaking-test-interface'
  ];

  const testSections = [
    { name: 'Listening', icon: 'Headphones', path: '/listening-test-interface' },
    { name: 'Reading', icon: 'BookOpen', path: '/reading-test-interface' },
    { name: 'Writing', icon: 'PenTool', path: '/writing-test-interface' },
    { name: 'Speaking', icon: 'Mic', path: '/speaking-test-interface' }
  ];

  useEffect(() => {
    setIsVisible(testingPaths.includes(location.pathname));
  }, [location.pathname]);

  const getCurrentSectionIndex = () => {
    return testingPaths.findIndex(path => path === location.pathname);
  };

  const getProgressColor = () => {
    const progressPercent = (sectionProgress / 100) * 100;
    if (progressPercent >= 80) return 'bg-success-500';
    if (progressPercent >= 60) return 'bg-primary-500';
    if (progressPercent >= 40) return 'bg-accent-500';
    if (progressPercent >= 20) return 'bg-warning-500';
    return 'bg-error-500';
  };

  const getTimeColor = () => {
    if (!totalTime) return 'text-text-secondary';
    const timePercent = (timeRemaining / totalTime) * 100;
    if (timePercent > 50) return 'text-success-600';
    if (timePercent > 25) return 'text-warning-600';
    return 'text-error-600';
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSectionClick = (index) => {
    if (onSectionChange && index <= currentSection) {
      onSectionChange(index);
    }
  };

  if (!isVisible) return null;

  const activeIndex = getCurrentSectionIndex();

  return (
    <div className="bg-background border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="py-3">
          {/* Desktop Progress Bar */}
          <div className="hidden md:block">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-6">
                {testSections.map((section, index) => {
                  const isActive = index === activeIndex;
                  const isCompleted = index < activeIndex;
                  const isAccessible = index <= currentSection;
                  
                  return (
                    <button
                      key={section.name}
                      onClick={() => handleSectionClick(index)}
                      disabled={!isAccessible}
                      className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-all duration-150 focus-ring ${
                        isActive 
                          ? 'bg-primary-50 text-primary-600 border border-primary-200' 
                          : isCompleted
                          ? 'bg-success-50 text-success-600 border border-success-200 hover:bg-success-100'
                          : isAccessible
                          ? 'text-text-secondary hover:bg-surface border border-transparent' :'text-text-muted cursor-not-allowed border border-transparent'
                      }`}
                    >
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                        isActive 
                          ? 'bg-primary-500 text-white' 
                          : isCompleted
                          ? 'bg-success-500 text-white'
                          : isAccessible
                          ? 'bg-secondary-200 text-secondary-600' :'bg-secondary-100 text-secondary-400'
                      }`}>
                        {isCompleted ? (
                          <Icon name="Check" size={14} />
                        ) : (
                          <Icon name={section.icon} size={14} />
                        )}
                      </div>
                      <span className="text-sm font-medium">{section.name}</span>
                    </button>
                  );
                })}
              </div>
              
              {timeRemaining > 0 && (
                <div className={`flex items-center space-x-2 text-sm font-data ${getTimeColor()}`}>
                  <Icon name="Clock" size={16} />
                  <span>{formatTime(timeRemaining)}</span>
                </div>
              )}
            </div>
            
            {/* Section Progress Bar */}
            <div className="w-full bg-secondary-100 rounded-full h-2">
              <div 
                className={`h-2 rounded-full progress-bar ${getProgressColor()}`}
                style={{ width: `${sectionProgress}%` }}
              />
            </div>
          </div>

          {/* Mobile Progress Bar */}
          <div className="md:hidden">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  activeIndex >= 0 ? 'bg-primary-500 text-white' : 'bg-secondary-200 text-secondary-600'
                }`}>
                  <Icon name={testSections[Math.max(0, activeIndex)]?.icon || 'Play'} size={16} />
                </div>
                <div>
                  <div className="text-sm font-medium text-text-primary">
                    {testSections[Math.max(0, activeIndex)]?.name || 'Test'}
                  </div>
                  <div className="text-xs text-text-secondary">
                    Section {Math.max(1, activeIndex + 1)} of {totalSections}
                  </div>
                </div>
              </div>
              
              {timeRemaining > 0 && (
                <div className={`text-sm font-data ${getTimeColor()}`}>
                  {formatTime(timeRemaining)}
                </div>
              )}
            </div>
            
            {/* Mobile Section Progress */}
            <div className="flex items-center space-x-2 mb-2">
              {testSections.map((_, index) => (
                <div
                  key={index}
                  className={`flex-1 h-1 rounded-full ${
                    index < activeIndex 
                      ? 'bg-success-500' 
                      : index === activeIndex 
                      ? 'bg-primary-500' :'bg-secondary-200'
                  }`}
                />
              ))}
            </div>
            
            {/* Current Section Progress */}
            <div className="w-full bg-secondary-100 rounded-full h-2">
              <div 
                className={`h-2 rounded-full progress-bar ${getProgressColor()}`}
                style={{ width: `${sectionProgress}%` }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TestProgressBar;