import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const AdaptiveHeader = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isTestingContext, setIsTestingContext] = useState(false);

  const testingPaths = [
    '/listening-test-interface',
    '/reading-test-interface', 
    '/writing-test-interface',
    '/speaking-test-interface'
  ];

  useEffect(() => {
    setIsTestingContext(testingPaths.includes(location.pathname));
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  const navigationItems = [
    {
      label: 'Dashboard',
      path: '/test-results-dashboard',
      icon: 'BarChart3',
      showInTesting: false
    },
    {
      label: 'Take Test',
      path: '/listening-test-interface',
      icon: 'Play',
      showInTesting: true,
      subItems: [
        { label: 'Listening', path: '/listening-test-interface', icon: 'Headphones' },
        { label: 'Reading', path: '/reading-test-interface', icon: 'BookOpen' },
        { label: 'Writing', path: '/writing-test-interface', icon: 'PenTool' },
        { label: 'Speaking', path: '/speaking-test-interface', icon: 'Mic' }
      ]
    },
    {
      label: 'Results',
      path: '/test-results-dashboard',
      icon: 'TrendingUp',
      showInTesting: false
    },
    {
      label: 'Profile',
      path: '/user-profile-settings',
      icon: 'User',
      showInTesting: false
    }
  ];

  const handleNavigation = (path) => {
    navigate(path);
    setIsMobileMenuOpen(false);
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const Logo = () => (
    <div 
      className="flex items-center space-x-3 cursor-pointer focus-ring rounded-lg p-2 -m-2"
      onClick={() => handleNavigation('/test-results-dashboard')}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          handleNavigation('/test-results-dashboard');
        }
      }}
    >
      <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
        <Icon name="GraduationCap" size={20} color="white" />
      </div>
      <div className="flex flex-col">
        <span className="text-lg font-semibold text-text-primary font-heading">
          IELTS
        </span>
        <span className="text-xs text-text-secondary font-caption -mt-1">
          Testing Platform
        </span>
      </div>
    </div>
  );

  const getCurrentTestSection = () => {
    const currentPath = location.pathname;
    const testSection = navigationItems
      .find(item => item.subItems)
      ?.subItems?.find(sub => sub.path === currentPath);
    return testSection?.label || 'Test';
  };

  if (isTestingContext) {
    return (
      <header className="fixed top-0 left-0 right-0 z-1000 nav-testing border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-14 sm:h-16">
            <Logo />
            
            <div className="flex items-center space-x-4">
              <div className="hidden sm:flex items-center space-x-2 text-sm text-text-secondary">
                <Icon name="Clock" size={16} />
                <span className="font-data">Current Section: {getCurrentTestSection()}</span>
              </div>
              
              <Button
                variant="ghost"
                size="sm"
                iconName="Menu"
                onClick={toggleMobileMenu}
                className="sm:hidden"
                aria-label="Toggle menu"
              />
            </div>
          </div>
        </div>

        {isMobileMenuOpen && (
          <div className="sm:hidden bg-background border-t border-border animate-fade-in">
            <div className="px-4 py-3 space-y-2">
              <div className="text-sm text-text-secondary mb-3">
                <Icon name="Clock" size={16} className="inline mr-2" />
                Current: {getCurrentTestSection()}
              </div>
              <Button
                variant="ghost"
                size="sm"
                iconName="Pause"
                fullWidth
                onClick={() => {}}
                className="justify-start"
              >
                Pause Test
              </Button>
              <Button
                variant="outline"
                size="sm"
                iconName="Home"
                fullWidth
                onClick={() => handleNavigation('/test-results-dashboard')}
                className="justify-start"
              >
                Exit to Dashboard
              </Button>
            </div>
          </div>
        )}
      </header>
    );
  }

  return (
    <header className="sticky top-0 z-1000 nav-management">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Logo />

          <nav className="hidden md:flex items-center space-x-1">
            {navigationItems.map((item) => {
              const isActive = location.pathname === item.path || 
                (item.subItems && item.subItems.some(sub => sub.path === location.pathname));
              
              return (
                <div key={item.path} className="relative group">
                  <Button
                    variant={isActive ? "primary" : "ghost"}
                    size="sm"
                    iconName={item.icon}
                    iconPosition="left"
                    onClick={() => handleNavigation(item.path)}
                    className="px-3 py-2"
                  >
                    {item.label}
                  </Button>
                  
                  {item.subItems && (
                    <div className="absolute top-full left-0 mt-1 w-48 bg-background border border-border rounded-lg shadow-custom-md opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-1100">
                      <div className="py-2">
                        {item.subItems.map((subItem) => (
                          <button
                            key={subItem.path}
                            onClick={() => handleNavigation(subItem.path)}
                            className="w-full px-4 py-2 text-left text-sm text-text-primary hover:bg-surface flex items-center space-x-3 focus-ring"
                          >
                            <Icon name={subItem.icon} size={16} />
                            <span>{subItem.label}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </nav>

          <div className="flex items-center space-x-3">
            <Button
              variant="outline"
              size="sm"
              iconName="Bell"
              className="hidden sm:flex"
              onClick={() => {}}
              aria-label="Notifications"
            />
            
            <Button
              variant="ghost"
              size="sm"
              iconName="Menu"
              onClick={toggleMobileMenu}
              className="md:hidden"
              aria-label="Toggle menu"
            />
          </div>
        </div>
      </div>

      {isMobileMenuOpen && (
        <div className="md:hidden bg-background border-t border-border animate-fade-in">
          <div className="px-4 py-3 space-y-1">
            {navigationItems.map((item) => {
              const isActive = location.pathname === item.path ||
                (item.subItems && item.subItems.some(sub => sub.path === location.pathname));
              
              return (
                <div key={item.path}>
                  <Button
                    variant={isActive ? "primary" : "ghost"}
                    size="sm"
                    iconName={item.icon}
                    iconPosition="left"
                    fullWidth
                    onClick={() => handleNavigation(item.path)}
                    className="justify-start mb-1"
                  >
                    {item.label}
                  </Button>
                  
                  {item.subItems && isActive && (
                    <div className="ml-4 space-y-1">
                      {item.subItems.map((subItem) => (
                        <Button
                          key={subItem.path}
                          variant={location.pathname === subItem.path ? "secondary" : "ghost"}
                          size="xs"
                          iconName={subItem.icon}
                          iconPosition="left"
                          fullWidth
                          onClick={() => handleNavigation(subItem.path)}
                          className="justify-start"
                        >
                          {subItem.label}
                        </Button>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </header>
  );
};

export default AdaptiveHeader;