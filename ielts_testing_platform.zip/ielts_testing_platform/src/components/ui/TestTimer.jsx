import React, { useState, useEffect, useCallback } from 'react';
import { useLocation } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const TestTimer = ({ 
  initialTime = 3600, // 60 minutes default
  onTimeUp,
  onTimeWarning,
  warningThreshold = 300, // 5 minutes
  criticalThreshold = 60, // 1 minute
  autoStart = true,
  showControls = true,
  sectionName = ''
}) => {
  const location = useLocation();
  const [timeRemaining, setTimeRemaining] = useState(initialTime);
  const [isRunning, setIsRunning] = useState(autoStart);
  const [isPaused, setIsPaused] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const [hasWarned, setHasWarned] = useState(false);
  const [hasCriticalWarned, setHasCriticalWarned] = useState(false);

  const testingPaths = [
    '/listening-test-interface',
    '/reading-test-interface', 
    '/writing-test-interface',
    '/speaking-test-interface'
  ];

  useEffect(() => {
    setIsVisible(testingPaths.includes(location.pathname));
  }, [location.pathname]);

  useEffect(() => {
    setTimeRemaining(initialTime);
    setHasWarned(false);
    setHasCriticalWarned(false);
  }, [initialTime]);

  const getTimerColor = useCallback(() => {
    const percentage = (timeRemaining / initialTime) * 100;
    if (percentage <= (criticalThreshold / initialTime) * 100) return 'text-error-600';
    if (percentage <= (warningThreshold / initialTime) * 100) return 'text-warning-600';
    return 'text-success-600';
  }, [timeRemaining, initialTime, criticalThreshold, warningThreshold]);

  const getProgressColor = useCallback(() => {
    const percentage = (timeRemaining / initialTime) * 100;
    if (percentage <= (criticalThreshold / initialTime) * 100) return 'bg-error-500';
    if (percentage <= (warningThreshold / initialTime) * 100) return 'bg-warning-500';
    return 'bg-primary-500';
  }, [timeRemaining, initialTime, criticalThreshold, warningThreshold]);

  const formatTime = useCallback((seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }, []);

  useEffect(() => {
    let interval;
    
    if (isRunning && !isPaused && timeRemaining > 0) {
      interval = setInterval(() => {
        setTimeRemaining(prev => {
          const newTime = prev - 1;
          
          // Warning notifications
          if (newTime === warningThreshold && !hasWarned) {
            setHasWarned(true);
            onTimeWarning?.(newTime);
          }
          
          if (newTime === criticalThreshold && !hasCriticalWarned) {
            setHasCriticalWarned(true);
            onTimeWarning?.(newTime);
          }
          
          // Time up
          if (newTime <= 0) {
            setIsRunning(false);
            onTimeUp?.();
            return 0;
          }
          
          return newTime;
        });
      }, 1000);
    }
    
    return () => clearInterval(interval);
  }, [isRunning, isPaused, timeRemaining, warningThreshold, criticalThreshold, hasWarned, hasCriticalWarned, onTimeUp, onTimeWarning]);

  const handlePlayPause = () => {
    if (isPaused) {
      setIsPaused(false);
    } else {
      setIsPaused(!isPaused);
    }
  };

  const handleStart = () => {
    setIsRunning(true);
    setIsPaused(false);
  };

  const handleStop = () => {
    setIsRunning(false);
    setIsPaused(false);
  };

  const handleReset = () => {
    setTimeRemaining(initialTime);
    setIsRunning(false);
    setIsPaused(false);
    setHasWarned(false);
    setHasCriticalWarned(false);
  };

  const getProgressPercentage = () => {
    return ((initialTime - timeRemaining) / initialTime) * 100;
  };

  if (!isVisible) return null;

  return (
    <div className="bg-background border border-border rounded-lg shadow-custom-sm">
      {/* Desktop Timer */}
      <div className="hidden md:block p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-3">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
              isRunning && !isPaused ? 'bg-primary-50 text-primary-600' : 'bg-secondary-100 text-secondary-600'
            }`}>
              <Icon name="Clock" size={20} />
            </div>
            <div>
              <div className="text-sm font-medium text-text-primary">
                {sectionName || 'Test Timer'}
              </div>
              <div className="text-xs text-text-secondary">
                {isRunning && !isPaused ? 'Running' : isPaused ? 'Paused' : 'Stopped'}
              </div>
            </div>
          </div>
          
          <div className={`text-2xl font-data font-semibold ${getTimerColor()}`}>
            {formatTime(timeRemaining)}
          </div>
        </div>
        
        {/* Progress Bar */}
        <div className="w-full bg-secondary-100 rounded-full h-2 mb-3">
          <div 
            className={`h-2 rounded-full transition-all duration-300 ${getProgressColor()}`}
            style={{ width: `${getProgressPercentage()}%` }}
          />
        </div>
        
        {/* Controls */}
        {showControls && (
          <div className="flex items-center justify-center space-x-2">
            {!isRunning ? (
              <Button
                variant="primary"
                size="sm"
                iconName="Play"
                onClick={handleStart}
              >
                Start
              </Button>
            ) : (
              <Button
                variant={isPaused ? "primary" : "secondary"}
                size="sm"
                iconName={isPaused ? "Play" : "Pause"}
                onClick={handlePlayPause}
              >
                {isPaused ? 'Resume' : 'Pause'}
              </Button>
            )}
            
            <Button
              variant="outline"
              size="sm"
              iconName="Square"
              onClick={handleStop}
              disabled={!isRunning && !isPaused}
            >
              Stop
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              iconName="RotateCcw"
              onClick={handleReset}
            >
              Reset
            </Button>
          </div>
        )}
      </div>

      {/* Mobile Timer */}
      <div className="md:hidden p-3">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center space-x-2">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
              isRunning && !isPaused ? 'bg-primary-50 text-primary-600' : 'bg-secondary-100 text-secondary-600'
            }`}>
              <Icon name="Clock" size={16} />
            </div>
            <div>
              <div className="text-sm font-medium text-text-primary">
                {sectionName || 'Timer'}
              </div>
            </div>
          </div>
          
          <div className={`text-lg font-data font-semibold ${getTimerColor()}`}>
            {formatTime(timeRemaining)}
          </div>
        </div>
        
        {/* Mobile Progress Bar */}
        <div className="w-full bg-secondary-100 rounded-full h-1.5 mb-3">
          <div 
            className={`h-1.5 rounded-full transition-all duration-300 ${getProgressColor()}`}
            style={{ width: `${getProgressPercentage()}%` }}
          />
        </div>
        
        {/* Mobile Controls */}
        {showControls && (
          <div className="flex items-center justify-center space-x-1">
            {!isRunning ? (
              <Button
                variant="primary"
                size="xs"
                iconName="Play"
                onClick={handleStart}
              >
                Start
              </Button>
            ) : (
              <Button
                variant={isPaused ? "primary" : "secondary"}
                size="xs"
                iconName={isPaused ? "Play" : "Pause"}
                onClick={handlePlayPause}
              >
                {isPaused ? 'Resume' : 'Pause'}
              </Button>
            )}
            
            <Button
              variant="outline"
              size="xs"
              iconName="Square"
              onClick={handleStop}
              disabled={!isRunning && !isPaused}
            />
            
            <Button
              variant="ghost"
              size="xs"
              iconName="RotateCcw"
              onClick={handleReset}
            />
          </div>
        )}
      </div>
    </div>
  );
};

export default TestTimer;