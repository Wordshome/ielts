import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const CertificateDownload = ({ testResult, userInfo }) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [downloadFormat, setDownloadFormat] = useState('pdf');

  const formatOptions = [
    { value: 'pdf', label: 'PDF Certificate', icon: 'FileText' },
    { value: 'png', label: 'PNG Image', icon: 'Image' },
    { value: 'jpg', label: 'JPG Image', icon: 'Image' }
  ];

  const handleDownload = async (format) => {
    setIsGenerating(true);
    
    // Simulate certificate generation
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // In a real application, this would generate and download the actual certificate
    const link = document.createElement('a');
    link.href = '#'; // Would be the actual certificate URL
    link.download = `IELTS_Certificate_${userInfo.name.replace(/\s+/g, '_')}_${testResult.testDate}.${format}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    setIsGenerating(false);
  };

  const isEligibleForCertificate = testResult.overallScore >= 4.0;

  return (
    <div className="bg-white rounded-lg border border-border p-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-success-50 rounded-lg flex items-center justify-center">
          <Icon name="Award" size={20} className="text-success-600" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-text-primary">Certificate Download</h3>
          <p className="text-sm text-text-secondary">Official IELTS test completion certificate</p>
        </div>
      </div>

      {isEligibleForCertificate ? (
        <div className="space-y-6">
          {/* Certificate Preview */}
          <div className="bg-gradient-to-br from-primary-50 to-accent-50 border-2 border-primary-200 rounded-lg p-6">
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-primary-600 rounded-full flex items-center justify-center mx-auto">
                <Icon name="Award" size={32} color="white" />
              </div>
              
              <div>
                <h4 className="text-xl font-bold text-text-primary mb-2">
                  Certificate of Completion
                </h4>
                <p className="text-sm text-text-secondary mb-4">
                  International English Language Testing System
                </p>
              </div>

              <div className="bg-white rounded-lg p-4 border border-primary-200">
                <p className="text-sm text-text-secondary mb-2">This certifies that</p>
                <p className="text-lg font-semibold text-text-primary mb-2">{userInfo.name}</p>
                <p className="text-sm text-text-secondary mb-3">
                  has successfully completed the IELTS examination on {testResult.testDate}
                </p>
                
                <div className="flex items-center justify-center space-x-6 text-sm">
                  <div className="text-center">
                    <p className="text-text-secondary">Overall Band Score</p>
                    <p className="text-2xl font-bold text-primary-600">{testResult.overallScore}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-text-secondary">Test Type</p>
                    <p className="font-semibold text-text-primary">{testResult.testType}</p>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-center space-x-4 text-xs text-text-secondary">
                <div className="flex items-center space-x-1">
                  <Icon name="Calendar" size={14} />
                  <span>Issued: {new Date().toLocaleDateString()}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Icon name="Shield" size={14} />
                  <span>Verified</span>
                </div>
              </div>
            </div>
          </div>

          {/* Format Selection */}
          <div>
            <h5 className="text-sm font-medium text-text-primary mb-3">Download Format</h5>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {formatOptions.map((option) => (
                <button
                  key={option.value}
                  onClick={() => setDownloadFormat(option.value)}
                  className={`flex items-center space-x-3 p-3 rounded-lg border transition-colors focus-ring ${
                    downloadFormat === option.value
                      ? 'border-primary-300 bg-primary-50 text-primary-700' :'border-border hover:bg-surface text-text-secondary'
                  }`}
                >
                  <Icon name={option.icon} size={20} />
                  <span className="text-sm font-medium">{option.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Download Actions */}
          <div className="flex flex-col sm:flex-row gap-3">
            <Button
              variant="primary"
              iconName="Download"
              iconPosition="left"
              onClick={() => handleDownload(downloadFormat)}
              loading={isGenerating}
              disabled={isGenerating}
              className="flex-1"
            >
              {isGenerating ? 'Generating Certificate...' : `Download ${downloadFormat.toUpperCase()}`}
            </Button>
            
            <Button
              variant="outline"
              iconName="Mail"
              iconPosition="left"
              onClick={() => {}}
              disabled={isGenerating}
              className="flex-1 sm:flex-none"
            >
              Email Certificate
            </Button>
            
            <Button
              variant="ghost"
              iconName="Share2"
              iconPosition="left"
              onClick={() => {}}
              disabled={isGenerating}
              className="flex-1 sm:flex-none"
            >
              Share
            </Button>
          </div>

          {/* Certificate Info */}
          <div className="bg-surface rounded-lg p-4">
            <div className="flex items-start space-x-3">
              <Icon name="Info" size={20} className="text-accent-600 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-text-secondary">
                <p className="font-medium text-text-primary mb-1">Certificate Information</p>
                <ul className="space-y-1 text-xs">
                  <li>• This certificate is valid for official documentation</li>
                  <li>• Certificate ID: {testResult.certificateId || 'IELTS-' + Date.now()}</li>
                  <li>• Verification available at our official website</li>
                  <li>• High-resolution format suitable for printing</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="text-center py-8">
          <div className="w-16 h-16 bg-error-50 rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name="AlertCircle" size={32} className="text-error-600" />
          </div>
          <h4 className="text-lg font-semibold text-text-primary mb-2">
            Certificate Not Available
          </h4>
          <p className="text-sm text-text-secondary mb-4">
            A minimum overall band score of 4.0 is required to generate an official certificate.
          </p>
          <p className="text-sm text-text-secondary">
            Current score: <span className="font-semibold">{testResult.overallScore}</span>
          </p>
          
          <div className="mt-6">
            <Button
              variant="primary"
              iconName="RotateCcw"
              iconPosition="left"
              onClick={() => {}}
            >
              Retake Test
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default CertificateDownload;