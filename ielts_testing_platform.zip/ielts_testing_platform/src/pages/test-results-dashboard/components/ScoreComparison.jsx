import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ScoreComparison = ({ currentScore, targetRequirements }) => {
  const [selectedTarget, setSelectedTarget] = useState('university');

  const comparisonTargets = {
    university: {
      label: 'University Admission',
      icon: 'GraduationCap',
      requirements: {
        overall: 6.5,
        listening: 6.0,
        reading: 6.0,
        writing: 6.0,
        speaking: 6.0
      },
      description: 'Typical requirements for undergraduate programs'
    },
    immigration: {
      label: 'Immigration (General)',
      icon: 'Plane',
      requirements: {
        overall: 6.0,
        listening: 6.0,
        reading: 6.0,
        writing: 6.0,
        speaking: 6.0
      },
      description: 'General immigration requirements'
    },
    professional: {
      label: 'Professional Registration',
      icon: 'Briefcase',
      requirements: {
        overall: 7.0,
        listening: 7.0,
        reading: 7.0,
        writing: 7.0,
        speaking: 7.0
      },
      description: 'Professional body registration requirements'
    },
    postgraduate: {
      label: 'Postgraduate Studies',
      icon: 'BookOpen',
      requirements: {
        overall: 7.0,
        listening: 6.5,
        reading: 6.5,
        writing: 6.5,
        speaking: 6.5
      },
      description: 'Master\'s and PhD program requirements'
    }
  };

  const getComparisonStatus = (current, required) => {
    const difference = current - required;
    if (difference >= 0.5) return { status: 'excellent', color: 'text-success-600', bg: 'bg-success-50', icon: 'CheckCircle2' };
    if (difference >= 0) return { status: 'good', color: 'text-success-600', bg: 'bg-success-50', icon: 'CheckCircle' };
    if (difference >= -0.5) return { status: 'close', color: 'text-warning-600', bg: 'bg-warning-50', icon: 'AlertCircle' };
    return { status: 'needs-improvement', color: 'text-error-600', bg: 'bg-error-50', icon: 'XCircle' };
  };

  const target = comparisonTargets[selectedTarget];
  const sections = ['overall', 'listening', 'reading', 'writing', 'speaking'];

  return (
    <div className="bg-white rounded-lg border border-border p-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-accent-50 rounded-lg flex items-center justify-center">
          <Icon name="Target" size={20} className="text-accent-600" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-text-primary">Score Comparison</h3>
          <p className="text-sm text-text-secondary">Compare your scores with target requirements</p>
        </div>
      </div>

      {/* Target Selection */}
      <div className="mb-6">
        <h4 className="text-sm font-medium text-text-primary mb-3">Select Target</h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {Object.entries(comparisonTargets).map(([key, targetOption]) => (
            <button
              key={key}
              onClick={() => setSelectedTarget(key)}
              className={`flex items-center space-x-2 p-3 rounded-lg border transition-colors focus-ring ${
                selectedTarget === key
                  ? 'border-primary-300 bg-primary-50 text-primary-700' :'border-border hover:bg-surface text-text-secondary'
              }`}
            >
              <Icon name={targetOption.icon} size={18} />
              <span className="text-sm font-medium">{targetOption.label}</span>
            </button>
          ))}
        </div>
        <p className="text-xs text-text-secondary mt-2">{target.description}</p>
      </div>

      {/* Comparison Table */}
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-border">
              <th className="text-left py-3 px-2 text-sm font-medium text-text-primary">Section</th>
              <th className="text-center py-3 px-2 text-sm font-medium text-text-primary">Your Score</th>
              <th className="text-center py-3 px-2 text-sm font-medium text-text-primary">Required</th>
              <th className="text-center py-3 px-2 text-sm font-medium text-text-primary">Difference</th>
              <th className="text-center py-3 px-2 text-sm font-medium text-text-primary">Status</th>
            </tr>
          </thead>
          <tbody>
            {sections.map((section) => {
              const current = currentScore[section];
              const required = target.requirements[section];
              const comparison = getComparisonStatus(current, required);
              const difference = current - required;

              return (
                <tr key={section} className="border-b border-border last:border-b-0">
                  <td className="py-3 px-2">
                    <span className="text-sm font-medium text-text-primary capitalize">{section}</span>
                  </td>
                  <td className="py-3 px-2 text-center">
                    <span className="text-sm font-semibold text-text-primary">{current.toFixed(1)}</span>
                  </td>
                  <td className="py-3 px-2 text-center">
                    <span className="text-sm text-text-secondary">{required.toFixed(1)}</span>
                  </td>
                  <td className="py-3 px-2 text-center">
                    <span className={`text-sm font-medium ${comparison.color}`}>
                      {difference >= 0 ? '+' : ''}{difference.toFixed(1)}
                    </span>
                  </td>
                  <td className="py-3 px-2 text-center">
                    <div className={`inline-flex items-center space-x-1 px-2 py-1 rounded-full ${comparison.bg}`}>
                      <Icon name={comparison.icon} size={14} className={comparison.color} />
                      <span className={`text-xs font-medium ${comparison.color} capitalize`}>
                        {comparison.status.replace('-', ' ')}
                      </span>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Summary */}
      <div className="mt-6 p-4 bg-surface rounded-lg">
        <div className="flex items-start space-x-3">
          <Icon name="Info" size={20} className="text-accent-600 mt-0.5 flex-shrink-0" />
          <div>
            <h5 className="text-sm font-medium text-text-primary mb-2">Summary</h5>
            {(() => {
              const meetRequirements = sections.every(section => 
                currentScore[section] >= target.requirements[section]
              );
              const sectionsNeedingImprovement = sections.filter(section => 
                currentScore[section] < target.requirements[section]
              );

              if (meetRequirements) {
                return (
                  <div className="text-sm text-success-700">
                    <p className="font-medium mb-1">✓ Congratulations! You meet all requirements for {target.label}.</p>
                    <p>Your scores exceed the minimum requirements across all sections.</p>
                  </div>
                );
              } else {
                return (
                  <div className="text-sm text-text-secondary">
                    <p className="font-medium mb-1 text-warning-700">
                      You need to improve {sectionsNeedingImprovement.length} section(s) to meet {target.label} requirements:
                    </p>
                    <ul className="space-y-1">
                      {sectionsNeedingImprovement.map(section => {
                        const needed = target.requirements[section] - currentScore[section];
                        return (
                          <li key={section} className="flex items-center space-x-2">
                            <span className="w-1.5 h-1.5 bg-warning-500 rounded-full" />
                            <span className="capitalize">{section}: improve by {needed.toFixed(1)} points</span>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                );
              }
            })()}
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-3 mt-6">
        <Button
          variant="primary"
          iconName="Target"
          iconPosition="left"
          onClick={() => {}}
          className="flex-1 sm:flex-none"
        >
          Set as Goal
        </Button>
        <Button
          variant="outline"
          iconName="BookOpen"
          iconPosition="left"
          onClick={() => {}}
          className="flex-1 sm:flex-none"
        >
          Study Plan
        </Button>
        <Button
          variant="ghost"
          iconName="RotateCcw"
          iconPosition="left"
          onClick={() => {}}
          className="flex-1 sm:flex-none"
        >
          Retake Test
        </Button>
      </div>
    </div>
  );
};

export default ScoreComparison;