import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const DetailedFeedback = ({ feedbackData }) => {
  const [expandedSections, setExpandedSections] = useState({});

  const toggleSection = (sectionId) => {
    setExpandedSections(prev => ({
      ...prev,
      [sectionId]: !prev[sectionId]
    }));
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'high': return 'text-error-600 bg-error-50 border-error-200';
      case 'medium': return 'text-warning-600 bg-warning-50 border-warning-200';
      case 'low': return 'text-success-600 bg-success-50 border-success-200';
      default: return 'text-text-secondary bg-secondary-50 border-secondary-200';
    }
  };

  const getSeverityIcon = (severity) => {
    switch (severity) {
      case 'high': return 'AlertTriangle';
      case 'medium': return 'AlertCircle';
      case 'low': return 'CheckCircle';
      default: return 'Info';
    }
  };

  return (
    <div className="bg-white rounded-lg border border-border p-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-accent-50 rounded-lg flex items-center justify-center">
          <Icon name="MessageSquare" size={20} className="text-accent-600" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-text-primary">Detailed Feedback</h3>
          <p className="text-sm text-text-secondary">Comprehensive analysis and recommendations</p>
        </div>
      </div>

      <div className="space-y-4">
        {feedbackData.map((section, index) => (
          <div key={index} className="border border-border rounded-lg overflow-hidden">
            <button
              onClick={() => toggleSection(section.id)}
              className="w-full px-4 py-3 bg-surface hover:bg-secondary-100 flex items-center justify-between text-left transition-colors focus-ring"
            >
              <div className="flex items-center space-x-3">
                <Icon name={section.icon} size={20} className="text-text-secondary" />
                <div>
                  <h4 className="font-medium text-text-primary">{section.title}</h4>
                  <p className="text-sm text-text-secondary">{section.subtitle}</p>
                </div>
              </div>
              <Icon 
                name={expandedSections[section.id] ? "ChevronUp" : "ChevronDown"} 
                size={20} 
                className="text-text-secondary" 
              />
            </button>

            {expandedSections[section.id] && (
              <div className="px-4 pb-4 bg-white">
                {/* Overall Assessment */}
                <div className="mb-4 p-3 bg-surface rounded-lg">
                  <p className="text-sm text-text-primary leading-relaxed">{section.assessment}</p>
                </div>

                {/* Strengths */}
                {section.strengths && section.strengths.length > 0 && (
                  <div className="mb-4">
                    <h5 className="flex items-center text-sm font-medium text-success-700 mb-2">
                      <Icon name="CheckCircle" size={16} className="mr-2" />
                      Strengths
                    </h5>
                    <ul className="space-y-2">
                      {section.strengths.map((strength, idx) => (
                        <li key={idx} className="flex items-start space-x-2 text-sm">
                          <span className="w-1.5 h-1.5 bg-success-500 rounded-full mt-2 flex-shrink-0" />
                          <span className="text-text-secondary">{strength}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Areas for Improvement */}
                {section.improvements && section.improvements.length > 0 && (
                  <div className="mb-4">
                    <h5 className="flex items-center text-sm font-medium text-warning-700 mb-2">
                      <Icon name="AlertCircle" size={16} className="mr-2" />
                      Areas for Improvement
                    </h5>
                    <div className="space-y-3">
                      {section.improvements.map((improvement, idx) => (
                        <div key={idx} className={`p-3 rounded-lg border ${getSeverityColor(improvement.severity)}`}>
                          <div className="flex items-start space-x-2">
                            <Icon name={getSeverityIcon(improvement.severity)} size={16} className="mt-0.5 flex-shrink-0" />
                            <div className="flex-1">
                              <p className="text-sm font-medium mb-1">{improvement.issue}</p>
                              <p className="text-xs opacity-90 mb-2">{improvement.description}</p>
                              <div className="flex items-center space-x-2">
                                <span className="text-xs font-medium">Recommendation:</span>
                                <span className="text-xs">{improvement.recommendation}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Specific Recommendations */}
                {section.recommendations && section.recommendations.length > 0 && (
                  <div className="mb-4">
                    <h5 className="flex items-center text-sm font-medium text-primary-700 mb-2">
                      <Icon name="Lightbulb" size={16} className="mr-2" />
                      Specific Recommendations
                    </h5>
                    <div className="space-y-2">
                      {section.recommendations.map((rec, idx) => (
                        <div key={idx} className="flex items-start space-x-2 p-2 bg-primary-50 rounded-lg">
                          <Icon name="ArrowRight" size={14} className="text-primary-600 mt-0.5 flex-shrink-0" />
                          <span className="text-sm text-text-primary">{rec}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Practice Resources */}
                {section.resources && section.resources.length > 0 && (
                  <div>
                    <h5 className="flex items-center text-sm font-medium text-accent-700 mb-2">
                      <Icon name="BookOpen" size={16} className="mr-2" />
                      Recommended Practice Resources
                    </h5>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {section.resources.map((resource, idx) => (
                        <Button
                          key={idx}
                          variant="outline"
                          size="sm"
                          iconName="ExternalLink"
                          iconPosition="right"
                          onClick={() => window.open(resource.url, '_blank')}
                          className="justify-between text-left"
                        >
                          <span className="truncate">{resource.title}</span>
                        </Button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-3 mt-6 pt-6 border-t border-border">
        <Button
          variant="primary"
          iconName="Download"
          iconPosition="left"
          onClick={() => {}}
          className="flex-1 sm:flex-none"
        >
          Download Detailed Report
        </Button>
        <Button
          variant="outline"
          iconName="Mail"
          iconPosition="left"
          onClick={() => {}}
          className="flex-1 sm:flex-none"
        >
          Email to Instructor
        </Button>
        <Button
          variant="ghost"
          iconName="Share"
          iconPosition="left"
          onClick={() => {}}
          className="flex-1 sm:flex-none"
        >
          Share Results
        </Button>
      </div>
    </div>
  );
};

export default DetailedFeedback;