import React, { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ScoreTrendChart = ({ testHistory }) => {
  const [selectedPeriod, setSelectedPeriod] = useState('all');
  const [selectedSections, setSelectedSections] = useState(['overall', 'listening', 'reading', 'writing', 'speaking']);

  const periodOptions = [
    { value: 'all', label: 'All Time' },
    { value: '6months', label: '6 Months' },
    { value: '3months', label: '3 Months' },
    { value: '1month', label: '1 Month' }
  ];

  const sectionColors = {
    overall: '#2563EB',
    listening: '#3B82F6',
    reading: '#10B981',
    writing: '#8B5CF6',
    speaking: '#F59E0B'
  };

  const filterDataByPeriod = (data) => {
    if (selectedPeriod === 'all') return data;
    
    const now = new Date();
    const monthsBack = selectedPeriod === '6months' ? 6 : selectedPeriod === '3months' ? 3 : 1;
    const cutoffDate = new Date(now.setMonth(now.getMonth() - monthsBack));
    
    return data.filter(item => new Date(item.date) >= cutoffDate);
  };

  const filteredData = filterDataByPeriod(testHistory);

  const toggleSection = (section) => {
    setSelectedSections(prev => 
      prev.includes(section) 
        ? prev.filter(s => s !== section)
        : [...prev, section]
    );
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-border rounded-lg shadow-lg">
          <p className="text-sm font-medium text-text-primary mb-2">{label}</p>
          {payload.map((entry, index) => (
            <div key={index} className="flex items-center space-x-2 text-sm">
              <div 
                className="w-3 h-3 rounded-full"
                style={{ backgroundColor: entry.color }}
              />
              <span className="text-text-secondary capitalize">{entry.dataKey}:</span>
              <span className="font-medium text-text-primary">{entry.value}</span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-white rounded-lg border border-border p-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
        <div className="flex items-center space-x-3 mb-4 sm:mb-0">
          <div className="w-10 h-10 bg-primary-50 rounded-lg flex items-center justify-center">
            <Icon name="TrendingUp" size={20} className="text-primary-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-text-primary">Score Trends</h3>
            <p className="text-sm text-text-secondary">Track your progress over time</p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          {periodOptions.map((option) => (
            <Button
              key={option.value}
              variant={selectedPeriod === option.value ? "primary" : "ghost"}
              size="sm"
              onClick={() => setSelectedPeriod(option.value)}
            >
              {option.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Section Toggles */}
      <div className="flex flex-wrap gap-2 mb-6">
        {Object.keys(sectionColors).map((section) => (
          <button
            key={section}
            onClick={() => toggleSection(section)}
            className={`flex items-center space-x-2 px-3 py-1 rounded-full text-sm font-medium transition-colors ${
              selectedSections.includes(section)
                ? 'bg-primary-100 text-primary-700 border border-primary-200' :'bg-secondary-100 text-secondary-600 border border-secondary-200 hover:bg-secondary-200'
            }`}
          >
            <div 
              className="w-3 h-3 rounded-full"
              style={{ backgroundColor: sectionColors[section] }}
            />
            <span className="capitalize">{section}</span>
          </button>
        ))}
      </div>

      {/* Chart */}
      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={filteredData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
            <XAxis 
              dataKey="date" 
              stroke="#64748B"
              fontSize={12}
              tickLine={false}
            />
            <YAxis 
              domain={[0, 9]}
              stroke="#64748B"
              fontSize={12}
              tickLine={false}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            
            {selectedSections.includes('overall') && (
              <Line
                type="monotone"
                dataKey="overall"
                stroke={sectionColors.overall}
                strokeWidth={3}
                dot={{ fill: sectionColors.overall, strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6 }}
              />
            )}
            {selectedSections.includes('listening') && (
              <Line
                type="monotone"
                dataKey="listening"
                stroke={sectionColors.listening}
                strokeWidth={2}
                dot={{ fill: sectionColors.listening, strokeWidth: 2, r: 3 }}
              />
            )}
            {selectedSections.includes('reading') && (
              <Line
                type="monotone"
                dataKey="reading"
                stroke={sectionColors.reading}
                strokeWidth={2}
                dot={{ fill: sectionColors.reading, strokeWidth: 2, r: 3 }}
              />
            )}
            {selectedSections.includes('writing') && (
              <Line
                type="monotone"
                dataKey="writing"
                stroke={sectionColors.writing}
                strokeWidth={2}
                dot={{ fill: sectionColors.writing, strokeWidth: 2, r: 3 }}
              />
            )}
            {selectedSections.includes('speaking') && (
              <Line
                type="monotone"
                dataKey="speaking"
                stroke={sectionColors.speaking}
                strokeWidth={2}
                dot={{ fill: sectionColors.speaking, strokeWidth: 2, r: 3 }}
              />
            )}
          </LineChart>
        </ResponsiveContainer>
      </div>

      {filteredData.length === 0 && (
        <div className="flex flex-col items-center justify-center h-40 text-text-secondary">
          <Icon name="BarChart3" size={48} className="mb-3 opacity-50" />
          <p className="text-lg font-medium">No data available</p>
          <p className="text-sm">Take more tests to see your progress trends</p>
        </div>
      )}
    </div>
  );
};

export default ScoreTrendChart;