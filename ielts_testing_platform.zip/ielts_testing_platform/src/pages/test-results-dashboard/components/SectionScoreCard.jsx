import React from 'react';
import Icon from '../../../components/AppIcon';

const SectionScoreCard = ({ section, score, previousScore, feedback, strengths, improvements }) => {
  const sectionConfig = {
    listening: {
      icon: 'Headphones',
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-200'
    },
    reading: {
      icon: 'BookOpen',
      color: 'text-green-600',
      bgColor: 'bg-green-50',
      borderColor: 'border-green-200'
    },
    writing: {
      icon: 'PenTool',
      color: 'text-purple-600',
      bgColor: 'bg-purple-50',
      borderColor: 'border-purple-200'
    },
    speaking: {
      icon: 'Mic',
      color: 'text-orange-600',
      bgColor: 'bg-orange-50',
      borderColor: 'border-orange-200'
    }
  };

  const config = sectionConfig[section.toLowerCase()];
  const improvement = previousScore ? (score - previousScore).toFixed(1) : null;

  const getScoreLevel = (score) => {
    if (score >= 8.0) return 'Excellent';
    if (score >= 6.5) return 'Good';
    if (score >= 5.5) return 'Average';
    return 'Needs Improvement';
  };

  return (
    <div className={`bg-white rounded-lg border ${config.borderColor} p-6 hover:shadow-md transition-shadow duration-200`}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className={`w-10 h-10 ${config.bgColor} rounded-lg flex items-center justify-center`}>
            <Icon name={config.icon} size={20} className={config.color} />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-text-primary capitalize">{section}</h3>
            <p className="text-sm text-text-secondary">{getScoreLevel(score)}</p>
          </div>
        </div>
        
        {improvement && (
          <div className={`flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium ${
            improvement > 0 ? 'bg-success-100 text-success-700' : 'bg-error-100 text-error-700'
          }`}>
            <Icon name={improvement > 0 ? 'ArrowUp' : 'ArrowDown'} size={12} />
            <span>{improvement > 0 ? '+' : ''}{improvement}</span>
          </div>
        )}
      </div>

      <div className="flex items-end space-x-2 mb-4">
        <div className={`text-3xl font-bold ${config.color}`}>
          {score.toFixed(1)}
        </div>
        <div className="text-sm text-text-secondary pb-1">/ 9.0</div>
      </div>

      {/* Score Progress */}
      <div className="w-full bg-secondary-100 rounded-full h-2 mb-4">
        <div 
          className={`h-2 rounded-full transition-all duration-500 ${
            section.toLowerCase() === 'listening' ? 'bg-blue-500' :
            section.toLowerCase() === 'reading' ? 'bg-green-500' :
            section.toLowerCase() === 'writing' ? 'bg-purple-500' : 'bg-orange-500'
          }`}
          style={{ width: `${(score / 9) * 100}%` }}
        />
      </div>

      {/* Feedback Section */}
      <div className="space-y-3">
        <div className="text-sm text-text-primary">
          <p className="font-medium mb-1">Feedback:</p>
          <p className="text-text-secondary leading-relaxed">{feedback}</p>
        </div>

        {strengths && strengths.length > 0 && (
          <div>
            <p className="text-sm font-medium text-success-700 mb-2 flex items-center">
              <Icon name="CheckCircle" size={16} className="mr-1" />
              Strengths
            </p>
            <ul className="text-xs text-text-secondary space-y-1">
              {strengths.map((strength, index) => (
                <li key={index} className="flex items-start">
                  <span className="w-1 h-1 bg-success-500 rounded-full mt-2 mr-2 flex-shrink-0" />
                  {strength}
                </li>
              ))}
            </ul>
          </div>
        )}

        {improvements && improvements.length > 0 && (
          <div>
            <p className="text-sm font-medium text-warning-700 mb-2 flex items-center">
              <Icon name="AlertCircle" size={16} className="mr-1" />
              Areas for Improvement
            </p>
            <ul className="text-xs text-text-secondary space-y-1">
              {improvements.map((improvement, index) => (
                <li key={index} className="flex items-start">
                  <span className="w-1 h-1 bg-warning-500 rounded-full mt-2 mr-2 flex-shrink-0" />
                  {improvement}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
};

export default SectionScoreCard;