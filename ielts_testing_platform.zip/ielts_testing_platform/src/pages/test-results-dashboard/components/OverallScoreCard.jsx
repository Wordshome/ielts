import React from 'react';
import Icon from '../../../components/AppIcon';

const OverallScoreCard = ({ overallScore, previousScore, testDate, testType }) => {
  const getScoreColor = (score) => {
    if (score >= 8.0) return 'text-success-600';
    if (score >= 6.5) return 'text-primary-600';
    if (score >= 5.5) return 'text-warning-600';
    return 'text-error-600';
  };

  const getScoreBgColor = (score) => {
    if (score >= 8.0) return 'bg-success-50 border-success-200';
    if (score >= 6.5) return 'bg-primary-50 border-primary-200';
    if (score >= 5.5) return 'bg-warning-50 border-warning-200';
    return 'bg-error-50 border-error-200';
  };

  const getBandDescription = (score) => {
    if (score >= 8.5) return 'Expert User';
    if (score >= 7.5) return 'Very Good User';
    if (score >= 6.5) return 'Competent User';
    if (score >= 5.5) return 'Modest User';
    if (score >= 4.5) return 'Limited User';
    return 'Extremely Limited User';
  };

  const improvement = previousScore ? (overallScore - previousScore).toFixed(1) : null;

  return (
    <div className={`rounded-xl border-2 p-6 ${getScoreBgColor(overallScore)}`}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm">
            <Icon name="Award" size={24} className="text-primary-600" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-text-primary">Overall Band Score</h2>
            <p className="text-sm text-text-secondary">{testType} • {testDate}</p>
          </div>
        </div>
        
        {improvement && (
          <div className={`flex items-center space-x-1 px-3 py-1 rounded-full text-sm font-medium ${
            improvement > 0 ? 'bg-success-100 text-success-700' : 'bg-error-100 text-error-700'
          }`}>
            <Icon name={improvement > 0 ? 'TrendingUp' : 'TrendingDown'} size={16} />
            <span>{improvement > 0 ? '+' : ''}{improvement}</span>
          </div>
        )}
      </div>

      <div className="flex items-end space-x-4 mb-4">
        <div className={`text-5xl font-bold ${getScoreColor(overallScore)}`}>
          {overallScore.toFixed(1)}
        </div>
        <div className="pb-2">
          <div className="text-lg font-semibold text-text-primary">
            {getBandDescription(overallScore)}
          </div>
          <div className="text-sm text-text-secondary">
            Band {Math.floor(overallScore)} - {Math.ceil(overallScore)}
          </div>
        </div>
      </div>

      {/* Score Progress Bar */}
      <div className="w-full bg-white rounded-full h-3 mb-3">
        <div 
          className={`h-3 rounded-full transition-all duration-500 ${
            overallScore >= 8.0 ? 'bg-success-500' :
            overallScore >= 6.5 ? 'bg-primary-500' :
            overallScore >= 5.5 ? 'bg-warning-500' : 'bg-error-500'
          }`}
          style={{ width: `${(overallScore / 9) * 100}%` }}
        />
      </div>

      <div className="flex justify-between text-xs text-text-secondary">
        <span>0</span>
        <span>4.5</span>
        <span>6.5</span>
        <span>8.0</span>
        <span>9.0</span>
      </div>
    </div>
  );
};

export default OverallScoreCard;