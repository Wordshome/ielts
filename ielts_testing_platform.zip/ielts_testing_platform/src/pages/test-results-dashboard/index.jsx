import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import AdaptiveHeader from '../../components/ui/AdaptiveHeader';
import NavigationBreadcrumb from '../../components/ui/NavigationBreadcrumb';
import OverallScoreCard from './components/OverallScoreCard';
import SectionScoreCard from './components/SectionScoreCard';
import ScoreTrendChart from './components/ScoreTrendChart';
import DetailedFeedback from './components/DetailedFeedback';
import CertificateDownload from './components/CertificateDownload';
import ScoreComparison from './components/ScoreComparison';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const TestResultsDashboard = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');

  // Mock user data
  const userInfo = {
    name: "Sarah Johnson",
    email: "sarah.johnson@email.com",
    testCenter: "London Test Center",
    candidateNumber: "GB123456789"
  };

  // Mock current test result
  const currentTestResult = {
    testDate: "15 Nov 2024",
    testType: "Academic",
    overallScore: 7.5,
    previousScore: 6.8,
    certificateId: "IELTS-2024-11-15-001",
    sections: {
      listening: 8.0,
      reading: 7.5,
      writing: 7.0,
      speaking: 7.5
    },
    previousSections: {
      listening: 7.5,
      reading: 7.0,
      writing: 6.5,
      speaking: 7.0
    }
  };

  // Mock test history for trends
  const testHistory = [
    {
      date: "15 Nov 2024",
      overall: 7.5,
      listening: 8.0,
      reading: 7.5,
      writing: 7.0,
      speaking: 7.5
    },
    {
      date: "20 Sep 2024",
      overall: 6.8,
      listening: 7.5,
      reading: 7.0,
      writing: 6.5,
      speaking: 7.0
    },
    {
      date: "15 Jul 2024",
      overall: 6.2,
      listening: 6.5,
      reading: 6.5,
      writing: 5.5,
      speaking: 6.5
    },
    {
      date: "10 May 2024",
      overall: 5.8,
      listening: 6.0,
      reading: 6.0,
      writing: 5.0,
      speaking: 6.0
    }
  ];

  // Mock detailed feedback data
  const feedbackData = [
    {
      id: 'listening',
      title: 'Listening Section',
      subtitle: 'Score: 8.0/9.0 - Excellent Performance',
      icon: 'Headphones',
      assessment: `Excellent listening comprehension demonstrated throughout all four parts. You showed strong ability to understand main ideas, specific details, and implied meanings. Your note-taking skills were particularly effective during the longer monologues and conversations.`,
      strengths: [
        'Excellent understanding of main ideas and supporting details',
        'Strong ability to follow complex conversations and lectures',
        'Effective note-taking and information organization',
        'Good grasp of different accents and speaking styles'
      ],
      improvements: [
        {
          issue: 'Minor difficulty with some technical vocabulary',
          description: 'Occasionally missed specific technical terms in academic contexts',
          recommendation: 'Practice with academic vocabulary lists and technical terminology',
          severity: 'low'
        }
      ],
      recommendations: [
        'Continue practicing with authentic materials like BBC podcasts',
        'Focus on academic lectures and technical presentations',
        'Practice prediction techniques before listening'
      ],
      resources: [
        { title: 'IELTS Listening Practice Tests', url: '#' },
        { title: 'Academic Vocabulary Builder', url: '#' }
      ]
    },
    {
      id: 'reading',
      title: 'Reading Section',
      subtitle: 'Score: 7.5/9.0 - Very Good Performance',
      icon: 'BookOpen',
      assessment: `Very good reading comprehension with strong analytical skills. You demonstrated excellent ability to understand complex texts and identify key information quickly. Your time management was effective across all three passages.`,
      strengths: [
        'Strong skimming and scanning techniques',
        'Excellent comprehension of complex academic texts',
        'Good time management across all passages',
        'Effective use of context clues for unknown vocabulary'
      ],
      improvements: [
        {
          issue: 'Some difficulty with True/False/Not Given questions',
          description: 'Occasionally confused between False and Not Given responses',
          recommendation: 'Practice distinguishing between contradicted and unstated information',
          severity: 'medium'
        }
      ],
      recommendations: [
        'Practice more True/False/Not Given question types',
        'Work on identifying paraphrased information',
        'Continue reading academic journals and articles'
      ],
      resources: [
        { title: 'IELTS Reading Strategies Guide', url: '#' },
        { title: 'Academic Reading Practice', url: '#' }
      ]
    },
    {
      id: 'writing',
      title: 'Writing Section',
      subtitle: 'Score: 7.0/9.0 - Good Performance',
      icon: 'PenTool',
      assessment: `Good writing performance with clear organization and coherent arguments. Your essays showed good structure and logical flow. Task achievement was generally strong, though there's room for improvement in lexical resource and grammatical range.`,
      strengths: [
        'Clear essay structure and organization','Good use of linking words and cohesive devices','Relevant examples and supporting evidence','Appropriate register and tone for academic writing'
      ],
      improvements: [
        {
          issue: 'Limited range of vocabulary',description: 'Repetition of certain words and phrases throughout essays',recommendation: 'Expand vocabulary range with synonyms and academic word lists',severity: 'medium'
        },
        {
          issue: 'Some grammatical errors affecting clarity',description: 'Occasional errors in complex sentence structures',recommendation: 'Practice complex grammar structures and proofread carefully',severity: 'medium'
        }
      ],
      recommendations: [
        'Build academic vocabulary through reading and word lists','Practice complex sentence structures and grammar patterns','Work on essay planning and time management','Get feedback on practice essays from qualified instructors'
      ],
      resources: [
        { title: 'Academic Writing Task 1 & 2 Guide', url: '#' },
        { title: 'IELTS Vocabulary Builder', url: '#' },
        { title: 'Grammar for Academic Writing', url: '#' }
      ]
    },
    {
      id: 'speaking',title: 'Speaking Section',subtitle: 'Score: 7.5/9.0 - Very Good Performance',icon: 'Mic',
      assessment: `Very good speaking performance with natural fluency and good pronunciation. You demonstrated confidence across all three parts of the test and showed good ability to develop topics with relevant details and examples.`,
      strengths: [
        'Natural fluency and rhythm in speech','Good pronunciation and clear articulation','Confident delivery across all three parts','Effective use of examples and personal experiences','Good range of vocabulary for most topics'
      ],
      improvements: [
        {
          issue: 'Occasional hesitation with abstract topics',description: 'Some difficulty expressing complex ideas in Part 3',recommendation: 'Practice discussing abstract concepts and philosophical questions',severity: 'low'
        }
      ],
      recommendations: [
        'Practice discussing abstract and complex topics','Work on expressing opinions with sophisticated language','Continue building topic-specific vocabulary','Practice with native speakers when possible'
      ],
      resources: [
        { title: 'IELTS Speaking Practice Topics', url: '#' },
        { title: 'Advanced Speaking Strategies', url: '#' }
      ]
    }
  ];

  const tabs = [
    { id: 'overview', label: 'Overview', icon: 'BarChart3' },
    { id: 'detailed', label: 'Detailed Analysis', icon: 'FileText' },
    { id: 'trends', label: 'Progress Trends', icon: 'TrendingUp' },
    { id: 'comparison', label: 'Score Comparison', icon: 'Target' },
    { id: 'certificate', label: 'Certificate', icon: 'Award' }
  ];

  const handleStartNewTest = () => {
    navigate('/listening-test-interface');
  };

  const handleViewProfile = () => {
    navigate('/user-profile-settings');
  };

  return (
    <div className="min-h-screen bg-surface">
      <AdaptiveHeader />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <NavigationBreadcrumb />
        
        {/* Header Section */}
        <div className="mb-8">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold text-text-primary mb-2">Test Results Dashboard</h1>
              <p className="text-text-secondary">
                Comprehensive analysis of your IELTS performance and progress tracking
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-3 mt-4 lg:mt-0">
              <Button
                variant="primary"
                iconName="Play"
                iconPosition="left"
                onClick={handleStartNewTest}
              >
                Take New Test
              </Button>
              <Button
                variant="outline"
                iconName="User"
                iconPosition="left"
                onClick={handleViewProfile}
              >
                View Profile
              </Button>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="border-b border-border">
            <nav className="flex space-x-8 overflow-x-auto">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 py-3 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-colors focus-ring ${
                    activeTab === tab.id
                      ? 'border-primary-500 text-primary-600' :'border-transparent text-text-secondary hover:text-text-primary hover:border-secondary-300'
                  }`}
                >
                  <Icon name={tab.icon} size={18} />
                  <span>{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Tab Content */}
        <div className="space-y-8">
          {activeTab === 'overview' && (
            <>
              {/* Overall Score */}
              <OverallScoreCard
                overallScore={currentTestResult.overallScore}
                previousScore={currentTestResult.previousScore}
                testDate={currentTestResult.testDate}
                testType={currentTestResult.testType}
              />

              {/* Section Scores Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
                {Object.entries(currentTestResult.sections).map(([section, score]) => (
                  <SectionScoreCard
                    key={section}
                    section={section}
                    score={score}
                    previousScore={currentTestResult.previousSections[section]}
                    feedback={feedbackData.find(f => f.id === section)?.assessment || ''}
                    strengths={feedbackData.find(f => f.id === section)?.strengths || []}
                    improvements={feedbackData.find(f => f.id === section)?.improvements?.map(i => i.issue) || []}
                  />
                ))}
              </div>

              {/* Quick Actions */}
              <div className="bg-white rounded-lg border border-border p-6">
                <h3 className="text-lg font-semibold text-text-primary mb-4">Quick Actions</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <Button
                    variant="outline"
                    iconName="Download"
                    iconPosition="left"
                    onClick={() => setActiveTab('certificate')}
                    fullWidth
                  >
                    Download Certificate
                  </Button>
                  <Button
                    variant="outline"
                    iconName="TrendingUp"
                    iconPosition="left"
                    onClick={() => setActiveTab('trends')}
                    fullWidth
                  >
                    View Progress
                  </Button>
                  <Button
                    variant="outline"
                    iconName="Target"
                    iconPosition="left"
                    onClick={() => setActiveTab('comparison')}
                    fullWidth
                  >
                    Compare Scores
                  </Button>
                  <Button
                    variant="outline"
                    iconName="Share"
                    iconPosition="left"
                    onClick={() => {}}
                    fullWidth
                  >
                    Share Results
                  </Button>
                </div>
              </div>
            </>
          )}

          {activeTab === 'detailed' && (
            <DetailedFeedback feedbackData={feedbackData} />
          )}

          {activeTab === 'trends' && (
            <ScoreTrendChart testHistory={testHistory} />
          )}

          {activeTab === 'comparison' && (
            <ScoreComparison
              currentScore={currentTestResult.sections}
              targetRequirements={{}}
            />
          )}

          {activeTab === 'certificate' && (
            <CertificateDownload
              testResult={currentTestResult}
              userInfo={userInfo}
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default TestResultsDashboard;