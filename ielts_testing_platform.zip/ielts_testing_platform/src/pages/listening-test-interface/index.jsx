import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import AdaptiveHeader from '../../components/ui/AdaptiveHeader';
import TestProgressBar from '../../components/ui/TestProgressBar';
import TestTimer from '../../components/ui/TestTimer';
import AudioPlayer from './components/AudioPlayer';
import QuestionDisplay from './components/QuestionDisplay';
import TranscriptPanel from './components/TranscriptPanel';
import TestControls from './components/TestControls';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const ListeningTestInterface = () => {
  const navigate = useNavigate();
  const audioRef = useRef(null);
  
  // Test state
  const [currentSection, setCurrentSection] = useState(0);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState({});
  const [isTestPaused, setIsTestPaused] = useState(false);
  const [showTranscript, setShowTranscript] = useState(false);
  const [sectionProgress, setSectionProgress] = useState(0);
  
  // Audio state
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [audioLoaded, setAudioLoaded] = useState(false);

  // Mock test data
  const testSections = [
    {
      id: 1,
      name: "Section 1 - Everyday Social Context",
      audioSrc: "https://www.soundjay.com/misc/sounds/bell-ringing-05.wav",
      duration: 600, // 10 minutes
      questions: [
        {
          id: 1,
          type: "multiple-choice",
          section: "Section 1",
          question: "What is the main topic of the conversation?",
          context: "You will hear a conversation between two people discussing weekend plans.",
          options: [
            { value: "A", text: "Planning a weekend trip" },
            { value: "B", text: "Discussing work schedules" },
            { value: "C", text: "Talking about hobbies" },
            { value: "D", text: "Making dinner reservations" }
          ]
        },
        {
          id: 2,
          type: "fill-in-blank",
          section: "Section 1",
          question: "Complete the information below.",
          context: "Fill in the missing information from the conversation.",
          text: "The meeting is scheduled for ___ at ___ in the ___ room."
        },
        {
          id: 3,
          type: "short-answer",
          section: "Section 1",
          question: "What time does the library close on weekends?",
          context: "Write NO MORE THAN THREE WORDS for your answer.",
          maxWords: 3
        }
      ]
    },
    {
      id: 2,
      name: "Section 2 - General Social Context",
      audioSrc: "https://www.soundjay.com/misc/sounds/bell-ringing-05.wav",
      duration: 600,
      questions: [
        {
          id: 4,
          type: "matching",
          section: "Section 2",
          question: "Match the facilities with their locations.",
          context: "You will hear a description of a sports center layout.",
          items: [
            { id: "1", text: "Swimming pool" },
            { id: "2", text: "Tennis courts" },
            { id: "3", text: "Gym equipment" }
          ],
          options: [
            { id: "A", text: "Ground floor" },
            { id: "B", text: "First floor" },
            { id: "C", text: "Second floor" },
            { id: "D", text: "Basement" }
          ]
        }
      ]
    }
  ];

  const transcriptData = [
    {
      id: 1,
      startTime: 0,
      endTime: 15,
      speaker: "Speaker A",
      text: "Good morning, I'd like to inquire about the weekend activities available at the community center."
    },
    {
      id: 2,
      startTime: 15,
      endTime: 30,
      speaker: "Speaker B",
      text: "Certainly! We have a variety of programs running throughout the weekend. What type of activities are you interested in?"
    },
    {
      id: 3,
      startTime: 30,
      endTime: 45,
      speaker: "Speaker A",
      text: "I\'m particularly interested in fitness classes and maybe some social events for families."
    }
  ];

  // Get current section and question data
  const getCurrentSection = () => testSections[currentSection] || testSections[0];
  const getCurrentQuestion = () => {
    const section = getCurrentSection();
    return section.questions[currentQuestion] || section.questions[0];
  };

  const totalQuestions = testSections.reduce((total, section) => total + section.questions.length, 0);
  const answeredQuestions = Object.keys(answers).length;

  // Audio event handlers
  const handleAudioTimeUpdate = (time) => {
    setCurrentTime(time);
    // Update section progress based on audio time
    const section = getCurrentSection();
    const progress = (time / section.duration) * 100;
    setSectionProgress(Math.min(progress, 100));
  };

  const handleAudioEnded = () => {
    setIsPlaying(false);
    // Auto-advance to next section if available
    if (currentSection < testSections.length - 1) {
      setTimeout(() => {
        setCurrentSection(prev => prev + 1);
        setCurrentQuestion(0);
        setSectionProgress(0);
      }, 2000);
    }
  };

  const handlePlayPause = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  // Question navigation
  const handleAnswerChange = (questionIndex, answer) => {
    const questionId = getCurrentQuestion().id;
    setAnswers(prev => ({
      ...prev,
      [questionId]: answer
    }));
  };

  const handleNextQuestion = () => {
    const section = getCurrentSection();
    if (currentQuestion < section.questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    } else if (currentSection < testSections.length - 1) {
      setCurrentSection(prev => prev + 1);
      setCurrentQuestion(0);
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(prev => prev - 1);
    } else if (currentSection > 0) {
      setCurrentSection(prev => prev - 1);
      const prevSection = testSections[currentSection - 1];
      setCurrentQuestion(prevSection.questions.length - 1);
    }
  };

  // Test control handlers
  const handleTestPause = () => {
    setIsTestPaused(true);
    if (isPlaying) {
      handlePlayPause();
    }
  };

  const handleTestResume = () => {
    setIsTestPaused(false);
  };

  const handleTestSubmit = () => {
    // Navigate to results with test data
    navigate('/test-results-dashboard', {
      state: {
        testType: 'listening',
        answers,
        totalQuestions,
        answeredQuestions,
        completedAt: new Date().toISOString()
      }
    });
  };

  const handleTestExit = () => {
    navigate('/test-results-dashboard');
  };

  const handleTimeUp = () => {
    handleTestSubmit();
  };

  const handleTimeWarning = (timeRemaining) => {
    // Show warning notification
    console.log(`Time warning: ${timeRemaining} seconds remaining`);
  };

  // Initialize audio
  useEffect(() => {
    const audio = audioRef.current;
    if (audio) {
      const handleLoadedMetadata = () => {
        setDuration(audio.duration);
        setAudioLoaded(true);
      };

      audio.addEventListener('loadedmetadata', handleLoadedMetadata);
      return () => audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
    }
  }, [currentSection]);

  const currentSectionData = getCurrentSection();
  const currentQuestionData = getCurrentQuestion();
  const selectedAnswer = answers[currentQuestionData.id];

  return (
    <div className="min-h-screen bg-surface">
      <AdaptiveHeader />
      <TestProgressBar
        currentSection={currentSection}
        totalSections={testSections.length}
        sectionProgress={sectionProgress}
        timeRemaining={Math.max(0, currentSectionData.duration - currentTime)}
        totalTime={currentSectionData.duration}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Section Header */}
            <div className="bg-background border border-border rounded-lg p-4 md:p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h1 className="text-xl md:text-2xl font-semibold text-text-primary">
                    IELTS Listening Test
                  </h1>
                  <p className="text-text-secondary mt-1">
                    {currentSectionData.name}
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    iconName="HelpCircle"
                    onClick={() => {}}
                  >
                    Help
                  </Button>
                </div>
              </div>

              {/* Test Instructions */}
              <div className="bg-primary-50 border border-primary-200 rounded-lg p-4">
                <div className="flex items-start space-x-3">
                  <Icon name="Info" size={20} className="text-primary-600 mt-0.5" />
                  <div className="text-sm text-primary-800">
                    <p className="font-medium mb-1">Instructions:</p>
                    <ul className="space-y-1">
                      <li>• Listen carefully to the audio recording</li>
                      <li>• Answer all questions in the order they appear</li>
                      <li>• You can take notes while listening</li>
                      <li>• The audio will play only once</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            {/* Audio Player */}
            <AudioPlayer
              audioSrc={currentSectionData.audioSrc}
              onTimeUpdate={handleAudioTimeUpdate}
              onEnded={handleAudioEnded}
              currentTime={currentTime}
              duration={duration}
              isPlaying={isPlaying}
              onPlayPause={handlePlayPause}
              disabled={isTestPaused}
            />

            {/* Question Display */}
            <QuestionDisplay
              question={currentQuestionData}
              questionIndex={currentQuestion}
              totalQuestions={currentSectionData.questions.length}
              selectedAnswer={selectedAnswer}
              onAnswerChange={handleAnswerChange}
              onNext={handleNextQuestion}
              onPrevious={handlePreviousQuestion}
              showTranscript={showTranscript}
              onToggleTranscript={() => setShowTranscript(!showTranscript)}
            />

            {/* Transcript Panel */}
            {showTranscript && (
              <TranscriptPanel
                transcript={transcriptData}
                currentTime={currentTime}
                isVisible={showTranscript}
                onClose={() => setShowTranscript(false)}
                onSeek={(time) => {
                  if (audioRef.current) {
                    audioRef.current.currentTime = time;
                  }
                }}
              />
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Timer */}
            <TestTimer
              initialTime={currentSectionData.duration}
              onTimeUp={handleTimeUp}
              onTimeWarning={handleTimeWarning}
              warningThreshold={300}
              criticalThreshold={60}
              autoStart={false}
              sectionName={currentSectionData.name}
            />

            {/* Test Controls */}
            <TestControls
              onPause={handleTestPause}
              onResume={handleTestResume}
              onSubmit={handleTestSubmit}
              onExit={handleTestExit}
              isPaused={isTestPaused}
              canSubmit={answeredQuestions > 0}
              showSubmitWarning={answeredQuestions < totalQuestions}
              currentSection={currentSection + 1}
              totalSections={testSections.length}
              answeredQuestions={answeredQuestions}
              totalQuestions={totalQuestions}
            />

            {/* Quick Navigation */}
            <div className="bg-background border border-border rounded-lg p-4">
              <h3 className="font-medium text-text-primary mb-3">Quick Navigation</h3>
              <div className="space-y-2">
                {testSections.map((section, sectionIndex) => (
                  <div key={section.id}>
                    <div className={`text-sm font-medium p-2 rounded ${
                      sectionIndex === currentSection
                        ? 'bg-primary-50 text-primary-700' :'text-text-secondary'
                    }`}>
                      Section {sectionIndex + 1}
                    </div>
                    <div className="grid grid-cols-5 gap-1 mt-2 ml-2">
                      {section.questions.map((question, questionIndex) => {
                        const isAnswered = answers[question.id] !== undefined;
                        const isCurrent = sectionIndex === currentSection && questionIndex === currentQuestion;
                        
                        return (
                          <button
                            key={question.id}
                            className={`w-8 h-8 text-xs rounded border ${
                              isCurrent
                                ? 'bg-primary-500 text-white border-primary-500'
                                : isAnswered
                                ? 'bg-success-100 text-success-700 border-success-300' :'bg-secondary-100 text-secondary-600 border-secondary-200 hover:bg-secondary-200'
                            }`}
                            onClick={() => {
                              setCurrentSection(sectionIndex);
                              setCurrentQuestion(questionIndex);
                            }}
                          >
                            {questionIndex + 1}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Hidden audio element */}
      <audio
        ref={audioRef}
        src={currentSectionData.audioSrc}
        onTimeUpdate={(e) => handleAudioTimeUpdate(e.target.currentTime)}
        onEnded={handleAudioEnded}
        onLoadedMetadata={(e) => setDuration(e.target.duration)}
        preload="metadata"
      />

      {/* Pause Overlay */}
      {isTestPaused && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-background border border-border rounded-lg p-8 max-w-md w-full mx-4">
            <div className="text-center">
              <div className="w-16 h-16 bg-warning-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Icon name="Pause" size={32} className="text-warning-600" />
              </div>
              <h3 className="text-lg font-medium text-text-primary mb-2">Test Paused</h3>
              <p className="text-text-secondary mb-6">
                Your test is currently paused. Click resume to continue.
              </p>
              <Button
                variant="primary"
                iconName="Play"
                onClick={handleTestResume}
                fullWidth
              >
                Resume Test
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ListeningTestInterface;