import React, { useState, useRef, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const AudioPlayer = ({ 
  audioSrc, 
  onTimeUpdate, 
  onEnded, 
  currentTime = 0,
  duration = 0,
  isPlaying = false,
  onPlayPause,
  disabled = false
}) => {
  const audioRef = useRef(null);
  const [volume, setVolume] = useState(0.8);
  const [playbackRate, setPlaybackRate] = useState(1.0);
  const [isLoading, setIsLoading] = useState(false);
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleTimeUpdate = () => {
      onTimeUpdate?.(audio.currentTime);
    };

    const handleLoadStart = () => setIsLoading(true);
    const handleCanPlay = () => {
      setIsLoading(false);
      setHasError(false);
    };
    const handleError = () => {
      setIsLoading(false);
      setHasError(true);
    };
    const handleEnded = () => onEnded?.();

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('loadstart', handleLoadStart);
    audio.addEventListener('canplay', handleCanPlay);
    audio.addEventListener('error', handleError);
    audio.addEventListener('ended', handleEnded);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('loadstart', handleLoadStart);
      audio.removeEventListener('canplay', handleCanPlay);
      audio.removeEventListener('error', handleError);
      audio.removeEventListener('ended', handleEnded);
    };
  }, [onTimeUpdate, onEnded]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    audio.volume = volume;
    audio.playbackRate = playbackRate;
  }, [volume, playbackRate]);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleVolumeChange = (e) => {
    setVolume(parseFloat(e.target.value));
  };

  const handlePlaybackRateChange = (rate) => {
    setPlaybackRate(rate);
  };

  const getVolumeIcon = () => {
    if (volume === 0) return 'VolumeX';
    if (volume < 0.5) return 'Volume1';
    return 'Volume2';
  };

  if (hasError) {
    return (
      <div className="bg-error-50 border border-error-200 rounded-lg p-6">
        <div className="flex items-center space-x-3 text-error-600">
          <Icon name="AlertCircle" size={24} />
          <div>
            <h3 className="font-medium">Audio Loading Error</h3>
            <p className="text-sm text-error-500">
              Unable to load audio file. Please check your connection and try again.
            </p>
          </div>
        </div>
        <Button
          variant="outline"
          size="sm"
          iconName="RefreshCw"
          onClick={() => {
            setHasError(false);
            audioRef.current?.load();
          }}
          className="mt-3"
        >
          Retry
        </Button>
      </div>
    );
  }

  return (
    <div className="bg-surface border border-border rounded-lg p-4 md:p-6">
      <audio
        ref={audioRef}
        src={audioSrc}
        preload="metadata"
        className="hidden"
      />

      {/* Main Controls */}
      <div className="flex items-center justify-center space-x-4 mb-6">
        <Button
          variant="primary"
          size="lg"
          iconName={isLoading ? "Loader2" : isPlaying ? "Pause" : "Play"}
          onClick={onPlayPause}
          disabled={disabled || isLoading}
          className={`w-16 h-16 rounded-full ${isLoading ? 'animate-spin' : ''}`}
          aria-label={isPlaying ? 'Pause audio' : 'Play audio'}
        />
      </div>

      {/* Progress Bar */}
      <div className="mb-4">
        <div className="flex items-center justify-between text-sm text-text-secondary mb-2">
          <span className="font-data">{formatTime(currentTime)}</span>
          <span className="font-data">{formatTime(duration)}</span>
        </div>
        <div className="w-full bg-secondary-200 rounded-full h-2">
          <div
            className="bg-primary-500 h-2 rounded-full transition-all duration-300"
            style={{ width: duration > 0 ? `${(currentTime / duration) * 100}%` : '0%' }}
          />
        </div>
      </div>

      {/* Desktop Controls */}
      <div className="hidden md:flex items-center justify-between">
        {/* Volume Control */}
        <div className="flex items-center space-x-3">
          <Icon name={getVolumeIcon()} size={20} className="text-text-secondary" />
          <input
            type="range"
            min="0"
            max="1"
            step="0.1"
            value={volume}
            onChange={handleVolumeChange}
            className="w-20 h-2 bg-secondary-200 rounded-lg appearance-none cursor-pointer"
            aria-label="Volume control"
          />
          <span className="text-sm text-text-secondary font-data w-8">
            {Math.round(volume * 100)}
          </span>
        </div>

        {/* Playback Speed */}
        <div className="flex items-center space-x-2">
          <span className="text-sm text-text-secondary">Speed:</span>
          {[0.75, 1.0, 1.25, 1.5].map((rate) => (
            <Button
              key={rate}
              variant={playbackRate === rate ? "primary" : "ghost"}
              size="xs"
              onClick={() => handlePlaybackRateChange(rate)}
              className="min-w-12"
            >
              {rate}x
            </Button>
          ))}
        </div>
      </div>

      {/* Mobile Controls */}
      <div className="md:hidden space-y-3">
        {/* Volume Control */}
        <div className="flex items-center space-x-3">
          <Icon name={getVolumeIcon()} size={18} className="text-text-secondary" />
          <input
            type="range"
            min="0"
            max="1"
            step="0.1"
            value={volume}
            onChange={handleVolumeChange}
            className="flex-1 h-2 bg-secondary-200 rounded-lg appearance-none cursor-pointer"
            aria-label="Volume control"
          />
          <span className="text-sm text-text-secondary font-data w-8">
            {Math.round(volume * 100)}
          </span>
        </div>

        {/* Playback Speed */}
        <div className="flex items-center justify-center space-x-2">
          <span className="text-sm text-text-secondary">Speed:</span>
          {[0.75, 1.0, 1.25, 1.5].map((rate) => (
            <Button
              key={rate}
              variant={playbackRate === rate ? "primary" : "ghost"}
              size="xs"
              onClick={() => handlePlaybackRateChange(rate)}
              className="min-w-10"
            >
              {rate}x
            </Button>
          ))}
        </div>
      </div>

      {/* Status Indicator */}
      {isLoading && (
        <div className="flex items-center justify-center space-x-2 mt-4 text-text-secondary">
          <Icon name="Loader2" size={16} className="animate-spin" />
          <span className="text-sm">Loading audio...</span>
        </div>
      )}
    </div>
  );
};

export default AudioPlayer;