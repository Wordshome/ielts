import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const TranscriptPanel = ({ 
  transcript, 
  currentTime = 0, 
  isVisible = false, 
  onClose,
  onSeek 
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [highlightedSegments, setHighlightedSegments] = useState([]);

  useEffect(() => {
    if (searchTerm.trim()) {
      const segments = transcript.filter(segment =>
        segment.text.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setHighlightedSegments(segments.map(s => s.id));
    } else {
      setHighlightedSegments([]);
    }
  }, [searchTerm, transcript]);

  const getCurrentSegment = () => {
    return transcript.find(segment => 
      currentTime >= segment.startTime && currentTime <= segment.endTime
    );
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSegmentClick = (startTime) => {
    onSeek?.(startTime);
  };

  const highlightText = (text, searchTerm) => {
    if (!searchTerm.trim()) return text;
    
    const regex = new RegExp(`(${searchTerm})`, 'gi');
    const parts = text.split(regex);
    
    return parts.map((part, index) => 
      regex.test(part) ? (
        <mark key={index} className="bg-warning-100 text-warning-800 px-1 rounded">
          {part}
        </mark>
      ) : part
    );
  };

  if (!isVisible) return null;

  const currentSegment = getCurrentSegment();

  return (
    <div className="bg-background border border-border rounded-lg shadow-custom-md">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Icon name="FileText" size={20} className="text-text-secondary" />
            <h3 className="font-medium text-text-primary">Audio Transcript</h3>
          </div>
          <Button
            variant="ghost"
            size="sm"
            iconName="X"
            onClick={onClose}
            aria-label="Close transcript"
          />
        </div>
        
        {/* Search */}
        <div className="mt-3 relative">
          <Icon 
            name="Search" 
            size={16} 
            className="absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary" 
          />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search transcript..."
            className="w-full pl-10 pr-4 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
          />
        </div>
      </div>

      {/* Transcript Content */}
      <div className="max-h-96 overflow-y-auto">
        {transcript.length === 0 ? (
          <div className="p-6 text-center text-text-secondary">
            <Icon name="FileText" size={48} className="mx-auto mb-3 opacity-50" />
            <p>No transcript available for this audio</p>
          </div>
        ) : (
          <div className="p-4 space-y-3">
            {transcript.map((segment) => {
              const isActive = currentSegment?.id === segment.id;
              const isHighlighted = highlightedSegments.includes(segment.id);
              
              return (
                <div
                  key={segment.id}
                  className={`p-3 rounded-lg border cursor-pointer transition-all ${
                    isActive
                      ? 'border-primary-500 bg-primary-50'
                      : isHighlighted
                      ? 'border-warning-300 bg-warning-50' :'border-border hover:border-primary-300 hover:bg-surface'
                  }`}
                  onClick={() => handleSegmentClick(segment.startTime)}
                >
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0">
                      <span className={`text-xs font-data px-2 py-1 rounded ${
                        isActive
                          ? 'bg-primary-500 text-white' :'bg-secondary-100 text-secondary-600'
                      }`}>
                        {formatTime(segment.startTime)}
                      </span>
                    </div>
                    <div className="flex-1">
                      <p className={`text-sm leading-relaxed ${
                        isActive ? 'text-primary-700' : 'text-text-primary'
                      }`}>
                        {highlightText(segment.text, searchTerm)}
                      </p>
                      {segment.speaker && (
                        <p className="text-xs text-text-secondary mt-1">
                          Speaker: {segment.speaker}
                        </p>
                      )}
                    </div>
                    {isActive && (
                      <Icon name="Play" size={16} className="text-primary-500 flex-shrink-0" />
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="p-4 border-t border-border bg-surface">
        <div className="flex items-center justify-between text-sm text-text-secondary">
          <span>{transcript.length} segments</span>
          {searchTerm && (
            <span>{highlightedSegments.length} matches found</span>
          )}
        </div>
      </div>
    </div>
  );
};

export default TranscriptPanel;