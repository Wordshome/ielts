import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const QuestionDisplay = ({ 
  question, 
  questionIndex, 
  totalQuestions,
  selectedAnswer,
  onAnswerChange,
  onNext,
  onPrevious,
  canNavigate = true,
  showTranscript = false,
  onToggleTranscript
}) => {
  const [notes, setNotes] = useState('');

  const handleAnswerSelect = (value) => {
    onAnswerChange(questionIndex, value);
  };

  const handleTextInput = (e) => {
    onAnswerChange(questionIndex, e.target.value);
  };

  const renderQuestionContent = () => {
    switch (question.type) {
      case 'multiple-choice':
        return (
          <div className="space-y-3">
            {question.options.map((option, index) => (
              <label
                key={index}
                className={`flex items-start space-x-3 p-3 rounded-lg border cursor-pointer transition-all ${
                  selectedAnswer === option.value
                    ? 'border-primary-500 bg-primary-50' :'border-border hover:border-primary-300 hover:bg-surface'
                }`}
              >
                <input
                  type="radio"
                  name={`question-${questionIndex}`}
                  value={option.value}
                  checked={selectedAnswer === option.value}
                  onChange={() => handleAnswerSelect(option.value)}
                  className="mt-1 w-4 h-4 text-primary-600 border-border focus:ring-primary-500"
                />
                <div className="flex-1">
                  <span className="text-text-primary">{option.text}</span>
                  {option.description && (
                    <p className="text-sm text-text-secondary mt-1">{option.description}</p>
                  )}
                </div>
              </label>
            ))}
          </div>
        );

      case 'fill-in-blank':
        return (
          <div className="space-y-4">
            <div className="text-text-primary leading-relaxed">
              {question.text.split('___').map((part, index) => (
                <React.Fragment key={index}>
                  {part}
                  {index < question.text.split('___').length - 1 && (
                    <Input
                      type="text"
                      value={selectedAnswer?.[index] || ''}
                      onChange={(e) => {
                        const newAnswers = [...(selectedAnswer || [])];
                        newAnswers[index] = e.target.value;
                        handleAnswerSelect(newAnswers);
                      }}
                      className="inline-block w-32 mx-2"
                      placeholder="Answer"
                    />
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>
        );

      case 'matching':
        return (
          <div className="space-y-4">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium text-text-primary mb-3">Items</h4>
                <div className="space-y-2">
                  {question.items.map((item, index) => (
                    <div key={index} className="p-3 bg-surface rounded-lg border">
                      <span className="font-medium text-primary-600">{item.id}.</span>
                      <span className="ml-2 text-text-primary">{item.text}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="font-medium text-text-primary mb-3">Options</h4>
                <div className="space-y-2">
                  {question.options.map((option, index) => (
                    <div key={index} className="p-3 bg-surface rounded-lg border">
                      <span className="font-medium text-secondary-600">{option.id}.</span>
                      <span className="ml-2 text-text-primary">{option.text}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div className="space-y-3">
              {question.items.map((item, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <span className="font-medium text-primary-600 w-8">{item.id}.</span>
                  <select
                    value={selectedAnswer?.[index] || ''}
                    onChange={(e) => {
                      const newAnswers = [...(selectedAnswer || [])];
                      newAnswers[index] = e.target.value;
                      handleAnswerSelect(newAnswers);
                    }}
                    className="flex-1 p-2 border border-border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  >
                    <option value="">Select option</option>
                    {question.options.map((option) => (
                      <option key={option.id} value={option.id}>
                        {option.id}. {option.text}
                      </option>
                    ))}
                  </select>
                </div>
              ))}
            </div>
          </div>
        );

      case 'short-answer':
        return (
          <div className="space-y-4">
            <Input
              type="text"
              value={selectedAnswer || ''}
              onChange={handleTextInput}
              placeholder="Type your answer here..."
              className="w-full"
            />
            <div className="text-sm text-text-secondary">
              Maximum {question.maxWords || 3} words
            </div>
          </div>
        );

      default:
        return (
          <div className="text-text-secondary">
            Question type not supported
          </div>
        );
    }
  };

  return (
    <div className="bg-background border border-border rounded-lg">
      {/* Question Header */}
      <div className="p-4 md:p-6 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-primary-500 text-white rounded-full flex items-center justify-center text-sm font-medium">
              {questionIndex + 1}
            </div>
            <div>
              <h3 className="font-medium text-text-primary">
                Question {questionIndex + 1} of {totalQuestions}
              </h3>
              <p className="text-sm text-text-secondary capitalize">
                {question.type.replace('-', ' ')} • {question.section}
              </p>
            </div>
          </div>
          
          {onToggleTranscript && (
            <Button
              variant="ghost"
              size="sm"
              iconName={showTranscript ? "EyeOff" : "Eye"}
              onClick={onToggleTranscript}
            >
              {showTranscript ? 'Hide' : 'Show'} Transcript
            </Button>
          )}
        </div>

        {/* Question Text */}
        <div className="prose prose-sm max-w-none">
          <p className="text-text-primary leading-relaxed">{question.question}</p>
          {question.context && (
            <div className="mt-3 p-3 bg-surface rounded-lg">
              <p className="text-sm text-text-secondary italic">{question.context}</p>
            </div>
          )}
        </div>
      </div>

      {/* Question Content */}
      <div className="p-4 md:p-6">
        {renderQuestionContent()}
      </div>

      {/* Notes Section */}
      <div className="p-4 md:p-6 border-t border-border bg-surface">
        <div className="flex items-center space-x-2 mb-3">
          <Icon name="FileText" size={16} className="text-text-secondary" />
          <span className="text-sm font-medium text-text-secondary">Notes</span>
        </div>
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Take notes here... (optional)"
          className="w-full p-3 border border-border rounded-lg resize-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
          rows={3}
        />
      </div>

      {/* Navigation */}
      {canNavigate && (
        <div className="p-4 md:p-6 border-t border-border">
          <div className="flex items-center justify-between">
            <Button
              variant="outline"
              iconName="ChevronLeft"
              onClick={onPrevious}
              disabled={questionIndex === 0}
            >
              Previous
            </Button>
            
            <div className="flex items-center space-x-2">
              <div className="flex space-x-1">
                {Array.from({ length: totalQuestions }, (_, i) => (
                  <div
                    key={i}
                    className={`w-2 h-2 rounded-full ${
                      i === questionIndex
                        ? 'bg-primary-500'
                        : i < questionIndex
                        ? 'bg-success-500' :'bg-secondary-200'
                    }`}
                  />
                ))}
              </div>
            </div>

            <Button
              variant="primary"
              iconName="ChevronRight"
              iconPosition="right"
              onClick={onNext}
              disabled={questionIndex === totalQuestions - 1}
            >
              {questionIndex === totalQuestions - 1 ? 'Finish' : 'Next'}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default QuestionDisplay;