import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const TestControls = ({ 
  onPause,
  onResume,
  onSubmit,
  onExit,
  isPaused = false,
  canSubmit = false,
  showSubmitWarning = false,
  currentSection = 1,
  totalSections = 4,
  answeredQuestions = 0,
  totalQuestions = 40
}) => {
  const [showExitConfirm, setShowExitConfirm] = useState(false);
  const [showSubmitConfirm, setShowSubmitConfirm] = useState(false);

  const handleExitClick = () => {
    setShowExitConfirm(true);
  };

  const handleSubmitClick = () => {
    setShowSubmitConfirm(true);
  };

  const confirmExit = () => {
    setShowExitConfirm(false);
    onExit?.();
  };

  const confirmSubmit = () => {
    setShowSubmitConfirm(false);
    onSubmit?.();
  };

  const cancelAction = () => {
    setShowExitConfirm(false);
    setShowSubmitConfirm(false);
  };

  return (
    <>
      <div className="bg-background border border-border rounded-lg p-4">
        {/* Test Status */}
        <div className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-text-primary">Test Progress</span>
            <span className="text-sm text-text-secondary">
              Section {currentSection} of {totalSections}
            </span>
          </div>
          <div className="w-full bg-secondary-200 rounded-full h-2 mb-2">
            <div
              className="bg-primary-500 h-2 rounded-full transition-all duration-300"
              style={{ width: `${(answeredQuestions / totalQuestions) * 100}%` }}
            />
          </div>
          <div className="flex justify-between text-xs text-text-secondary">
            <span>{answeredQuestions} answered</span>
            <span>{totalQuestions - answeredQuestions} remaining</span>
          </div>
        </div>

        {/* Control Buttons */}
        <div className="space-y-3">
          {/* Pause/Resume */}
          <Button
            variant={isPaused ? "primary" : "secondary"}
            iconName={isPaused ? "Play" : "Pause"}
            onClick={isPaused ? onResume : onPause}
            fullWidth
          >
            {isPaused ? 'Resume Test' : 'Pause Test'}
          </Button>

          {/* Submit Test */}
          <Button
            variant={showSubmitWarning ? "warning" : "success"}
            iconName="CheckCircle"
            onClick={handleSubmitClick}
            disabled={!canSubmit}
            fullWidth
          >
            Submit Test
          </Button>

          {/* Exit Test */}
          <Button
            variant="outline"
            iconName="LogOut"
            onClick={handleExitClick}
            fullWidth
          >
            Exit Test
          </Button>
        </div>

        {/* Warning Messages */}
        {showSubmitWarning && (
          <div className="mt-4 p-3 bg-warning-50 border border-warning-200 rounded-lg">
            <div className="flex items-start space-x-2">
              <Icon name="AlertTriangle" size={16} className="text-warning-600 mt-0.5" />
              <div className="text-sm">
                <p className="text-warning-800 font-medium">Incomplete Answers</p>
                <p className="text-warning-700">
                  You have {totalQuestions - answeredQuestions} unanswered questions. 
                  You can still submit, but consider reviewing your answers.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Test Instructions Reminder */}
        <div className="mt-4 p-3 bg-surface border border-border rounded-lg">
          <div className="flex items-start space-x-2">
            <Icon name="Info" size={16} className="text-text-secondary mt-0.5" />
            <div className="text-sm text-text-secondary">
              <p className="font-medium">Remember:</p>
              <ul className="mt-1 space-y-1 text-xs">
                <li>• Audio will play only once per section</li>
                <li>• You can take notes during the test</li>
                <li>• Review your answers before submitting</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Exit Confirmation Modal */}
      {showExitConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-background border border-border rounded-lg max-w-md w-full p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-error-100 rounded-full flex items-center justify-center">
                <Icon name="AlertTriangle" size={20} className="text-error-600" />
              </div>
              <div>
                <h3 className="font-medium text-text-primary">Exit Test?</h3>
                <p className="text-sm text-text-secondary">
                  Are you sure you want to exit the test?
                </p>
              </div>
            </div>
            
            <div className="mb-4 p-3 bg-error-50 border border-error-200 rounded-lg">
              <p className="text-sm text-error-800">
                <strong>Warning:</strong> If you exit now, your progress will be lost and 
                you'll need to restart the entire test.
              </p>
            </div>

            <div className="flex space-x-3">
              <Button
                variant="outline"
                onClick={cancelAction}
                fullWidth
              >
                Cancel
              </Button>
              <Button
                variant="danger"
                onClick={confirmExit}
                fullWidth
              >
                Exit Test
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Submit Confirmation Modal */}
      {showSubmitConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-background border border-border rounded-lg max-w-md w-full p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-success-100 rounded-full flex items-center justify-center">
                <Icon name="CheckCircle" size={20} className="text-success-600" />
              </div>
              <div>
                <h3 className="font-medium text-text-primary">Submit Test?</h3>
                <p className="text-sm text-text-secondary">
                  Ready to submit your listening test?
                </p>
              </div>
            </div>
            
            <div className="mb-4 space-y-3">
              <div className="p-3 bg-surface border border-border rounded-lg">
                <div className="flex justify-between text-sm">
                  <span className="text-text-secondary">Questions Answered:</span>
                  <span className="font-medium text-text-primary">
                    {answeredQuestions} / {totalQuestions}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-text-secondary">Completion:</span>
                  <span className="font-medium text-text-primary">
                    {Math.round((answeredQuestions / totalQuestions) * 100)}%
                  </span>
                </div>
              </div>
              
              {answeredQuestions < totalQuestions && (
                <div className="p-3 bg-warning-50 border border-warning-200 rounded-lg">
                  <p className="text-sm text-warning-800">
                    You have {totalQuestions - answeredQuestions} unanswered questions. 
                    These will be marked as incorrect.
                  </p>
                </div>
              )}
            </div>

            <div className="flex space-x-3">
              <Button
                variant="outline"
                onClick={cancelAction}
                fullWidth
              >
                Review Answers
              </Button>
              <Button
                variant="success"
                onClick={confirmSubmit}
                fullWidth
              >
                Submit Test
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default TestControls;