import React, { useState, useEffect } from 'react';
import AdaptiveHeader from '../../components/ui/AdaptiveHeader';
import NavigationBreadcrumb from '../../components/ui/NavigationBreadcrumb';
import PersonalInfoSection from './components/PersonalInfoSection';
import AccountSecuritySection from './components/AccountSecuritySection';
import TestPreferencesSection from './components/TestPreferencesSection';
import NotificationSettingsSection from './components/NotificationSettingsSection';
import PrivacyControlsSection from './components/PrivacyControlsSection';
import LanguageTimezoneSection from './components/LanguageTimezoneSection';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const UserProfileSettings = () => {
  const [expandedSections, setExpandedSections] = useState({
    personalInfo: true,
    accountSecurity: false,
    testPreferences: false,
    notifications: false,
    privacy: false,
    localization: false
  });

  const [userData, setUserData] = useState({
    firstName: "Sarah",
    lastName: "Johnson",
    email: "sarah.johnson@email.com",
    phone: "+1 (555) 123-4567",
    dateOfBirth: "1995-03-15",
    nationality: "United States",
    profilePhoto: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face"
  });

  const [preferences, setPreferences] = useState({
    defaultTestType: "academic",
    timerSettings: "standard",
    autoSave: true,
    showProgressBar: true,
    enableKeyboardShortcuts: true,
    fontSize: "medium",
    theme: "light",
    audioQuality: "high",
    speakingRecordingQuality: "high",
    accessibilityMode: false,
    screenReaderSupport: false,
    highContrastMode: false
  });

  const [notifications, setNotifications] = useState({
    emailNotifications: true,
    testReminders: true,
    progressUpdates: true,
    resultNotifications: true,
    marketingEmails: false,
    pushNotifications: true,
    smsNotifications: false,
    weeklyReports: true,
    achievementAlerts: true,
    reminderFrequency: "daily",
    quietHours: { enabled: false, start: "22:00", end: "08:00" }
  });

  const [privacy, setPrivacy] = useState({
    profileVisibility: "private",
    shareProgress: false,
    allowAnalytics: true,
    dataCollection: true,
    thirdPartySharing: false,
    marketingConsent: false,
    researchParticipation: false,
    cookiePreferences: "essential"
  });

  const [localization, setLocalization] = useState({
    language: "en",
    timezone: "America/New_York",
    dateFormat: "MM/DD/YYYY",
    timeFormat: "12h",
    currency: "USD",
    numberFormat: "international"
  });

  const [saveStatus, setSaveStatus] = useState({
    isVisible: false,
    message: '',
    type: 'success'
  });

  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  useEffect(() => {
    const handleBeforeUnload = (e) => {
      if (hasUnsavedChanges) {
        e.preventDefault();
        e.returnValue = '';
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [hasUnsavedChanges]);

  const toggleSection = (sectionKey) => {
    setExpandedSections(prev => ({
      ...prev,
      [sectionKey]: !prev[sectionKey]
    }));
  };

  const handleUpdate = (section, data) => {
    setHasUnsavedChanges(false);
    
    switch (section) {
      case 'personalInfo':
        setUserData(prev => ({ ...prev, ...data }));
        break;
      case 'security':
        // Handle security updates
        break;
      case 'testPreferences':
        setPreferences(prev => ({ ...prev, ...data }));
        break;
      case 'notifications':
        setNotifications(prev => ({ ...prev, ...data }));
        break;
      case 'privacy':
        setPrivacy(prev => ({ ...prev, ...data }));
        break;
      case 'localization':
        setLocalization(prev => ({ ...prev, ...data }));
        break;
      default:
        break;
    }

    showSaveStatus('Settings updated successfully!', 'success');
  };

  const showSaveStatus = (message, type = 'success') => {
    setSaveStatus({
      isVisible: true,
      message,
      type
    });

    setTimeout(() => {
      setSaveStatus(prev => ({ ...prev, isVisible: false }));
    }, 3000);
  };

  const handleExpandAll = () => {
    const allExpanded = Object.values(expandedSections).every(Boolean);
    const newState = Object.keys(expandedSections).reduce((acc, key) => {
      acc[key] = !allExpanded;
      return acc;
    }, {});
    setExpandedSections(newState);
  };

  const handleResetToDefaults = () => {
    if (window.confirm('Are you sure you want to reset all settings to their default values? This action cannot be undone.')) {
      setPreferences({
        defaultTestType: "academic",
        timerSettings: "standard",
        autoSave: true,
        showProgressBar: true,
        enableKeyboardShortcuts: true,
        fontSize: "medium",
        theme: "light",
        audioQuality: "high",
        speakingRecordingQuality: "high",
        accessibilityMode: false,
        screenReaderSupport: false,
        highContrastMode: false
      });

      setNotifications({
        emailNotifications: true,
        testReminders: true,
        progressUpdates: true,
        resultNotifications: true,
        marketingEmails: false,
        pushNotifications: true,
        smsNotifications: false,
        weeklyReports: true,
        achievementAlerts: true,
        reminderFrequency: "daily",
        quietHours: { enabled: false, start: "22:00", end: "08:00" }
      });

      setPrivacy({
        profileVisibility: "private",
        shareProgress: false,
        allowAnalytics: true,
        dataCollection: true,
        thirdPartySharing: false,
        marketingConsent: false,
        researchParticipation: false,
        cookiePreferences: "essential"
      });

      showSaveStatus('Settings reset to defaults', 'success');
    }
  };

  return (
    <div className="min-h-screen bg-surface">
      <AdaptiveHeader />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <NavigationBreadcrumb />
        
        {/* Header Section */}
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold text-text-primary mb-2">Profile Settings</h1>
              <p className="text-text-secondary">
                Manage your account preferences and customize your IELTS testing experience
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-3 mt-4 sm:mt-0">
              <Button
                variant="outline"
                size="sm"
                iconName={Object.values(expandedSections).every(Boolean) ? "Minimize2" : "Maximize2"}
                onClick={handleExpandAll}
              >
                {Object.values(expandedSections).every(Boolean) ? 'Collapse All' : 'Expand All'}
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                iconName="RotateCcw"
                onClick={handleResetToDefaults}
              >
                Reset to Defaults
              </Button>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
            <div className="bg-background border border-border rounded-lg p-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-primary-50 rounded-lg flex items-center justify-center">
                  <Icon name="User" size={20} className="text-primary-600" />
                </div>
                <div>
                  <div className="text-sm font-medium text-text-primary">Profile Completion</div>
                  <div className="text-xs text-text-secondary">85% Complete</div>
                </div>
              </div>
            </div>
            
            <div className="bg-background border border-border rounded-lg p-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-success-50 rounded-lg flex items-center justify-center">
                  <Icon name="Shield" size={20} className="text-success-600" />
                </div>
                <div>
                  <div className="text-sm font-medium text-text-primary">Security Score</div>
                  <div className="text-xs text-text-secondary">Good</div>
                </div>
              </div>
            </div>
            
            <div className="bg-background border border-border rounded-lg p-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-accent-50 rounded-lg flex items-center justify-center">
                  <Icon name="Settings" size={20} className="text-accent-600" />
                </div>
                <div>
                  <div className="text-sm font-medium text-text-primary">Last Updated</div>
                  <div className="text-xs text-text-secondary">2 days ago</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Settings Sections */}
        <div className="space-y-6">
          <PersonalInfoSection
            isExpanded={expandedSections.personalInfo}
            onToggle={() => toggleSection('personalInfo')}
            userData={userData}
            onUpdate={handleUpdate}
          />

          <AccountSecuritySection
            isExpanded={expandedSections.accountSecurity}
            onToggle={() => toggleSection('accountSecurity')}
            onUpdate={handleUpdate}
          />

          <TestPreferencesSection
            isExpanded={expandedSections.testPreferences}
            onToggle={() => toggleSection('testPreferences')}
            preferences={preferences}
            onUpdate={handleUpdate}
          />

          <NotificationSettingsSection
            isExpanded={expandedSections.notifications}
            onToggle={() => toggleSection('notifications')}
            notifications={notifications}
            onUpdate={handleUpdate}
          />

          <PrivacyControlsSection
            isExpanded={expandedSections.privacy}
            onToggle={() => toggleSection('privacy')}
            privacy={privacy}
            onUpdate={handleUpdate}
          />

          <LanguageTimezoneSection
            isExpanded={expandedSections.localization}
            onToggle={() => toggleSection('localization')}
            settings={localization}
            onUpdate={handleUpdate}
          />
        </div>

        {/* Save Status Toast */}
        {saveStatus.isVisible && (
          <div className="fixed bottom-4 right-4 z-50 animate-fade-in">
            <div className={`px-4 py-3 rounded-lg shadow-custom-lg flex items-center space-x-3 ${
              saveStatus.type === 'success' ?'bg-success-50 border border-success-200 text-success-700' :'bg-error-50 border border-error-200 text-error-700'
            }`}>
              <Icon 
                name={saveStatus.type === 'success' ? "CheckCircle" : "AlertCircle"} 
                size={20} 
              />
              <span className="text-sm font-medium">{saveStatus.message}</span>
            </div>
          </div>
        )}

        {/* Unsaved Changes Warning */}
        {hasUnsavedChanges && (
          <div className="fixed bottom-4 left-4 right-4 sm:left-auto sm:right-4 sm:w-96 z-50 animate-fade-in">
            <div className="bg-warning-50 border border-warning-200 rounded-lg p-4">
              <div className="flex items-center space-x-3">
                <Icon name="AlertTriangle" size={20} className="text-warning-600" />
                <div className="flex-1">
                  <div className="text-sm font-medium text-warning-700">Unsaved Changes</div>
                  <div className="text-xs text-warning-600">You have unsaved changes that will be lost if you leave.</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="mt-12 pt-8 border-t border-border">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
            <div className="text-sm text-text-secondary">
              <p>Need help with your settings? <a href="#" className="text-primary-600 hover:text-primary-700">Contact Support</a></p>
            </div>
            <div className="text-sm text-text-secondary mt-2 sm:mt-0">
              Last saved: {new Date().toLocaleDateString()} at {new Date().toLocaleTimeString()}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserProfileSettings;