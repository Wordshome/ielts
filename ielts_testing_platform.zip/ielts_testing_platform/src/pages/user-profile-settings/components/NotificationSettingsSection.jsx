import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const NotificationSettingsSection = ({ isExpanded, onToggle, notifications, onUpdate }) => {
  const [formData, setFormData] = useState({
    emailNotifications: notifications.emailNotifications !== false,
    testReminders: notifications.testReminders !== false,
    progressUpdates: notifications.progressUpdates !== false,
    resultNotifications: notifications.resultNotifications !== false,
    marketingEmails: notifications.marketingEmails || false,
    pushNotifications: notifications.pushNotifications !== false,
    smsNotifications: notifications.smsNotifications || false,
    weeklyReports: notifications.weeklyReports !== false,
    achievementAlerts: notifications.achievementAlerts !== false,
    reminderFrequency: notifications.reminderFrequency || 'daily',
    quietHours: notifications.quietHours || { enabled: false, start: '22:00', end: '08:00' }
  });

  const [isEditing, setIsEditing] = useState(false);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleQuietHoursChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      quietHours: {
        ...prev.quietHours,
        [field]: value
      }
    }));
  };

  const handleSave = () => {
    onUpdate('notifications', formData);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setFormData({
      emailNotifications: notifications.emailNotifications !== false,
      testReminders: notifications.testReminders !== false,
      progressUpdates: notifications.progressUpdates !== false,
      resultNotifications: notifications.resultNotifications !== false,
      marketingEmails: notifications.marketingEmails || false,
      pushNotifications: notifications.pushNotifications !== false,
      smsNotifications: notifications.smsNotifications || false,
      weeklyReports: notifications.weeklyReports !== false,
      achievementAlerts: notifications.achievementAlerts !== false,
      reminderFrequency: notifications.reminderFrequency || 'daily',
      quietHours: notifications.quietHours || { enabled: false, start: '22:00', end: '08:00' }
    });
    setIsEditing(false);
  };

  const reminderFrequencies = [
    { value: 'never', label: 'Never' },
    { value: 'daily', label: 'Daily' },
    { value: 'weekly', label: 'Weekly' },
    { value: 'monthly', label: 'Monthly' }
  ];

  const notificationTypes = [
    {
      key: 'emailNotifications',
      title: 'Email Notifications',
      description: 'Receive general notifications via email',
      icon: 'Mail',
      category: 'essential'
    },
    {
      key: 'testReminders',
      title: 'Test Reminders',
      description: 'Get reminded about upcoming scheduled tests',
      icon: 'Clock',
      category: 'essential'
    },
    {
      key: 'resultNotifications',
      title: 'Result Notifications',
      description: 'Be notified when your test results are ready',
      icon: 'FileText',
      category: 'essential'
    },
    {
      key: 'progressUpdates',
      title: 'Progress Updates',
      description: 'Receive updates about your learning progress',
      icon: 'TrendingUp',
      category: 'updates'
    },
    {
      key: 'weeklyReports',
      title: 'Weekly Reports',
      description: 'Get weekly summaries of your performance',
      icon: 'BarChart3',
      category: 'updates'
    },
    {
      key: 'achievementAlerts',
      title: 'Achievement Alerts',
      description: 'Celebrate your milestones and achievements',
      icon: 'Award',
      category: 'updates'
    },
    {
      key: 'pushNotifications',
      title: 'Push Notifications',
      description: 'Receive browser push notifications',
      icon: 'Bell',
      category: 'delivery'
    },
    {
      key: 'smsNotifications',
      title: 'SMS Notifications',
      description: 'Get important updates via text message',
      icon: 'MessageSquare',
      category: 'delivery'
    },
    {
      key: 'marketingEmails',
      title: 'Marketing Emails',
      description: 'Receive promotional content and tips',
      icon: 'Megaphone',
      category: 'marketing'
    }
  ];

  const getNotificationsByCategory = (category) => {
    return notificationTypes.filter(type => type.category === category);
  };

  return (
    <div className="bg-background border border-border rounded-lg shadow-custom-sm">
      <button
        onClick={onToggle}
        className="w-full px-6 py-4 flex items-center justify-between text-left hover:bg-surface transition-colors focus-ring rounded-t-lg"
      >
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-warning-50 rounded-lg flex items-center justify-center">
            <Icon name="Bell" size={20} className="text-warning-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-text-primary">Notification Settings</h3>
            <p className="text-sm text-text-secondary">Manage how you receive updates and alerts</p>
          </div>
        </div>
        <Icon 
          name={isExpanded ? "ChevronUp" : "ChevronDown"} 
          size={20} 
          className="text-text-secondary" 
        />
      </button>

      {isExpanded && (
        <div className="px-6 pb-6 border-t border-border">
          <div className="pt-6 space-y-8">
            {/* Essential Notifications */}
            <div>
              <h4 className="text-base font-medium text-text-primary mb-4 flex items-center space-x-2">
                <Icon name="AlertCircle" size={16} className="text-primary-600" />
                <span>Essential Notifications</span>
              </h4>
              <div className="space-y-4">
                {getNotificationsByCategory('essential').map(notification => (
                  <div key={notification.key} className="flex items-center justify-between p-4 bg-surface rounded-lg border border-border">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-primary-50 rounded-lg flex items-center justify-center">
                        <Icon name={notification.icon} size={20} className="text-primary-600" />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-text-primary">{notification.title}</div>
                        <div className="text-xs text-text-secondary">{notification.description}</div>
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={formData[notification.key]}
                      onChange={(e) => handleInputChange(notification.key, e.target.checked)}
                      disabled={!isEditing}
                      className="w-4 h-4 text-primary-600 border-border rounded focus:ring-primary-500"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Progress & Updates */}
            <div>
              <h4 className="text-base font-medium text-text-primary mb-4 flex items-center space-x-2">
                <Icon name="TrendingUp" size={16} className="text-success-600" />
                <span>Progress & Updates</span>
              </h4>
              <div className="space-y-4">
                {getNotificationsByCategory('updates').map(notification => (
                  <div key={notification.key} className="flex items-center justify-between p-4 bg-surface rounded-lg border border-border">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-success-50 rounded-lg flex items-center justify-center">
                        <Icon name={notification.icon} size={20} className="text-success-600" />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-text-primary">{notification.title}</div>
                        <div className="text-xs text-text-secondary">{notification.description}</div>
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={formData[notification.key]}
                      onChange={(e) => handleInputChange(notification.key, e.target.checked)}
                      disabled={!isEditing}
                      className="w-4 h-4 text-primary-600 border-border rounded focus:ring-primary-500"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Delivery Methods */}
            <div>
              <h4 className="text-base font-medium text-text-primary mb-4 flex items-center space-x-2">
                <Icon name="Send" size={16} className="text-accent-600" />
                <span>Delivery Methods</span>
              </h4>
              <div className="space-y-4">
                {getNotificationsByCategory('delivery').map(notification => (
                  <div key={notification.key} className="flex items-center justify-between p-4 bg-surface rounded-lg border border-border">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-accent-50 rounded-lg flex items-center justify-center">
                        <Icon name={notification.icon} size={20} className="text-accent-600" />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-text-primary">{notification.title}</div>
                        <div className="text-xs text-text-secondary">{notification.description}</div>
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={formData[notification.key]}
                      onChange={(e) => handleInputChange(notification.key, e.target.checked)}
                      disabled={!isEditing}
                      className="w-4 h-4 text-primary-600 border-border rounded focus:ring-primary-500"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Marketing */}
            <div>
              <h4 className="text-base font-medium text-text-primary mb-4 flex items-center space-x-2">
                <Icon name="Megaphone" size={16} className="text-warning-600" />
                <span>Marketing & Promotions</span>
              </h4>
              <div className="space-y-4">
                {getNotificationsByCategory('marketing').map(notification => (
                  <div key={notification.key} className="flex items-center justify-between p-4 bg-surface rounded-lg border border-border">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-warning-50 rounded-lg flex items-center justify-center">
                        <Icon name={notification.icon} size={20} className="text-warning-600" />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-text-primary">{notification.title}</div>
                        <div className="text-xs text-text-secondary">{notification.description}</div>
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={formData[notification.key]}
                      onChange={(e) => handleInputChange(notification.key, e.target.checked)}
                      disabled={!isEditing}
                      className="w-4 h-4 text-primary-600 border-border rounded focus:ring-primary-500"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Reminder Frequency */}
            <div>
              <h4 className="text-base font-medium text-text-primary mb-4">Reminder Frequency</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {reminderFrequencies.map(frequency => (
                  <label key={frequency.value} className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="radio"
                      name="reminderFrequency"
                      value={frequency.value}
                      checked={formData.reminderFrequency === frequency.value}
                      onChange={(e) => handleInputChange('reminderFrequency', e.target.value)}
                      disabled={!isEditing}
                      className="w-4 h-4 text-primary-600 border-border focus:ring-primary-500"
                    />
                    <span className="text-sm text-text-primary">{frequency.label}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Quiet Hours */}
            <div>
              <h4 className="text-base font-medium text-text-primary mb-4">Quiet Hours</h4>
              <div className="p-4 bg-surface rounded-lg border border-border">
                <label className="flex items-center justify-between mb-4 cursor-pointer">
                  <div>
                    <div className="text-sm font-medium text-text-primary">Enable Quiet Hours</div>
                    <div className="text-xs text-text-secondary">Pause notifications during specified hours</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={formData.quietHours.enabled}
                    onChange={(e) => handleQuietHoursChange('enabled', e.target.checked)}
                    disabled={!isEditing}
                    className="w-4 h-4 text-primary-600 border-border rounded focus:ring-primary-500"
                  />
                </label>
                
                {formData.quietHours.enabled && (
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-text-primary mb-2">
                        Start Time
                      </label>
                      <input
                        type="time"
                        value={formData.quietHours.start}
                        onChange={(e) => handleQuietHoursChange('start', e.target.value)}
                        disabled={!isEditing}
                        className="w-full px-3 py-2 border border-border rounded-lg bg-background text-text-primary focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent disabled:bg-secondary-50 disabled:text-text-muted"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-text-primary mb-2">
                        End Time
                      </label>
                      <input
                        type="time"
                        value={formData.quietHours.end}
                        onChange={(e) => handleQuietHoursChange('end', e.target.value)}
                        disabled={!isEditing}
                        className="w-full px-3 py-2 border border-border rounded-lg bg-background text-text-primary focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent disabled:bg-secondary-50 disabled:text-text-muted"
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 pt-6 border-t border-border">
              {!isEditing ? (
                <Button
                  variant="primary"
                  iconName="Edit"
                  onClick={() => setIsEditing(true)}
                >
                  Edit Notifications
                </Button>
              ) : (
                <div className="flex flex-col sm:flex-row gap-3">
                  <Button
                    variant="primary"
                    iconName="Save"
                    onClick={handleSave}
                  >
                    Save Changes
                  </Button>
                  <Button
                    variant="outline"
                    iconName="X"
                    onClick={handleCancel}
                  >
                    Cancel
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default NotificationSettingsSection;