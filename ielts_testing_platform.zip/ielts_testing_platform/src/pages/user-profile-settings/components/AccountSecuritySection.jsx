import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const AccountSecuritySection = ({ isExpanded, onToggle, onUpdate }) => {
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false);
  const [showPasswords, setShowPasswords] = useState({
    current: false,
    new: false,
    confirm: false
  });
  const [isChangingPassword, setIsChangingPassword] = useState(false);

  const handlePasswordChange = (field, value) => {
    setPasswordData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const togglePasswordVisibility = (field) => {
    setShowPasswords(prev => ({
      ...prev,
      [field]: !prev[field]
    }));
  };

  const handlePasswordSubmit = () => {
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      alert('New passwords do not match');
      return;
    }
    
    if (passwordData.newPassword.length < 8) {
      alert('Password must be at least 8 characters long');
      return;
    }

    onUpdate('security', { passwordChanged: true });
    setPasswordData({
      currentPassword: '',
      newPassword: '',
      confirmPassword: ''
    });
    setIsChangingPassword(false);
    alert('Password updated successfully');
  };

  const handleTwoFactorToggle = () => {
    setTwoFactorEnabled(!twoFactorEnabled);
    onUpdate('security', { twoFactorEnabled: !twoFactorEnabled });
  };

  const getPasswordStrength = (password) => {
    if (!password) return { strength: 0, label: '', color: '' };
    
    let strength = 0;
    if (password.length >= 8) strength++;
    if (/[A-Z]/.test(password)) strength++;
    if (/[a-z]/.test(password)) strength++;
    if (/[0-9]/.test(password)) strength++;
    if (/[^A-Za-z0-9]/.test(password)) strength++;

    const labels = ['Very Weak', 'Weak', 'Fair', 'Good', 'Strong'];
    const colors = ['bg-error-500', 'bg-warning-500', 'bg-warning-400', 'bg-success-400', 'bg-success-500'];
    
    return {
      strength: (strength / 5) * 100,
      label: labels[strength - 1] || 'Very Weak',
      color: colors[strength - 1] || 'bg-error-500'
    };
  };

  const passwordStrength = getPasswordStrength(passwordData.newPassword);

  return (
    <div className="bg-background border border-border rounded-lg shadow-custom-sm">
      <button
        onClick={onToggle}
        className="w-full px-6 py-4 flex items-center justify-between text-left hover:bg-surface transition-colors focus-ring rounded-t-lg"
      >
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-success-50 rounded-lg flex items-center justify-center">
            <Icon name="Shield" size={20} className="text-success-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-text-primary">Account Security</h3>
            <p className="text-sm text-text-secondary">Manage your password and security settings</p>
          </div>
        </div>
        <Icon 
          name={isExpanded ? "ChevronUp" : "ChevronDown"} 
          size={20} 
          className="text-text-secondary" 
        />
      </button>

      {isExpanded && (
        <div className="px-6 pb-6 border-t border-border">
          <div className="pt-6 space-y-8">
            {/* Password Change Section */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h4 className="text-base font-medium text-text-primary">Password</h4>
                  <p className="text-sm text-text-secondary">
                    Last changed 3 months ago
                  </p>
                </div>
                {!isChangingPassword && (
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="Key"
                    onClick={() => setIsChangingPassword(true)}
                  >
                    Change Password
                  </Button>
                )}
              </div>

              {isChangingPassword && (
                <div className="space-y-4 p-4 bg-surface rounded-lg border border-border">
                  <div>
                    <label className="block text-sm font-medium text-text-primary mb-2">
                      Current Password *
                    </label>
                    <div className="relative">
                      <Input
                        type={showPasswords.current ? "text" : "password"}
                        value={passwordData.currentPassword}
                        onChange={(e) => handlePasswordChange('currentPassword', e.target.value)}
                        placeholder="Enter your current password"
                        required
                      />
                      <button
                        type="button"
                        onClick={() => togglePasswordVisibility('current')}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-text-secondary hover:text-text-primary focus-ring rounded p-1"
                      >
                        <Icon name={showPasswords.current ? "EyeOff" : "Eye"} size={16} />
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-text-primary mb-2">
                      New Password *
                    </label>
                    <div className="relative">
                      <Input
                        type={showPasswords.new ? "text" : "password"}
                        value={passwordData.newPassword}
                        onChange={(e) => handlePasswordChange('newPassword', e.target.value)}
                        placeholder="Enter your new password"
                        required
                      />
                      <button
                        type="button"
                        onClick={() => togglePasswordVisibility('new')}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-text-secondary hover:text-text-primary focus-ring rounded p-1"
                      >
                        <Icon name={showPasswords.new ? "EyeOff" : "Eye"} size={16} />
                      </button>
                    </div>
                    
                    {passwordData.newPassword && (
                      <div className="mt-2">
                        <div className="flex items-center justify-between text-xs mb-1">
                          <span className="text-text-secondary">Password strength</span>
                          <span className="text-text-primary font-medium">{passwordStrength.label}</span>
                        </div>
                        <div className="w-full bg-secondary-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full transition-all duration-300 ${passwordStrength.color}`}
                            style={{ width: `${passwordStrength.strength}%` }}
                          />
                        </div>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-text-primary mb-2">
                      Confirm New Password *
                    </label>
                    <div className="relative">
                      <Input
                        type={showPasswords.confirm ? "text" : "password"}
                        value={passwordData.confirmPassword}
                        onChange={(e) => handlePasswordChange('confirmPassword', e.target.value)}
                        placeholder="Confirm your new password"
                        required
                      />
                      <button
                        type="button"
                        onClick={() => togglePasswordVisibility('confirm')}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-text-secondary hover:text-text-primary focus-ring rounded p-1"
                      >
                        <Icon name={showPasswords.confirm ? "EyeOff" : "Eye"} size={16} />
                      </button>
                    </div>
                    {passwordData.confirmPassword && passwordData.newPassword !== passwordData.confirmPassword && (
                      <p className="text-xs text-error-600 mt-1">Passwords do not match</p>
                    )}
                  </div>

                  <div className="flex flex-col sm:flex-row gap-3 pt-2">
                    <Button
                      variant="primary"
                      iconName="Save"
                      onClick={handlePasswordSubmit}
                      disabled={!passwordData.currentPassword || !passwordData.newPassword || !passwordData.confirmPassword || passwordData.newPassword !== passwordData.confirmPassword}
                    >
                      Update Password
                    </Button>
                    <Button
                      variant="outline"
                      iconName="X"
                      onClick={() => {
                        setIsChangingPassword(false);
                        setPasswordData({
                          currentPassword: '',
                          newPassword: '',
                          confirmPassword: ''
                        });
                      }}
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              )}
            </div>

            {/* Two-Factor Authentication */}
            <div>
              <div className="flex items-center justify-between p-4 bg-surface rounded-lg border border-border">
                <div className="flex items-center space-x-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    twoFactorEnabled ? 'bg-success-50' : 'bg-warning-50'
                  }`}>
                    <Icon 
                      name={twoFactorEnabled ? "ShieldCheck" : "ShieldAlert"} 
                      size={20} 
                      className={twoFactorEnabled ? 'text-success-600' : 'text-warning-600'} 
                    />
                  </div>
                  <div>
                    <h4 className="text-base font-medium text-text-primary">Two-Factor Authentication</h4>
                    <p className="text-sm text-text-secondary">
                      {twoFactorEnabled ? 'Enabled - Your account is protected' : 'Add an extra layer of security to your account'}
                    </p>
                  </div>
                </div>
                <Button
                  variant={twoFactorEnabled ? "outline" : "primary"}
                  size="sm"
                  iconName={twoFactorEnabled ? "Settings" : "Plus"}
                  onClick={handleTwoFactorToggle}
                >
                  {twoFactorEnabled ? 'Manage' : 'Enable'}
                </Button>
              </div>
            </div>

            {/* Login Sessions */}
            <div>
              <h4 className="text-base font-medium text-text-primary mb-4">Active Sessions</h4>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-4 bg-surface rounded-lg border border-border">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-primary-50 rounded-lg flex items-center justify-center">
                      <Icon name="Monitor" size={20} className="text-primary-600" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-text-primary">Current Session</p>
                      <p className="text-xs text-text-secondary">Chrome on Windows • New York, US</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-success-500 rounded-full"></div>
                    <span className="text-xs text-text-secondary">Active now</span>
                  </div>
                </div>

                <div className="flex items-center justify-between p-4 bg-surface rounded-lg border border-border">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-secondary-100 rounded-lg flex items-center justify-center">
                      <Icon name="Smartphone" size={20} className="text-secondary-600" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-text-primary">Mobile App</p>
                      <p className="text-xs text-text-secondary">iOS Safari • 2 hours ago</p>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    iconName="LogOut"
                    onClick={() => {}}
                  >
                    Sign Out
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AccountSecuritySection;