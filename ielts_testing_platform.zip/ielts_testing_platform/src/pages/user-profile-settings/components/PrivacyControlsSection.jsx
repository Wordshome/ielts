import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const PrivacyControlsSection = ({ isExpanded, onToggle, privacy, onUpdate }) => {
  const [formData, setFormData] = useState({
    profileVisibility: privacy.profileVisibility || 'private',
    shareProgress: privacy.shareProgress || false,
    allowAnalytics: privacy.allowAnalytics !== false,
    dataCollection: privacy.dataCollection !== false,
    thirdPartySharing: privacy.thirdPartySharing || false,
    marketingConsent: privacy.marketingConsent || false,
    researchParticipation: privacy.researchParticipation || false,
    cookiePreferences: privacy.cookiePreferences || 'essential'
  });

  const [isEditing, setIsEditing] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deleteConfirmText, setDeleteConfirmText] = useState('');

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSave = () => {
    onUpdate('privacy', formData);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setFormData({
      profileVisibility: privacy.profileVisibility || 'private',
      shareProgress: privacy.shareProgress || false,
      allowAnalytics: privacy.allowAnalytics !== false,
      dataCollection: privacy.dataCollection !== false,
      thirdPartySharing: privacy.thirdPartySharing || false,
      marketingConsent: privacy.marketingConsent || false,
      researchParticipation: privacy.researchParticipation || false,
      cookiePreferences: privacy.cookiePreferences || 'essential'
    });
    setIsEditing(false);
  };

  const handleDeleteAccount = () => {
    if (deleteConfirmText === 'DELETE MY ACCOUNT') {
      alert('Account deletion request submitted. You will receive a confirmation email within 24 hours.');
      setShowDeleteConfirm(false);
      setDeleteConfirmText('');
    } else {
      alert('Please type "DELETE MY ACCOUNT" exactly to confirm.');
    }
  };

  const handleExportData = () => {
    alert('Your data export has been initiated. You will receive a download link via email within 24 hours.');
  };

  const visibilityOptions = [
    { value: 'public', label: 'Public', description: 'Your profile is visible to all users' },
    { value: 'friends', label: 'Friends Only', description: 'Only your connections can see your profile' },
    { value: 'private', label: 'Private', description: 'Your profile is completely private' }
  ];

  const cookieOptions = [
    { value: 'essential', label: 'Essential Only', description: 'Only cookies required for basic functionality' },
    { value: 'functional', label: 'Functional', description: 'Essential + cookies that enhance your experience' },
    { value: 'all', label: 'All Cookies', description: 'All cookies including analytics and marketing' }
  ];

  const privacyControls = [
    {
      key: 'shareProgress',
      title: 'Share Progress',
      description: 'Allow others to see your test scores and progress',
      icon: 'TrendingUp',
      category: 'sharing'
    },
    {
      key: 'allowAnalytics',
      title: 'Usage Analytics',
      description: 'Help us improve the platform by sharing anonymous usage data',
      icon: 'BarChart3',
      category: 'data'
    },
    {
      key: 'dataCollection',
      title: 'Performance Data Collection',
      description: 'Collect detailed performance data to provide personalized insights',
      icon: 'Database',
      category: 'data'
    },
    {
      key: 'thirdPartySharing',
      title: 'Third-Party Sharing',
      description: 'Share anonymized data with educational partners for research',
      icon: 'Share2',
      category: 'sharing'
    },
    {
      key: 'marketingConsent',
      title: 'Marketing Communications',
      description: 'Receive personalized marketing content and recommendations',
      icon: 'Mail',
      category: 'marketing'
    },
    {
      key: 'researchParticipation',
      title: 'Research Participation',
      description: 'Participate in educational research studies (optional)',
      icon: 'Search',
      category: 'research'
    }
  ];

  const getControlsByCategory = (category) => {
    return privacyControls.filter(control => control.category === category);
  };

  return (
    <div className="bg-background border border-border rounded-lg shadow-custom-sm">
      <button
        onClick={onToggle}
        className="w-full px-6 py-4 flex items-center justify-between text-left hover:bg-surface transition-colors focus-ring rounded-t-lg"
      >
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-error-50 rounded-lg flex items-center justify-center">
            <Icon name="Shield" size={20} className="text-error-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-text-primary">Privacy Controls</h3>
            <p className="text-sm text-text-secondary">Manage your data privacy and account visibility</p>
          </div>
        </div>
        <Icon 
          name={isExpanded ? "ChevronUp" : "ChevronDown"} 
          size={20} 
          className="text-text-secondary" 
        />
      </button>

      {isExpanded && (
        <div className="px-6 pb-6 border-t border-border">
          <div className="pt-6 space-y-8">
            {/* Profile Visibility */}
            <div>
              <h4 className="text-base font-medium text-text-primary mb-4">Profile Visibility</h4>
              <div className="space-y-3">
                {visibilityOptions.map(option => (
                  <label key={option.value} className="flex items-start space-x-3 cursor-pointer">
                    <input
                      type="radio"
                      name="profileVisibility"
                      value={option.value}
                      checked={formData.profileVisibility === option.value}
                      onChange={(e) => handleInputChange('profileVisibility', e.target.value)}
                      disabled={!isEditing}
                      className="mt-1 w-4 h-4 text-primary-600 border-border focus:ring-primary-500"
                    />
                    <div className="flex-1">
                      <div className="text-sm font-medium text-text-primary">{option.label}</div>
                      <div className="text-xs text-text-secondary">{option.description}</div>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            {/* Data Sharing */}
            <div>
              <h4 className="text-base font-medium text-text-primary mb-4 flex items-center space-x-2">
                <Icon name="Share2" size={16} className="text-primary-600" />
                <span>Data Sharing</span>
              </h4>
              <div className="space-y-4">
                {getControlsByCategory('sharing').map(control => (
                  <div key={control.key} className="flex items-center justify-between p-4 bg-surface rounded-lg border border-border">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-primary-50 rounded-lg flex items-center justify-center">
                        <Icon name={control.icon} size={20} className="text-primary-600" />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-text-primary">{control.title}</div>
                        <div className="text-xs text-text-secondary">{control.description}</div>
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={formData[control.key]}
                      onChange={(e) => handleInputChange(control.key, e.target.checked)}
                      disabled={!isEditing}
                      className="w-4 h-4 text-primary-600 border-border rounded focus:ring-primary-500"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Data Collection */}
            <div>
              <h4 className="text-base font-medium text-text-primary mb-4 flex items-center space-x-2">
                <Icon name="Database" size={16} className="text-accent-600" />
                <span>Data Collection</span>
              </h4>
              <div className="space-y-4">
                {getControlsByCategory('data').map(control => (
                  <div key={control.key} className="flex items-center justify-between p-4 bg-surface rounded-lg border border-border">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-accent-50 rounded-lg flex items-center justify-center">
                        <Icon name={control.icon} size={20} className="text-accent-600" />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-text-primary">{control.title}</div>
                        <div className="text-xs text-text-secondary">{control.description}</div>
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={formData[control.key]}
                      onChange={(e) => handleInputChange(control.key, e.target.checked)}
                      disabled={!isEditing}
                      className="w-4 h-4 text-primary-600 border-border rounded focus:ring-primary-500"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Marketing & Research */}
            <div>
              <h4 className="text-base font-medium text-text-primary mb-4 flex items-center space-x-2">
                <Icon name="Mail" size={16} className="text-warning-600" />
                <span>Marketing & Research</span>
              </h4>
              <div className="space-y-4">
                {[...getControlsByCategory('marketing'), ...getControlsByCategory('research')].map(control => (
                  <div key={control.key} className="flex items-center justify-between p-4 bg-surface rounded-lg border border-border">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-warning-50 rounded-lg flex items-center justify-center">
                        <Icon name={control.icon} size={20} className="text-warning-600" />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-text-primary">{control.title}</div>
                        <div className="text-xs text-text-secondary">{control.description}</div>
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={formData[control.key]}
                      onChange={(e) => handleInputChange(control.key, e.target.checked)}
                      disabled={!isEditing}
                      className="w-4 h-4 text-primary-600 border-border rounded focus:ring-primary-500"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Cookie Preferences */}
            <div>
              <h4 className="text-base font-medium text-text-primary mb-4">Cookie Preferences</h4>
              <div className="space-y-3">
                {cookieOptions.map(option => (
                  <label key={option.value} className="flex items-start space-x-3 cursor-pointer">
                    <input
                      type="radio"
                      name="cookiePreferences"
                      value={option.value}
                      checked={formData.cookiePreferences === option.value}
                      onChange={(e) => handleInputChange('cookiePreferences', e.target.value)}
                      disabled={!isEditing}
                      className="mt-1 w-4 h-4 text-primary-600 border-border focus:ring-primary-500"
                    />
                    <div className="flex-1">
                      <div className="text-sm font-medium text-text-primary">{option.label}</div>
                      <div className="text-xs text-text-secondary">{option.description}</div>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            {/* Data Management */}
            <div>
              <h4 className="text-base font-medium text-text-primary mb-4">Data Management</h4>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-surface rounded-lg border border-border">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-success-50 rounded-lg flex items-center justify-center">
                      <Icon name="Download" size={20} className="text-success-600" />
                    </div>
                    <div>
                      <div className="text-sm font-medium text-text-primary">Export Your Data</div>
                      <div className="text-xs text-text-secondary">Download a copy of all your personal data</div>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="Download"
                    onClick={handleExportData}
                  >
                    Export
                  </Button>
                </div>

                <div className="flex items-center justify-between p-4 bg-error-50 rounded-lg border border-error-200">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-error-100 rounded-lg flex items-center justify-center">
                      <Icon name="Trash2" size={20} className="text-error-600" />
                    </div>
                    <div>
                      <div className="text-sm font-medium text-error-700">Delete Account</div>
                      <div className="text-xs text-error-600">Permanently delete your account and all data</div>
                    </div>
                  </div>
                  <Button
                    variant="danger"
                    size="sm"
                    iconName="Trash2"
                    onClick={() => setShowDeleteConfirm(true)}
                  >
                    Delete
                  </Button>
                </div>
              </div>
            </div>

            {/* Delete Confirmation Modal */}
            {showDeleteConfirm && (
              <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
                <div className="bg-background rounded-lg shadow-custom-lg max-w-md w-full p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="w-12 h-12 bg-error-100 rounded-lg flex items-center justify-center">
                      <Icon name="AlertTriangle" size={24} className="text-error-600" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-text-primary">Delete Account</h3>
                      <p className="text-sm text-text-secondary">This action cannot be undone</p>
                    </div>
                  </div>
                  
                  <div className="mb-6">
                    <p className="text-sm text-text-primary mb-4">
                      This will permanently delete your account and all associated data, including:
                    </p>
                    <ul className="text-sm text-text-secondary space-y-1 mb-4">
                      <li>• All test results and progress history</li>
                      <li>• Personal information and preferences</li>
                      <li>• Account settings and customizations</li>
                      <li>• Any certificates or achievements</li>
                    </ul>
                    <p className="text-sm text-text-primary mb-4">
                      To confirm, please type <strong>"DELETE MY ACCOUNT"</strong> below:
                    </p>
                    <input
                      type="text"
                      value={deleteConfirmText}
                      onChange={(e) => setDeleteConfirmText(e.target.value)}
                      placeholder="Type DELETE MY ACCOUNT"
                      className="w-full px-3 py-2 border border-border rounded-lg bg-background text-text-primary focus:outline-none focus:ring-2 focus:ring-error-500 focus:border-transparent"
                    />
                  </div>
                  
                  <div className="flex flex-col sm:flex-row gap-3">
                    <Button
                      variant="danger"
                      iconName="Trash2"
                      onClick={handleDeleteAccount}
                      disabled={deleteConfirmText !== 'DELETE MY ACCOUNT'}
                      fullWidth
                    >
                      Delete Account
                    </Button>
                    <Button
                      variant="outline"
                      iconName="X"
                      onClick={() => {
                        setShowDeleteConfirm(false);
                        setDeleteConfirmText('');
                      }}
                      fullWidth
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 pt-6 border-t border-border">
              {!isEditing ? (
                <Button
                  variant="primary"
                  iconName="Edit"
                  onClick={() => setIsEditing(true)}
                >
                  Edit Privacy Settings
                </Button>
              ) : (
                <div className="flex flex-col sm:flex-row gap-3">
                  <Button
                    variant="primary"
                    iconName="Save"
                    onClick={handleSave}
                  >
                    Save Changes
                  </Button>
                  <Button
                    variant="outline"
                    iconName="X"
                    onClick={handleCancel}
                  >
                    Cancel
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PrivacyControlsSection;