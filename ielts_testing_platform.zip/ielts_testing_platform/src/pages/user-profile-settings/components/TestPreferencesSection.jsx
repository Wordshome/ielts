import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';


const TestPreferencesSection = ({ isExpanded, onToggle, preferences, onUpdate }) => {
  const [formData, setFormData] = useState({
    defaultTestType: preferences.defaultTestType || 'academic',
    timerSettings: preferences.timerSettings || 'standard',
    autoSave: preferences.autoSave !== false,
    showProgressBar: preferences.showProgressBar !== false,
    enableKeyboardShortcuts: preferences.enableKeyboardShortcuts !== false,
    fontSize: preferences.fontSize || 'medium',
    theme: preferences.theme || 'light',
    audioQuality: preferences.audioQuality || 'high',
    speakingRecordingQuality: preferences.speakingRecordingQuality || 'high',
    accessibilityMode: preferences.accessibilityMode || false,
    screenReaderSupport: preferences.screenReaderSupport || false,
    highContrastMode: preferences.highContrastMode || false
  });

  const [isEditing, setIsEditing] = useState(false);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSave = () => {
    onUpdate('testPreferences', formData);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setFormData({
      defaultTestType: preferences.defaultTestType || 'academic',
      timerSettings: preferences.timerSettings || 'standard',
      autoSave: preferences.autoSave !== false,
      showProgressBar: preferences.showProgressBar !== false,
      enableKeyboardShortcuts: preferences.enableKeyboardShortcuts !== false,
      fontSize: preferences.fontSize || 'medium',
      theme: preferences.theme || 'light',
      audioQuality: preferences.audioQuality || 'high',
      speakingRecordingQuality: preferences.speakingRecordingQuality || 'high',
      accessibilityMode: preferences.accessibilityMode || false,
      screenReaderSupport: preferences.screenReaderSupport || false,
      highContrastMode: preferences.highContrastMode || false
    });
    setIsEditing(false);
  };

  const testTypes = [
    { value: 'academic', label: 'Academic IELTS', description: 'For university admissions and academic purposes' },
    { value: 'general', label: 'General Training IELTS', description: 'For immigration and work purposes' }
  ];

  const timerOptions = [
    { value: 'standard', label: 'Standard Timer', description: 'Official IELTS timing' },
    { value: 'extended', label: 'Extended Timer', description: '25% extra time for accessibility' },
    { value: 'practice', label: 'Practice Mode', description: 'Flexible timing for practice' }
  ];

  const fontSizes = [
    { value: 'small', label: 'Small' },
    { value: 'medium', label: 'Medium' },
    { value: 'large', label: 'Large' },
    { value: 'extra-large', label: 'Extra Large' }
  ];

  const themes = [
    { value: 'light', label: 'Light Theme' },
    { value: 'dark', label: 'Dark Theme' },
    { value: 'auto', label: 'Auto (System)' }
  ];

  const audioQualities = [
    { value: 'standard', label: 'Standard Quality' },
    { value: 'high', label: 'High Quality' },
    { value: 'premium', label: 'Premium Quality' }
  ];

  return (
    <div className="bg-background border border-border rounded-lg shadow-custom-sm">
      <button
        onClick={onToggle}
        className="w-full px-6 py-4 flex items-center justify-between text-left hover:bg-surface transition-colors focus-ring rounded-t-lg"
      >
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-accent-50 rounded-lg flex items-center justify-center">
            <Icon name="Settings" size={20} className="text-accent-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-text-primary">Test Preferences</h3>
            <p className="text-sm text-text-secondary">Customize your test-taking experience</p>
          </div>
        </div>
        <Icon 
          name={isExpanded ? "ChevronUp" : "ChevronDown"} 
          size={20} 
          className="text-text-secondary" 
        />
      </button>

      {isExpanded && (
        <div className="px-6 pb-6 border-t border-border">
          <div className="pt-6 space-y-8">
            {/* Test Type Preference */}
            <div>
              <h4 className="text-base font-medium text-text-primary mb-4">Default Test Type</h4>
              <div className="space-y-3">
                {testTypes.map(type => (
                  <label key={type.value} className="flex items-start space-x-3 cursor-pointer">
                    <input
                      type="radio"
                      name="testType"
                      value={type.value}
                      checked={formData.defaultTestType === type.value}
                      onChange={(e) => handleInputChange('defaultTestType', e.target.value)}
                      disabled={!isEditing}
                      className="mt-1 w-4 h-4 text-primary-600 border-border focus:ring-primary-500"
                    />
                    <div className="flex-1">
                      <div className="text-sm font-medium text-text-primary">{type.label}</div>
                      <div className="text-xs text-text-secondary">{type.description}</div>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            {/* Timer Settings */}
            <div>
              <h4 className="text-base font-medium text-text-primary mb-4">Timer Settings</h4>
              <div className="space-y-3">
                {timerOptions.map(option => (
                  <label key={option.value} className="flex items-start space-x-3 cursor-pointer">
                    <input
                      type="radio"
                      name="timerSettings"
                      value={option.value}
                      checked={formData.timerSettings === option.value}
                      onChange={(e) => handleInputChange('timerSettings', e.target.value)}
                      disabled={!isEditing}
                      className="mt-1 w-4 h-4 text-primary-600 border-border focus:ring-primary-500"
                    />
                    <div className="flex-1">
                      <div className="text-sm font-medium text-text-primary">{option.label}</div>
                      <div className="text-xs text-text-secondary">{option.description}</div>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            {/* Interface Preferences */}
            <div>
              <h4 className="text-base font-medium text-text-primary mb-4">Interface Preferences</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-2">
                    Font Size
                  </label>
                  <select
                    value={formData.fontSize}
                    onChange={(e) => handleInputChange('fontSize', e.target.value)}
                    disabled={!isEditing}
                    className="w-full px-3 py-2 border border-border rounded-lg bg-background text-text-primary focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent disabled:bg-secondary-50 disabled:text-text-muted"
                  >
                    {fontSizes.map(size => (
                      <option key={size.value} value={size.value}>{size.label}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-text-primary mb-2">
                    Theme
                  </label>
                  <select
                    value={formData.theme}
                    onChange={(e) => handleInputChange('theme', e.target.value)}
                    disabled={!isEditing}
                    className="w-full px-3 py-2 border border-border rounded-lg bg-background text-text-primary focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent disabled:bg-secondary-50 disabled:text-text-muted"
                  >
                    {themes.map(theme => (
                      <option key={theme.value} value={theme.value}>{theme.label}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Audio Settings */}
            <div>
              <h4 className="text-base font-medium text-text-primary mb-4">Audio Settings</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-2">
                    Listening Audio Quality
                  </label>
                  <select
                    value={formData.audioQuality}
                    onChange={(e) => handleInputChange('audioQuality', e.target.value)}
                    disabled={!isEditing}
                    className="w-full px-3 py-2 border border-border rounded-lg bg-background text-text-primary focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent disabled:bg-secondary-50 disabled:text-text-muted"
                  >
                    {audioQualities.map(quality => (
                      <option key={quality.value} value={quality.value}>{quality.label}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-text-primary mb-2">
                    Speaking Recording Quality
                  </label>
                  <select
                    value={formData.speakingRecordingQuality}
                    onChange={(e) => handleInputChange('speakingRecordingQuality', e.target.value)}
                    disabled={!isEditing}
                    className="w-full px-3 py-2 border border-border rounded-lg bg-background text-text-primary focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent disabled:bg-secondary-50 disabled:text-text-muted"
                  >
                    {audioQualities.map(quality => (
                      <option key={quality.value} value={quality.value}>{quality.label}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Feature Toggles */}
            <div>
              <h4 className="text-base font-medium text-text-primary mb-4">Features</h4>
              <div className="space-y-4">
                <label className="flex items-center justify-between cursor-pointer">
                  <div>
                    <div className="text-sm font-medium text-text-primary">Auto-save Progress</div>
                    <div className="text-xs text-text-secondary">Automatically save your answers as you type</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={formData.autoSave}
                    onChange={(e) => handleInputChange('autoSave', e.target.checked)}
                    disabled={!isEditing}
                    className="w-4 h-4 text-primary-600 border-border rounded focus:ring-primary-500"
                  />
                </label>

                <label className="flex items-center justify-between cursor-pointer">
                  <div>
                    <div className="text-sm font-medium text-text-primary">Show Progress Bar</div>
                    <div className="text-xs text-text-secondary">Display test progress indicator</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={formData.showProgressBar}
                    onChange={(e) => handleInputChange('showProgressBar', e.target.checked)}
                    disabled={!isEditing}
                    className="w-4 h-4 text-primary-600 border-border rounded focus:ring-primary-500"
                  />
                </label>

                <label className="flex items-center justify-between cursor-pointer">
                  <div>
                    <div className="text-sm font-medium text-text-primary">Keyboard Shortcuts</div>
                    <div className="text-xs text-text-secondary">Enable keyboard shortcuts for navigation</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={formData.enableKeyboardShortcuts}
                    onChange={(e) => handleInputChange('enableKeyboardShortcuts', e.target.checked)}
                    disabled={!isEditing}
                    className="w-4 h-4 text-primary-600 border-border rounded focus:ring-primary-500"
                  />
                </label>
              </div>
            </div>

            {/* Accessibility Options */}
            <div>
              <h4 className="text-base font-medium text-text-primary mb-4">Accessibility</h4>
              <div className="space-y-4">
                <label className="flex items-center justify-between cursor-pointer">
                  <div>
                    <div className="text-sm font-medium text-text-primary">Accessibility Mode</div>
                    <div className="text-xs text-text-secondary">Enable enhanced accessibility features</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={formData.accessibilityMode}
                    onChange={(e) => handleInputChange('accessibilityMode', e.target.checked)}
                    disabled={!isEditing}
                    className="w-4 h-4 text-primary-600 border-border rounded focus:ring-primary-500"
                  />
                </label>

                <label className="flex items-center justify-between cursor-pointer">
                  <div>
                    <div className="text-sm font-medium text-text-primary">Screen Reader Support</div>
                    <div className="text-xs text-text-secondary">Optimize for screen reader compatibility</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={formData.screenReaderSupport}
                    onChange={(e) => handleInputChange('screenReaderSupport', e.target.checked)}
                    disabled={!isEditing}
                    className="w-4 h-4 text-primary-600 border-border rounded focus:ring-primary-500"
                  />
                </label>

                <label className="flex items-center justify-between cursor-pointer">
                  <div>
                    <div className="text-sm font-medium text-text-primary">High Contrast Mode</div>
                    <div className="text-xs text-text-secondary">Increase contrast for better visibility</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={formData.highContrastMode}
                    onChange={(e) => handleInputChange('highContrastMode', e.target.checked)}
                    disabled={!isEditing}
                    className="w-4 h-4 text-primary-600 border-border rounded focus:ring-primary-500"
                  />
                </label>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 pt-6 border-t border-border">
              {!isEditing ? (
                <Button
                  variant="primary"
                  iconName="Edit"
                  onClick={() => setIsEditing(true)}
                >
                  Edit Preferences
                </Button>
              ) : (
                <div className="flex flex-col sm:flex-row gap-3">
                  <Button
                    variant="primary"
                    iconName="Save"
                    onClick={handleSave}
                  >
                    Save Changes
                  </Button>
                  <Button
                    variant="outline"
                    iconName="X"
                    onClick={handleCancel}
                  >
                    Cancel
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TestPreferencesSection;