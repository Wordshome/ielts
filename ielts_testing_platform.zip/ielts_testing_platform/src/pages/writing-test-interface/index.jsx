import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import AdaptiveHeader from '../../components/ui/AdaptiveHeader';
import TestProgressBar from '../../components/ui/TestProgressBar';
import TestTimer from '../../components/ui/TestTimer';
import TaskInstructions from './components/TaskInstructions';
import WritingEditor from './components/WritingEditor';
import PlanningArea from './components/PlanningArea';
import ReviewMode from './components/ReviewMode';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const WritingTestInterface = () => {
  const navigate = useNavigate();
  const [currentTask, setCurrentTask] = useState(1);
  const [taskContents, setTaskContents] = useState({
    1: '',
    2: ''
  });
  const [planningNotes, setPlanningNotes] = useState({
    outline: '',
    ideas: '',
    vocabulary: ''
  });
  const [autoSaveStatus, setAutoSaveStatus] = useState('saved');
  const [isSpellCheckEnabled, setIsSpellCheckEnabled] = useState(true);
  const [isPlanningVisible, setIsPlanningVisible] = useState(false);
  const [isReviewMode, setIsReviewMode] = useState(false);
  const [highlights, setHighlights] = useState([]);
  const [testStartTime] = useState(Date.now());
  const [timeRemaining, setTimeRemaining] = useState(3600); // 60 minutes total

  const tasks = [
    {
      id: 1,
      timeLimit: 20,
      wordCount: 150,
      overview: `You should spend about 20 minutes on this task.\n\nThe chart below shows the percentage of households in owned and rented accommodation in England and Wales between 1918 and 2011.\n\nSummarize the information by selecting and reporting the main features, and make comparisons where relevant.`,
      detailedInstructions: [
        "Write at least 150 words describing the chart or diagram provided.",
        "Focus on the main trends, differences, or stages shown in the visual data.",
        "Make relevant comparisons between different categories or time periods.",
        "Do not give your opinion or speculate about reasons - just describe what you see.",
        "Use appropriate vocabulary for describing data and trends."
      ],
      assessmentCriteria: [
        "Task Achievement (25%)",
        "Coherence and Cohesion (25%)",
        "Lexical Resource (25%)",
        "Grammatical Range and Accuracy (25%)"
      ],
      samplePrompt: "The bar chart illustrates the changes in housing ownership patterns in England and Wales from 1918 to 2011, showing the proportion of households in owned versus rented accommodation."
    },
    {
      id: 2,
      timeLimit: 40,
      wordCount: 250,
      overview: `You should spend about 40 minutes on this task.\n\nWrite about the following topic:\n\nSome people think that all university students should study whatever they like. Others believe that they should only be allowed to study subjects that will be useful in the future, such as those related to science and technology.\n\nDiscuss both these views and give your own opinion.`,
      detailedInstructions: [
        "Write at least 250 words presenting a clear argument on the given topic.",
        "Discuss both viewpoints mentioned in the question thoroughly.",
        "Provide your own opinion with supporting reasons and examples.",
        "Structure your essay with clear introduction, body paragraphs, and conclusion.",
        "Use formal academic language and avoid contractions or informal expressions."
      ],
      assessmentCriteria: [
        "Task Response (25%)",
        "Coherence and Cohesion (25%)",
        "Lexical Resource (25%)",
        "Grammatical Range and Accuracy (25%)"
      ],
      samplePrompt: "In today's rapidly evolving world, the debate over university curriculum freedom versus practical subject focus has become increasingly relevant for educational policy makers."
    }
  ];

  // Auto-save functionality
  useEffect(() => {
    const autoSaveInterval = setInterval(() => {
      if (taskContents[currentTask] || Object.values(planningNotes).some(note => note)) {
        setAutoSaveStatus('saving');
        
        // Simulate save operation
        setTimeout(() => {
          setAutoSaveStatus('saved');
        }, 1000);
      }
    }, 30000); // Auto-save every 30 seconds

    return () => clearInterval(autoSaveInterval);
  }, [taskContents, planningNotes, currentTask]);

  // Word count calculation
  const getWordCount = useCallback((text) => {
    if (!text) return 0;
    return text.trim().split(/\s+/).filter(word => word.length > 0).length;
  }, []);

  const handleTaskChange = (taskId) => {
    setCurrentTask(taskId);
    setIsReviewMode(false);
  };

  const handleContentChange = (content) => {
    setTaskContents(prev => ({
      ...prev,
      [currentTask]: content
    }));
    setAutoSaveStatus('unsaved');
  };

  const handleNotesChange = (noteType, content) => {
    setPlanningNotes(prev => ({
      ...prev,
      [noteType]: content
    }));
  };

  const handleSave = () => {
    setAutoSaveStatus('saving');
    
    // Simulate save operation
    setTimeout(() => {
      setAutoSaveStatus('saved');
    }, 1000);
  };

  const handleSpellCheckToggle = () => {
    setIsSpellCheckEnabled(!isSpellCheckEnabled);
  };

  const handlePlanningToggle = () => {
    setIsPlanningVisible(!isPlanningVisible);
  };

  const handleReviewToggle = () => {
    setIsReviewMode(!isReviewMode);
  };

  const handleHighlight = (type) => {
    // Implementation for text highlighting
    console.log('Highlighting:', type);
  };

  const handleTimeUp = () => {
    // Auto-submit when time is up
    navigate('/test-results-dashboard');
  };

  const handleTimeWarning = (remainingTime) => {
    // Show warning notifications
    if (remainingTime === 300) {
      // 5 minutes warning
      alert('5 minutes remaining!');
    } else if (remainingTime === 60) {
      // 1 minute warning
      alert('1 minute remaining!');
    }
  };

  const handleSubmitTest = () => {
    if (window.confirm('Are you sure you want to submit your writing test? This action cannot be undone.')) {
      navigate('/test-results-dashboard');
    }
  };

  const handleNextSection = () => {
    navigate('/speaking-test-interface');
  };

  const currentTaskData = tasks.find(task => task.id === currentTask);
  const currentWordCount = getWordCount(taskContents[currentTask]);
  const sectionProgress = Math.min((currentWordCount / currentTaskData.wordCount) * 100, 100);

  return (
    <div className="min-h-screen bg-surface">
      <AdaptiveHeader />
      
      <TestProgressBar 
        currentSection={2}
        totalSections={4}
        sectionProgress={sectionProgress}
        timeRemaining={timeRemaining}
        totalTime={3600}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Main Content Area */}
          <div className="lg:col-span-8 space-y-6">
            {/* Task Instructions */}
            <TaskInstructions
              currentTask={currentTask}
              onTaskChange={handleTaskChange}
              tasks={tasks}
            />

            {/* Writing Editor */}
            <WritingEditor
              content={taskContents[currentTask]}
              onChange={handleContentChange}
              placeholder={`Start writing your response for Task ${currentTask}...\n\nRemember to:\n• Address all parts of the task\n• Organize your ideas clearly\n• Use appropriate vocabulary and grammar\n• Write at least ${currentTaskData.wordCount} words`}
              wordCount={currentWordCount}
              targetWordCount={currentTaskData.wordCount}
              onSave={handleSave}
              autoSaveStatus={autoSaveStatus}
              isSpellCheckEnabled={isSpellCheckEnabled}
              onSpellCheckToggle={handleSpellCheckToggle}
            />

            {/* Mobile Action Buttons */}
            <div className="lg:hidden flex flex-wrap gap-2">
              <Button
                variant="outline"
                size="sm"
                iconName="FileText"
                onClick={handlePlanningToggle}
              >
                Planning
              </Button>
              <Button
                variant="outline"
                size="sm"
                iconName="Eye"
                onClick={handleReviewToggle}
              >
                Review
              </Button>
              <Button
                variant="secondary"
                size="sm"
                iconName="Save"
                onClick={handleSave}
              >
                Save
              </Button>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-4 space-y-6">
            {/* Timer */}
            <TestTimer
              initialTime={3600}
              onTimeUp={handleTimeUp}
              onTimeWarning={handleTimeWarning}
              warningThreshold={300}
              criticalThreshold={60}
              sectionName="Writing Test"
            />

            {/* Task Progress */}
            <div className="bg-white border border-secondary-200 rounded-lg shadow-custom-sm p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-medium text-text-primary">Task Progress</h3>
                <Icon name="Target" size={16} className="text-primary-600" />
              </div>
              
              <div className="space-y-3">
                {tasks.map((task) => {
                  const taskWordCount = getWordCount(taskContents[task.id]);
                  const taskProgress = Math.min((taskWordCount / task.wordCount) * 100, 100);
                  
                  return (
                    <div key={task.id} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-text-secondary">Task {task.id}</span>
                        <span className="text-sm font-medium text-text-primary">
                          {taskWordCount}/{task.wordCount}
                        </span>
                      </div>
                      <div className="w-full bg-secondary-100 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full transition-all duration-300 ${
                            taskProgress >= 100 ? 'bg-success-500' :
                            taskProgress >= 80 ? 'bg-primary-500' :
                            taskProgress >= 60 ? 'bg-accent-500' :
                            taskProgress >= 40 ? 'bg-warning-500' : 'bg-error-500'
                          }`}
                          style={{ width: `${taskProgress}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Desktop Planning Area */}
            <div className="hidden lg:block">
              <PlanningArea
                notes={planningNotes}
                onNotesChange={handleNotesChange}
                isVisible={true}
                onToggle={handlePlanningToggle}
              />
            </div>

            {/* Desktop Review Mode */}
            <div className="hidden lg:block">
              <ReviewMode
                content={taskContents[currentTask]}
                isActive={true}
                onToggle={handleReviewToggle}
                onHighlight={handleHighlight}
                highlights={highlights}
              />
            </div>

            {/* Test Actions */}
            <div className="bg-white border border-secondary-200 rounded-lg shadow-custom-sm p-4">
              <div className="space-y-3">
                <Button
                  variant="primary"
                  fullWidth
                  iconName="ArrowRight"
                  iconPosition="right"
                  onClick={handleNextSection}
                >
                  Continue to Speaking
                </Button>
                
                <Button
                  variant="outline"
                  fullWidth
                  iconName="Upload"
                  onClick={handleSubmitTest}
                >
                  Submit Writing Test
                </Button>
                
                <Button
                  variant="ghost"
                  fullWidth
                  iconName="Pause"
                  onClick={() => navigate('/test-results-dashboard')}
                >
                  Pause & Exit
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Planning Area */}
      <div className="lg:hidden">
        <PlanningArea
          notes={planningNotes}
          onNotesChange={handleNotesChange}
          isVisible={isPlanningVisible}
          onToggle={handlePlanningToggle}
        />
      </div>

      {/* Mobile Review Mode */}
      <div className="lg:hidden">
        <ReviewMode
          content={taskContents[currentTask]}
          isActive={isReviewMode}
          onToggle={handleReviewToggle}
          onHighlight={handleHighlight}
          highlights={highlights}
        />
      </div>
    </div>
  );
};

export default WritingTestInterface;