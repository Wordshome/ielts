import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const PlanningArea = ({ notes, onNotesChange, isVisible, onToggle }) => {
  const [activeTab, setActiveTab] = useState('outline');

  const planningTabs = [
    { id: 'outline', label: 'Outline', icon: 'List' },
    { id: 'ideas', label: 'Ideas', icon: 'Lightbulb' },
    { id: 'vocabulary', label: 'Vocabulary', icon: 'BookOpen' }
  ];

  const insertTemplate = (template) => {
    const templates = {
      essay: `Introduction:\n- Hook:\n- Background:\n- Thesis statement:\n\nBody Paragraph 1:\n- Topic sentence:\n- Supporting evidence:\n- Analysis:\n\nBody Paragraph 2:\n- Topic sentence:\n- Supporting evidence:\n- Analysis:\n\nConclusion:\n- Restate thesis:\n- Summary of main points:\n- Final thought:`,
      report: `Overview:\n- Main trend/feature:\n- Key statistics:\n\nDetailed Analysis:\n- Significant changes:\n- Comparisons:\n- Notable patterns:\n\nConclusion:\n- Summary of findings:`,
      letter: `Opening:\n- Purpose of writing:\n- Context:\n\nMain Content:\n- Key points to address:\n- Supporting details:\n\nClosing:\n- Next steps/requests:\n- Appropriate sign-off:`
    };

    const currentNotes = notes[activeTab] || '';
    const newNotes = currentNotes + (currentNotes ? '\n\n' : '') + templates[template];
    onNotesChange(activeTab, newNotes);
  };

  if (!isVisible) {
    return (
      <div className="fixed bottom-4 right-4 z-40">
        <Button
          variant="primary"
          size="sm"
          iconName="FileText"
          onClick={onToggle}
          className="shadow-custom-lg"
        >
          Planning
        </Button>
      </div>
    );
  }

  return (
    <div className="bg-white border border-secondary-200 rounded-lg shadow-custom-sm">
      <div className="flex items-center justify-between p-3 border-b border-secondary-200">
        <div className="flex items-center space-x-2">
          <Icon name="FileText" size={16} className="text-primary-600" />
          <h3 className="text-sm font-medium text-text-primary">Planning Area</h3>
        </div>
        
        <Button
          variant="ghost"
          size="sm"
          iconName="X"
          onClick={onToggle}
          className="w-6 h-6"
          aria-label="Close planning area"
        />
      </div>

      {/* Tabs */}
      <div className="flex border-b border-secondary-200">
        {planningTabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex-1 flex items-center justify-center space-x-2 px-3 py-2 text-sm font-medium transition-colors focus-ring ${
              activeTab === tab.id
                ? 'text-primary-600 border-b-2 border-primary-600 bg-primary-50' :'text-text-secondary hover:text-text-primary hover:bg-surface'
            }`}
          >
            <Icon name={tab.icon} size={14} />
            <span className="hidden sm:inline">{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Content Area */}
      <div className="p-3">
        {activeTab === 'outline' && (
          <div className="space-y-3">
            <div className="flex flex-wrap gap-2">
              <Button
                variant="outline"
                size="xs"
                onClick={() => insertTemplate('essay')}
              >
                Essay Template
              </Button>
              <Button
                variant="outline"
                size="xs"
                onClick={() => insertTemplate('report')}
              >
                Report Template
              </Button>
              <Button
                variant="outline"
                size="xs"
                onClick={() => insertTemplate('letter')}
              >
                Letter Template
              </Button>
            </div>
            
            <textarea
              value={notes.outline || ''}
              onChange={(e) => onNotesChange('outline', e.target.value)}
              placeholder="Create your essay outline here...\n\n• Introduction\n• Main points\n• Supporting evidence\n• Conclusion"
              className="w-full h-32 p-2 text-sm border border-secondary-200 rounded-md resize-none focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
            />
          </div>
        )}

        {activeTab === 'ideas' && (
          <div className="space-y-3">
            <div className="text-xs text-text-secondary">
              Brainstorm your ideas and key points
            </div>
            
            <textarea
              value={notes.ideas || ''}
              onChange={(e) => onNotesChange('ideas', e.target.value)}
              placeholder="Jot down your ideas...\n\n• Key arguments\n• Examples\n• Personal experiences\n• Statistics or facts"
              className="w-full h-32 p-2 text-sm border border-secondary-200 rounded-md resize-none focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
            />
          </div>
        )}

        {activeTab === 'vocabulary' && (
          <div className="space-y-3">
            <div className="text-xs text-text-secondary">
              Note useful vocabulary and phrases
            </div>
            
            <textarea
              value={notes.vocabulary || ''}
              onChange={(e) => onNotesChange('vocabulary', e.target.value)}
              placeholder="Useful vocabulary...\n\n• Linking words\n• Academic phrases\n• Topic-specific terms\n• Synonyms"
              className="w-full h-32 p-2 text-sm border border-secondary-200 rounded-md resize-none focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
            />
          </div>
        )}

        {/* Quick Actions */}
        <div className="flex items-center justify-between mt-3 pt-3 border-t border-secondary-200">
          <div className="text-xs text-text-muted">
            Auto-saved
          </div>
          
          <Button
            variant="ghost"
            size="xs"
            iconName="RotateCcw"
            onClick={() => onNotesChange(activeTab, '')}
          >
            Clear
          </Button>
        </div>
      </div>
    </div>
  );
};

export default PlanningArea;