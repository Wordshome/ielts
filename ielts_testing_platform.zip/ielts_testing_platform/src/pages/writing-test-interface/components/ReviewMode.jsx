import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ReviewMode = ({ content, isActive, onToggle, onHighlight, highlights = [] }) => {
  const [selectedIssues, setSelectedIssues] = useState([]);
  const [reviewStats, setReviewStats] = useState({
    wordCount: 0,
    sentenceCount: 0,
    paragraphCount: 0,
    readingTime: 0
  });

  useEffect(() => {
    if (content) {
      const words = content.trim().split(/\s+/).filter(word => word.length > 0);
      const sentences = content.split(/[.!?]+/).filter(s => s.trim().length > 0);
      const paragraphs = content.split(/\n\s*\n/).filter(p => p.trim().length > 0);
      const readingTime = Math.ceil(words.length / 200); // Average reading speed

      setReviewStats({
        wordCount: words.length,
        sentenceCount: sentences.length,
        paragraphCount: paragraphs.length,
        readingTime
      });
    }
  }, [content]);

  const commonIssues = [
    {
      id: 'grammar',
      label: 'Grammar Check',
      icon: 'CheckCircle',
      description: 'Review subject-verb agreement, tenses, and sentence structure',
      color: 'text-error-600'
    },
    {
      id: 'spelling',
      label: 'Spelling',
      icon: 'Spellcheck',
      description: 'Check for spelling errors and typos',
      color: 'text-warning-600'
    },
    {
      id: 'punctuation',
      label: 'Punctuation',
      icon: 'Quote',
      description: 'Verify commas, periods, and other punctuation marks',
      color: 'text-accent-600'
    },
    {
      id: 'coherence',
      label: 'Coherence',
      icon: 'Link',
      description: 'Check logical flow and transitions between ideas',
      color: 'text-primary-600'
    },
    {
      id: 'vocabulary',
      label: 'Vocabulary',
      icon: 'BookOpen',
      description: 'Review word choice and variety',
      color: 'text-success-600'
    }
  ];

  const toggleIssueSelection = (issueId) => {
    setSelectedIssues(prev => 
      prev.includes(issueId) 
        ? prev.filter(id => id !== issueId)
        : [...prev, issueId]
    );
  };

  const handleHighlightText = (type) => {
    // This would integrate with text selection in the main editor
    onHighlight(type);
  };

  if (!isActive) {
    return (
      <div className="fixed bottom-4 left-4 z-40">
        <Button
          variant="secondary"
          size="sm"
          iconName="Eye"
          onClick={onToggle}
          className="shadow-custom-lg"
        >
          Review
        </Button>
      </div>
    );
  }

  return (
    <div className="bg-white border border-secondary-200 rounded-lg shadow-custom-sm">
      <div className="flex items-center justify-between p-3 border-b border-secondary-200">
        <div className="flex items-center space-x-2">
          <Icon name="Eye" size={16} className="text-secondary-600" />
          <h3 className="text-sm font-medium text-text-primary">Review Mode</h3>
        </div>
        
        <Button
          variant="ghost"
          size="sm"
          iconName="X"
          onClick={onToggle}
          className="w-6 h-6"
          aria-label="Close review mode"
        />
      </div>

      {/* Statistics */}
      <div className="p-3 border-b border-secondary-200">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="text-center">
            <div className="text-lg font-semibold text-text-primary">{reviewStats.wordCount}</div>
            <div className="text-xs text-text-secondary">Words</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-semibold text-text-primary">{reviewStats.sentenceCount}</div>
            <div className="text-xs text-text-secondary">Sentences</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-semibold text-text-primary">{reviewStats.paragraphCount}</div>
            <div className="text-xs text-text-secondary">Paragraphs</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-semibold text-text-primary">{reviewStats.readingTime}m</div>
            <div className="text-xs text-text-secondary">Read Time</div>
          </div>
        </div>
      </div>

      {/* Review Checklist */}
      <div className="p-3">
        <h4 className="text-sm font-medium text-text-primary mb-3">Review Checklist</h4>
        
        <div className="space-y-2">
          {commonIssues.map((issue) => (
            <div
              key={issue.id}
              className={`flex items-start space-x-3 p-2 rounded-lg border transition-colors cursor-pointer ${
                selectedIssues.includes(issue.id)
                  ? 'border-primary-200 bg-primary-50' :'border-secondary-200 hover:bg-surface'
              }`}
              onClick={() => toggleIssueSelection(issue.id)}
            >
              <div className={`w-5 h-5 rounded border-2 flex items-center justify-center mt-0.5 ${
                selectedIssues.includes(issue.id)
                  ? 'border-primary-500 bg-primary-500' :'border-secondary-300'
              }`}>
                {selectedIssues.includes(issue.id) && (
                  <Icon name="Check" size={12} className="text-white" />
                )}
              </div>
              
              <div className="flex-1">
                <div className="flex items-center space-x-2">
                  <Icon name={issue.icon} size={14} className={issue.color} />
                  <span className="text-sm font-medium text-text-primary">{issue.label}</span>
                </div>
                <p className="text-xs text-text-secondary mt-1">{issue.description}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Highlighting Tools */}
        <div className="mt-4 pt-3 border-t border-secondary-200">
          <h4 className="text-sm font-medium text-text-primary mb-2">Highlighting Tools</h4>
          
          <div className="flex flex-wrap gap-2">
            <Button
              variant="outline"
              size="xs"
              iconName="Highlighter"
              onClick={() => handleHighlightText('error')}
              className="text-error-600 border-error-200 hover:bg-error-50"
            >
              Error
            </Button>
            <Button
              variant="outline"
              size="xs"
              iconName="Highlighter"
              onClick={() => handleHighlightText('improvement')}
              className="text-warning-600 border-warning-200 hover:bg-warning-50"
            >
              Improve
            </Button>
            <Button
              variant="outline"
              size="xs"
              iconName="Highlighter"
              onClick={() => handleHighlightText('good')}
              className="text-success-600 border-success-200 hover:bg-success-50"
            >
              Good
            </Button>
            <Button
              variant="ghost"
              size="xs"
              iconName="Eraser"
              onClick={() => handleHighlightText('clear')}
            >
              Clear
            </Button>
          </div>
        </div>

        {/* Review Summary */}
        <div className="mt-4 pt-3 border-t border-secondary-200">
          <div className="flex items-center justify-between">
            <div className="text-sm text-text-secondary">
              {selectedIssues.length} of {commonIssues.length} items reviewed
            </div>
            
            <div className="flex items-center space-x-2">
              <div className="w-16 bg-secondary-100 rounded-full h-2">
                <div 
                  className="h-2 bg-primary-500 rounded-full transition-all duration-300"
                  style={{ width: `${(selectedIssues.length / commonIssues.length) * 100}%` }}
                />
              </div>
              <span className="text-xs text-text-secondary">
                {Math.round((selectedIssues.length / commonIssues.length) * 100)}%
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReviewMode;