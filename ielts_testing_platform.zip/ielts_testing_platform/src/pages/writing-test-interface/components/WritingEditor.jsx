import React, { useState, useEffect, useRef } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const WritingEditor = ({ 
  content, 
  onChange, 
  placeholder, 
  wordCount, 
  targetWordCount, 
  onSave,
  autoSaveStatus,
  isSpellCheckEnabled,
  onSpellCheckToggle 
}) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [selectedText, setSelectedText] = useState('');
  const textareaRef = useRef(null);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
    }
  }, [content]);

  const handleTextSelection = () => {
    if (textareaRef.current) {
      const start = textareaRef.current.selectionStart;
      const end = textareaRef.current.selectionEnd;
      const selected = content.substring(start, end);
      setSelectedText(selected);
    }
  };

  const insertText = (textToInsert) => {
    if (textareaRef.current) {
      const start = textareaRef.current.selectionStart;
      const end = textareaRef.current.selectionEnd;
      const newContent = content.substring(0, start) + textToInsert + content.substring(end);
      onChange(newContent);
      
      // Restore cursor position
      setTimeout(() => {
        textareaRef.current.selectionStart = start + textToInsert.length;
        textareaRef.current.selectionEnd = start + textToInsert.length;
        textareaRef.current.focus();
      }, 0);
    }
  };

  const formatText = (format) => {
    if (!selectedText) return;
    
    let formattedText = selectedText;
    switch (format) {
      case 'bold':
        formattedText = `**${selectedText}**`;
        break;
      case 'italic':
        formattedText = `*${selectedText}*`;
        break;
      case 'underline':
        formattedText = `_${selectedText}_`;
        break;
      default:
        break;
    }
    
    insertText(formattedText);
  };

  const getWordCountColor = () => {
    const percentage = (wordCount / targetWordCount) * 100;
    if (percentage < 80) return 'text-error-600';
    if (percentage < 95) return 'text-warning-600';
    if (percentage > 120) return 'text-warning-600';
    return 'text-success-600';
  };

  const getWordCountStatus = () => {
    const percentage = (wordCount / targetWordCount) * 100;
    if (percentage < 80) return 'Below minimum';
    if (percentage < 95) return 'Approaching target';
    if (percentage > 120) return 'Exceeding recommended';
    return 'Target achieved';
  };

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  return (
    <div className={`bg-white border border-secondary-200 rounded-lg shadow-custom-sm ${
      isFullscreen ? 'fixed inset-4 z-50' : ''
    }`}>
      {/* Toolbar */}
      <div className="flex items-center justify-between p-3 border-b border-secondary-200">
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            iconName="Bold"
            onClick={() => formatText('bold')}
            disabled={!selectedText}
            className="w-8 h-8"
            aria-label="Bold"
          />
          <Button
            variant="ghost"
            size="sm"
            iconName="Italic"
            onClick={() => formatText('italic')}
            disabled={!selectedText}
            className="w-8 h-8"
            aria-label="Italic"
          />
          <Button
            variant="ghost"
            size="sm"
            iconName="Underline"
            onClick={() => formatText('underline')}
            disabled={!selectedText}
            className="w-8 h-8"
            aria-label="Underline"
          />
          
          <div className="w-px h-6 bg-secondary-200 mx-2" />
          
          <Button
            variant={isSpellCheckEnabled ? "primary" : "ghost"}
            size="sm"
            iconName="CheckCircle"
            onClick={onSpellCheckToggle}
            className="w-8 h-8"
            aria-label="Toggle spell check"
          />
        </div>

        <div className="flex items-center space-x-3">
          {/* Auto-save Status */}
          <div className="flex items-center space-x-2">
            <div className={`w-2 h-2 rounded-full ${
              autoSaveStatus === 'saving' ? 'bg-warning-500 animate-pulse' :
              autoSaveStatus === 'saved' ? 'bg-success-500' :
              autoSaveStatus === 'error' ? 'bg-error-500' : 'bg-secondary-300'
            }`} />
            <span className="text-xs text-text-secondary">
              {autoSaveStatus === 'saving' ? 'Saving...' :
               autoSaveStatus === 'saved' ? 'Saved' :
               autoSaveStatus === 'error' ? 'Save failed' : 'Not saved'}
            </span>
          </div>

          <Button
            variant="ghost"
            size="sm"
            iconName={isFullscreen ? "Minimize2" : "Maximize2"}
            onClick={toggleFullscreen}
            className="w-8 h-8"
            aria-label={isFullscreen ? "Exit fullscreen" : "Enter fullscreen"}
          />
        </div>
      </div>

      {/* Writing Area */}
      <div className="p-4">
        <textarea
          ref={textareaRef}
          value={content}
          onChange={(e) => onChange(e.target.value)}
          onSelect={handleTextSelection}
          placeholder={placeholder}
          spellCheck={isSpellCheckEnabled}
          className={`w-full resize-none border-none outline-none text-text-primary placeholder-text-muted leading-relaxed ${
            isFullscreen ? 'min-h-[calc(100vh-200px)]' : 'min-h-[400px]'
          } text-base md:text-lg`}
          style={{ fontFamily: 'var(--font-body)' }}
        />
      </div>

      {/* Word Count and Status */}
      <div className="flex items-center justify-between p-4 border-t border-secondary-200 bg-surface">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <Icon name="Type" size={16} className="text-text-secondary" />
            <span className={`text-sm font-medium ${getWordCountColor()}`}>
              {wordCount} / {targetWordCount} words
            </span>
          </div>
          
          <div className="text-xs text-text-secondary">
            {getWordCountStatus()}
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            iconName="Save"
            onClick={onSave}
          >
            Save Draft
          </Button>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="px-4 pb-4">
        <div className="w-full bg-secondary-100 rounded-full h-2">
          <div 
            className={`h-2 rounded-full transition-all duration-300 ${
              wordCount < targetWordCount * 0.8 ? 'bg-error-500' :
              wordCount < targetWordCount * 0.95 ? 'bg-warning-500' :
              wordCount > targetWordCount * 1.2 ? 'bg-warning-500' : 'bg-success-500'
            }`}
            style={{ width: `${Math.min((wordCount / targetWordCount) * 100, 100)}%` }}
          />
        </div>
      </div>
    </div>
  );
};

export default WritingEditor;