import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const TaskInstructions = ({ currentTask, onTaskChange, tasks }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const toggleExpanded = () => {
    setIsExpanded(!isExpanded);
  };

  const currentTaskData = tasks.find(task => task.id === currentTask);

  return (
    <div className="bg-white border border-secondary-200 rounded-lg shadow-custom-sm">
      <div className="p-4 border-b border-secondary-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-primary-50 rounded-lg flex items-center justify-center">
              <Icon name="FileText" size={16} className="text-primary-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-text-primary">
                Writing Task {currentTask}
              </h3>
              <p className="text-sm text-text-secondary">
                {currentTaskData?.timeLimit} minutes • {currentTaskData?.wordCount} words minimum
              </p>
            </div>
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            iconName={isExpanded ? "ChevronUp" : "ChevronDown"}
            onClick={toggleExpanded}
            aria-label={isExpanded ? "Collapse instructions" : "Expand instructions"}
          />
        </div>
      </div>

      <div className="p-4">
        <div className="mb-4">
          <h4 className="text-sm font-medium text-text-primary mb-2">Task Overview</h4>
          <p className="text-sm text-text-secondary leading-relaxed">
            {currentTaskData?.overview}
          </p>
        </div>

        {isExpanded && (
          <div className="space-y-4 animate-fade-in">
            <div>
              <h4 className="text-sm font-medium text-text-primary mb-2">Detailed Instructions</h4>
              <div className="text-sm text-text-secondary leading-relaxed space-y-2">
                {currentTaskData?.detailedInstructions.map((instruction, index) => (
                  <p key={index}>{instruction}</p>
                ))}
              </div>
            </div>

            <div>
              <h4 className="text-sm font-medium text-text-primary mb-2">Assessment Criteria</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {currentTaskData?.assessmentCriteria.map((criteria, index) => (
                  <div key={index} className="flex items-start space-x-2">
                    <Icon name="CheckCircle" size={16} className="text-success-500 mt-0.5 flex-shrink-0" />
                    <span className="text-sm text-text-secondary">{criteria}</span>
                  </div>
                ))}
              </div>
            </div>

            {currentTaskData?.samplePrompt && (
              <div>
                <h4 className="text-sm font-medium text-text-primary mb-2">Sample Question</h4>
                <div className="bg-surface p-3 rounded-lg border border-secondary-200">
                  <p className="text-sm text-text-secondary italic">
                    "{currentTaskData.samplePrompt}"
                  </p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Task Navigation */}
        <div className="flex items-center justify-between mt-4 pt-4 border-t border-secondary-200">
          <div className="flex space-x-2">
            {tasks.map((task) => (
              <Button
                key={task.id}
                variant={currentTask === task.id ? "primary" : "outline"}
                size="sm"
                onClick={() => onTaskChange(task.id)}
                className="min-w-[80px]"
              >
                Task {task.id}
              </Button>
            ))}
          </div>
          
          <div className="text-xs text-text-muted">
            Click to switch between tasks
          </div>
        </div>
      </div>
    </div>
  );
};

export default TaskInstructions;