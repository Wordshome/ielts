import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QuestionPrompt = ({ 
  question, 
  preparationTime = 30, 
  speakingTime = 120, 
  onPreparationComplete,
  onTimeUp,
  isActive = false,
  showInstructions = true
}) => {
  const [currentPhase, setCurrentPhase] = useState('preparation'); // preparation, speaking, completed
  const [timeRemaining, setTimeRemaining] = useState(preparationTime);
  const [isTimerRunning, setIsTimerRunning] = useState(false);

  useEffect(() => {
    if (isActive && currentPhase === 'preparation') {
      setTimeRemaining(preparationTime);
      setIsTimerRunning(true);
    }
  }, [isActive, preparationTime]);

  useEffect(() => {
    let interval;
    
    if (isTimerRunning && timeRemaining > 0) {
      interval = setInterval(() => {
        setTimeRemaining(prev => {
          const newTime = prev - 1;
          
          if (newTime <= 0) {
            if (currentPhase === 'preparation') {
              setCurrentPhase('speaking');
              setTimeRemaining(speakingTime);
              onPreparationComplete?.();
              return speakingTime;
            } else if (currentPhase === 'speaking') {
              setCurrentPhase('completed');
              setIsTimerRunning(false);
              onTimeUp?.();
              return 0;
            }
          }
          
          return newTime;
        });
      }, 1000);
    }
    
    return () => clearInterval(interval);
  }, [isTimerRunning, timeRemaining, currentPhase, speakingTime, onPreparationComplete, onTimeUp]);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getPhaseColor = () => {
    switch (currentPhase) {
      case 'preparation':
        return 'text-warning-600';
      case 'speaking':
        return 'text-primary-600';
      case 'completed':
        return 'text-success-600';
      default:
        return 'text-text-secondary';
    }
  };

  const getPhaseIcon = () => {
    switch (currentPhase) {
      case 'preparation':
        return 'Clock';
      case 'speaking':
        return 'Mic';
      case 'completed':
        return 'Check';
      default:
        return 'Clock';
    }
  };

  const getPhaseLabel = () => {
    switch (currentPhase) {
      case 'preparation':
        return 'Preparation Time';
      case 'speaking':
        return 'Speaking Time';
      case 'completed':
        return 'Time Complete';
      default:
        return 'Preparation Time';
    }
  };

  const handleSkipPreparation = () => {
    if (currentPhase === 'preparation') {
      setCurrentPhase('speaking');
      setTimeRemaining(speakingTime);
      onPreparationComplete?.();
    }
  };

  return (
    <div className="bg-background border border-border rounded-xl p-6 shadow-custom-md">
      {/* Question Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary-50 rounded-lg flex items-center justify-center">
            <Icon name="MessageSquare" size={20} className="text-primary-600" />
          </div>
          <div>
            <div className="text-lg font-semibold text-text-primary">
              {question?.title || 'Speaking Question'}
            </div>
            <div className="text-sm text-text-secondary">
              Part {question?.part || 1} of 3
            </div>
          </div>
        </div>
        
        {/* Timer Display */}
        <div className="text-right">
          <div className={`text-2xl font-data font-semibold ${getPhaseColor()}`}>
            {formatTime(timeRemaining)}
          </div>
          <div className={`text-sm flex items-center justify-end space-x-1 ${getPhaseColor()}`}>
            <Icon name={getPhaseIcon()} size={14} />
            <span>{getPhaseLabel()}</span>
          </div>
        </div>
      </div>

      {/* Question Content */}
      <div className="mb-6">
        <div className="bg-surface rounded-lg p-4 border border-border-light">
          <div className="text-text-primary leading-relaxed">
            {question?.content || `Describe a memorable experience from your childhood. You should say:\n\n• What the experience was\n• When and where it happened\n• Who was involved\n• Why it was memorable\n\nYou will have 1 minute to prepare and 2 minutes to speak.`}
          </div>
        </div>
      </div>

      {/* Instructions */}
      {showInstructions && (
        <div className="mb-6">
          <div className="bg-accent-50 border border-accent-200 rounded-lg p-4">
            <div className="flex items-start space-x-3">
              <Icon name="Info" size={20} className="text-accent-600 mt-0.5" />
              <div>
                <div className="text-sm font-medium text-accent-800 mb-1">
                  Instructions
                </div>
                <div className="text-sm text-accent-700 leading-relaxed">
                  {currentPhase === 'preparation' && (
                    "Use this time to think about your answer. You can make notes if needed. When ready, you can skip to speaking time."
                  )}
                  {currentPhase === 'speaking' && (
                    "Speak clearly and naturally. Try to cover all the points mentioned in the question. You have up to 2 minutes."
                  )}
                  {currentPhase === 'completed' && (
                    "Time is up! You can now review your recording or move to the next question."
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Phase-specific Controls */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          {currentPhase === 'preparation' && (
            <Button
              variant="outline"
              size="sm"
              iconName="FastForward"
              onClick={handleSkipPreparation}
            >
              Skip to Speaking
            </Button>
          )}
          
          {currentPhase === 'speaking' && (
            <div className="flex items-center space-x-2 text-sm text-text-secondary">
              <Icon name="Mic" size={16} />
              <span>Recording in progress...</span>
            </div>
          )}
          
          {currentPhase === 'completed' && (
            <div className="flex items-center space-x-2 text-sm text-success-600">
              <Icon name="Check" size={16} />
              <span>Speaking time complete</span>
            </div>
          )}
        </div>

        {/* Progress Indicator */}
        <div className="flex items-center space-x-2">
          <div className={`w-2 h-2 rounded-full ${
            currentPhase === 'preparation' ? 'bg-warning-500' : 'bg-secondary-200'
          }`} />
          <div className={`w-2 h-2 rounded-full ${
            currentPhase === 'speaking' ? 'bg-primary-500' : 
            currentPhase === 'completed' ? 'bg-success-500' : 'bg-secondary-200'
          }`} />
          <div className={`w-2 h-2 rounded-full ${
            currentPhase === 'completed' ? 'bg-success-500' : 'bg-secondary-200'
          }`} />
        </div>
      </div>

      {/* Mobile Timer Bar */}
      <div className="mt-4 md:hidden">
        <div className="w-full bg-secondary-100 rounded-full h-2">
          <div 
            className={`h-2 rounded-full transition-all duration-1000 ${
              currentPhase === 'preparation' ? 'bg-warning-500' :
              currentPhase === 'speaking' ? 'bg-primary-500' : 'bg-success-500'
            }`}
            style={{ 
              width: `${currentPhase === 'preparation' 
                ? ((preparationTime - timeRemaining) / preparationTime) * 100
                : currentPhase === 'speaking'
                ? ((speakingTime - timeRemaining) / speakingTime) * 100
                : 100
              }%` 
            }}
          />
        </div>
      </div>
    </div>
  );
};

export default QuestionPrompt;