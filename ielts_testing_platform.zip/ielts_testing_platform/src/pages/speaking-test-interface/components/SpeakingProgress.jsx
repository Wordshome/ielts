import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SpeakingProgress = ({ 
  currentQuestion = 0, 
  totalQuestions = 3, 
  completedQuestions = [], 
  onQuestionSelect,
  questions = []
}) => {
  const mockQuestions = [
    {
      id: 1,
      title: "Personal Introduction",
      part: 1,
      type: "personal",
      duration: "4-5 minutes",
      status: "completed",
      hasRecording: true
    },
    {
      id: 2,
      title: "Describe a Memorable Experience",
      part: 2,
      type: "long-turn",
      duration: "3-4 minutes",
      status: "current",
      hasRecording: false
    },
    {
      id: 3,
      title: "Discussion on Education",
      part: 3,
      type: "discussion",
      duration: "4-5 minutes",
      status: "pending",
      hasRecording: false
    }
  ];

  const questionData = questions.length > 0 ? questions : mockQuestions;

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed':
        return 'CheckCircle';
      case 'current':
        return 'Play';
      case 'pending':
        return 'Clock';
      default:
        return 'Circle';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return 'text-success-600 bg-success-50 border-success-200';
      case 'current':
        return 'text-primary-600 bg-primary-50 border-primary-200';
      case 'pending':
        return 'text-secondary-500 bg-secondary-50 border-secondary-200';
      default:
        return 'text-secondary-400 bg-secondary-50 border-secondary-200';
    }
  };

  const getProgressPercentage = () => {
    return (completedQuestions.length / totalQuestions) * 100;
  };

  return (
    <div className="bg-background border border-border rounded-xl p-6 shadow-custom-md">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary-50 rounded-lg flex items-center justify-center">
            <Icon name="BarChart3" size={20} className="text-primary-600" />
          </div>
          <div>
            <div className="text-lg font-semibold text-text-primary">
              Speaking Test Progress
            </div>
            <div className="text-sm text-text-secondary">
              {completedQuestions.length} of {totalQuestions} parts completed
            </div>
          </div>
        </div>
        
        <div className="text-right">
          <div className="text-2xl font-semibold text-primary-600">
            {Math.round(getProgressPercentage())}%
          </div>
          <div className="text-xs text-text-secondary">
            Complete
          </div>
        </div>
      </div>

      {/* Overall Progress Bar */}
      <div className="mb-6">
        <div className="w-full bg-secondary-100 rounded-full h-2">
          <div 
            className="h-2 bg-primary-500 rounded-full transition-all duration-300"
            style={{ width: `${getProgressPercentage()}%` }}
          />
        </div>
      </div>

      {/* Question List */}
      <div className="space-y-4">
        {questionData.map((question, index) => (
          <div
            key={question.id}
            className={`border rounded-lg p-4 transition-all duration-150 cursor-pointer hover:shadow-custom-sm ${
              question.status === 'current' ?'border-primary-200 bg-primary-50' 
                : question.status === 'completed' ?'border-success-200 bg-success-50' :'border-secondary-200 bg-background hover:bg-surface'
            }`}
            onClick={() => onQuestionSelect?.(index)}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center border ${getStatusColor(question.status)}`}>
                  <Icon name={getStatusIcon(question.status)} size={16} />
                </div>
                
                <div>
                  <div className="text-sm font-medium text-text-primary">
                    Part {question.part}: {question.title}
                  </div>
                  <div className="text-xs text-text-secondary">
                    {question.duration} • {question.type}
                  </div>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                {question.hasRecording && (
                  <div className="flex items-center space-x-1 text-xs text-success-600">
                    <Icon name="Mic" size={12} />
                    <span>Recorded</span>
                  </div>
                )}
                
                {question.status === 'current' && (
                  <div className="w-2 h-2 bg-primary-500 rounded-full animate-pulse" />
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Mobile Summary */}
      <div className="md:hidden mt-6 pt-4 border-t border-border">
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <div className="text-lg font-semibold text-success-600">
              {completedQuestions.length}
            </div>
            <div className="text-xs text-text-secondary">
              Completed
            </div>
          </div>
          <div>
            <div className="text-lg font-semibold text-primary-600">
              1
            </div>
            <div className="text-xs text-text-secondary">
              Current
            </div>
          </div>
          <div>
            <div className="text-lg font-semibold text-secondary-500">
              {totalQuestions - completedQuestions.length - 1}
            </div>
            <div className="text-xs text-text-secondary">
              Remaining
            </div>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex items-center justify-between mt-6 pt-4 border-t border-border">
        <Button
          variant="outline"
          size="sm"
          iconName="SkipBack"
          onClick={() => onQuestionSelect?.(Math.max(0, currentQuestion - 1))}
          disabled={currentQuestion === 0}
        >
          Previous
        </Button>
        
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            iconName="RotateCcw"
            onClick={() => {}}
          >
            Reset
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            iconName="Save"
            onClick={() => {}}
          >
            Save Progress
          </Button>
        </div>
        
        <Button
          variant="primary"
          size="sm"
          iconName="SkipForward"
          onClick={() => onQuestionSelect?.(Math.min(totalQuestions - 1, currentQuestion + 1))}
          disabled={currentQuestion === totalQuestions - 1}
        >
          Next
        </Button>
      </div>
    </div>
  );
};

export default SpeakingProgress;