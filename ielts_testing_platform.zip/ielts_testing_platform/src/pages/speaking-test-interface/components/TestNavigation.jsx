import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const TestNavigation = ({ 
  onPauseTest, 
  onExitTest, 
  onSubmitTest, 
  canSubmit = false,
  isPaused = false,
  showSubmit = false
}) => {
  const navigate = useNavigate();

  const handleExitTest = () => {
    if (window.confirm('Are you sure you want to exit the test? Your progress will be saved.')) {
      onExitTest?.();
      navigate('/test-results-dashboard');
    }
  };

  const handleSubmitTest = () => {
    if (window.confirm('Are you sure you want to submit your speaking test? This action cannot be undone.')) {
      onSubmitTest?.();
      navigate('/test-results-dashboard');
    }
  };

  const handleNavigateToSection = (path) => {
    if (window.confirm('Are you sure you want to leave the speaking test? Your progress will be saved.')) {
      navigate(path);
    }
  };

  return (
    <div className="bg-background border border-border rounded-xl p-4 shadow-custom-md">
      {/* Desktop Navigation */}
      <div className="hidden md:flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            iconName="Headphones"
            onClick={() => handleNavigateToSection('/listening-test-interface')}
          >
            Listening
          </Button>
          <Button
            variant="outline"
            size="sm"
            iconName="BookOpen"
            onClick={() => handleNavigateToSection('/reading-test-interface')}
          >
            Reading
          </Button>
          <Button
            variant="outline"
            size="sm"
            iconName="PenTool"
            onClick={() => handleNavigateToSection('/writing-test-interface')}
          >
            Writing
          </Button>
          <Button
            variant="primary"
            size="sm"
            iconName="Mic"
            disabled
          >
            Speaking
          </Button>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            iconName={isPaused ? "Play" : "Pause"}
            onClick={onPauseTest}
          >
            {isPaused ? 'Resume' : 'Pause'}
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            iconName="Home"
            onClick={handleExitTest}
          >
            Exit Test
          </Button>
          
          {showSubmit && (
            <Button
              variant="success"
              size="sm"
              iconName="Send"
              onClick={handleSubmitTest}
              disabled={!canSubmit}
            >
              Submit Test
            </Button>
          )}
        </div>
      </div>

      {/* Mobile Navigation */}
      <div className="md:hidden">
        {/* Section Navigation */}
        <div className="flex items-center space-x-1 mb-3">
          <Button
            variant="ghost"
            size="xs"
            iconName="Headphones"
            onClick={() => handleNavigateToSection('/listening-test-interface')}
            className="flex-1"
          >
            Listening
          </Button>
          <Button
            variant="ghost"
            size="xs"
            iconName="BookOpen"
            onClick={() => handleNavigateToSection('/reading-test-interface')}
            className="flex-1"
          >
            Reading
          </Button>
          <Button
            variant="ghost"
            size="xs"
            iconName="PenTool"
            onClick={() => handleNavigateToSection('/writing-test-interface')}
            className="flex-1"
          >
            Writing
          </Button>
          <Button
            variant="primary"
            size="xs"
            iconName="Mic"
            disabled
            className="flex-1"
          >
            Speaking
          </Button>
        </div>
        
        {/* Control Buttons */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              iconName={isPaused ? "Play" : "Pause"}
              onClick={onPauseTest}
            />
            
            <Button
              variant="outline"
              size="sm"
              iconName="Home"
              onClick={handleExitTest}
            />
          </div>
          
          {showSubmit && (
            <Button
              variant="success"
              size="sm"
              iconName="Send"
              onClick={handleSubmitTest}
              disabled={!canSubmit}
            >
              Submit
            </Button>
          )}
        </div>
      </div>

      {/* Status Indicators */}
      <div className="flex items-center justify-between mt-3 pt-3 border-t border-border text-xs text-text-secondary">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-1">
            <div className="w-2 h-2 bg-success-500 rounded-full" />
            <span>Auto-save enabled</span>
          </div>
          
          {isPaused && (
            <div className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-warning-500 rounded-full" />
              <span>Test paused</span>
            </div>
          )}
        </div>
        
        <div className="flex items-center space-x-1">
          <Icon name="Wifi" size={12} />
          <span>Connected</span>
        </div>
      </div>
    </div>
  );
};

export default TestNavigation;