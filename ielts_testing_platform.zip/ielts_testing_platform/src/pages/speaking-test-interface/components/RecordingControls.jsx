import React, { useState, useEffect, useRef } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const RecordingControls = ({ 
  isRecording, 
  onStartRecording, 
  onStopRecording, 
  onPlayback, 
  isPlaying, 
  recordingTime, 
  hasRecording,
  disabled = false,
  microphoneLevel = 0
}) => {
  const [showWaveform, setShowWaveform] = useState(false);
  const waveformRef = useRef(null);

  useEffect(() => {
    if (isRecording) {
      setShowWaveform(true);
      animateWaveform();
    } else {
      setShowWaveform(false);
    }
  }, [isRecording]);

  const animateWaveform = () => {
    if (!waveformRef.current) return;
    
    const bars = waveformRef.current.children;
    const animate = () => {
      for (let i = 0; i < bars.length; i++) {
        const height = Math.random() * 40 + 10;
        bars[i].style.height = `${height}px`;
      }
    };
    
    const interval = setInterval(animate, 100);
    return () => clearInterval(interval);
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getMicrophoneLevelColor = () => {
    if (microphoneLevel < 30) return 'bg-error-500';
    if (microphoneLevel < 70) return 'bg-warning-500';
    return 'bg-success-500';
  };

  return (
    <div className="bg-background border border-border rounded-xl p-6 shadow-custom-md">
      {/* Recording Status */}
      <div className="text-center mb-6">
        <div className={`inline-flex items-center space-x-2 px-4 py-2 rounded-full text-sm font-medium ${
          isRecording 
            ? 'bg-error-50 text-error-600 border border-error-200' 
            : hasRecording 
            ? 'bg-success-50 text-success-600 border border-success-200' :'bg-secondary-100 text-secondary-600 border border-secondary-200'
        }`}>
          {isRecording && (
            <div className="w-2 h-2 bg-error-500 rounded-full animate-pulse" />
          )}
          <Icon 
            name={isRecording ? "Mic" : hasRecording ? "Check" : "MicOff"} 
            size={16} 
          />
          <span>
            {isRecording ? 'Recording...' : hasRecording ? 'Recording Complete' : 'Ready to Record'}
          </span>
        </div>
      </div>

      {/* Waveform Visualization */}
      {showWaveform && (
        <div className="flex items-center justify-center mb-6 h-16">
          <div ref={waveformRef} className="flex items-end space-x-1 h-full">
            {Array.from({ length: 20 }).map((_, index) => (
              <div
                key={index}
                className="w-2 bg-primary-500 rounded-t transition-all duration-100"
                style={{ height: '10px' }}
              />
            ))}
          </div>
        </div>
      )}

      {/* Recording Timer */}
      {(isRecording || hasRecording) && (
        <div className="text-center mb-6">
          <div className="text-2xl font-data font-semibold text-text-primary">
            {formatTime(recordingTime)}
          </div>
          <div className="text-sm text-text-secondary mt-1">
            Recording Duration
          </div>
        </div>
      )}

      {/* Microphone Level Indicator */}
      {isRecording && (
        <div className="mb-6">
          <div className="flex items-center justify-between text-sm text-text-secondary mb-2">
            <span>Microphone Level</span>
            <span>{microphoneLevel}%</span>
          </div>
          <div className="w-full bg-secondary-100 rounded-full h-2">
            <div 
              className={`h-2 rounded-full transition-all duration-150 ${getMicrophoneLevelColor()}`}
              style={{ width: `${microphoneLevel}%` }}
            />
          </div>
        </div>
      )}

      {/* Main Controls */}
      <div className="flex items-center justify-center space-x-4">
        {!isRecording ? (
          <>
            <Button
              variant="primary"
              size="xl"
              iconName="Mic"
              onClick={onStartRecording}
              disabled={disabled}
              className="w-16 h-16 rounded-full"
              aria-label="Start recording"
            />
            
            {hasRecording && (
              <Button
                variant={isPlaying ? "secondary" : "outline"}
                size="lg"
                iconName={isPlaying ? "Pause" : "Play"}
                onClick={onPlayback}
                className="w-12 h-12 rounded-full"
                aria-label={isPlaying ? "Pause playback" : "Play recording"}
              />
            )}
          </>
        ) : (
          <Button
            variant="danger"
            size="xl"
            iconName="Square"
            onClick={onStopRecording}
            className="w-16 h-16 rounded-full"
            aria-label="Stop recording"
          />
        )}
      </div>

      {/* Control Labels */}
      <div className="text-center mt-4">
        <div className="text-sm text-text-secondary">
          {!isRecording 
            ? hasRecording 
              ? 'Tap to record again or play to review' :'Tap the microphone to start recording' :'Tap the stop button to finish recording'
          }
        </div>
      </div>

      {/* Desktop Additional Controls */}
      <div className="hidden md:flex items-center justify-center space-x-2 mt-6">
        <Button
          variant="ghost"
          size="sm"
          iconName="Settings"
          onClick={() => {}}
          disabled={isRecording}
        >
          Audio Settings
        </Button>
        
        <Button
          variant="ghost"
          size="sm"
          iconName="Volume2"
          onClick={() => {}}
          disabled={isRecording}
        >
          Test Audio
        </Button>
      </div>
    </div>
  );
};

export default RecordingControls;