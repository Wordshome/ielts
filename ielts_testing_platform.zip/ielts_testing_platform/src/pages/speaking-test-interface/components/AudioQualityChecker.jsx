import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const AudioQualityChecker = ({ onQualityCheck, onPermissionGranted }) => {
  const [microphoneAccess, setMicrophoneAccess] = useState('checking'); // checking, granted, denied
  const [audioLevel, setAudioLevel] = useState(0);
  const [isTestingAudio, setIsTestingAudio] = useState(false);
  const [audioQuality, setAudioQuality] = useState('unknown'); // unknown, poor, good, excellent
  const [mediaStream, setMediaStream] = useState(null);

  useEffect(() => {
    checkMicrophonePermission();
    return () => {
      if (mediaStream) {
        mediaStream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const checkMicrophonePermission = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      setMicrophoneAccess('granted');
      setMediaStream(stream);
      onPermissionGranted?.(true);
      
      // Set up audio level monitoring
      const audioContext = new (window.AudioContext || window.webkitAudioContext)();
      const analyser = audioContext.createAnalyser();
      const microphone = audioContext.createMediaStreamSource(stream);
      const dataArray = new Uint8Array(analyser.frequencyBinCount);
      
      microphone.connect(analyser);
      analyser.fftSize = 256;
      
      const updateAudioLevel = () => {
        analyser.getByteFrequencyData(dataArray);
        const average = dataArray.reduce((a, b) => a + b) / dataArray.length;
        const level = Math.round((average / 255) * 100);
        setAudioLevel(level);
        
        // Determine audio quality based on level consistency
        if (level > 20 && level < 80) {
          setAudioQuality('excellent');
        } else if (level > 10 && level < 90) {
          setAudioQuality('good');
        } else if (level > 5) {
          setAudioQuality('poor');
        }
        
        if (isTestingAudio) {
          requestAnimationFrame(updateAudioLevel);
        }
      };
      
      if (isTestingAudio) {
        updateAudioLevel();
      }
      
    } catch (error) {
      setMicrophoneAccess('denied');
      onPermissionGranted?.(false);
    }
  };

  const startAudioTest = () => {
    setIsTestingAudio(true);
    setAudioQuality('unknown');
  };

  const stopAudioTest = () => {
    setIsTestingAudio(false);
    onQualityCheck?.(audioQuality);
  };

  const getQualityColor = () => {
    switch (audioQuality) {
      case 'excellent':
        return 'text-success-600';
      case 'good':
        return 'text-primary-600';
      case 'poor':
        return 'text-warning-600';
      default:
        return 'text-text-secondary';
    }
  };

  const getQualityIcon = () => {
    switch (audioQuality) {
      case 'excellent':
        return 'CheckCircle';
      case 'good':
        return 'Check';
      case 'poor':
        return 'AlertTriangle';
      default:
        return 'HelpCircle';
    }
  };

  const getLevelColor = () => {
    if (audioLevel < 20) return 'bg-error-500';
    if (audioLevel < 40) return 'bg-warning-500';
    if (audioLevel < 80) return 'bg-success-500';
    return 'bg-warning-500'; // Too loud
  };

  if (microphoneAccess === 'checking') {
    return (
      <div className="bg-background border border-border rounded-xl p-6 shadow-custom-md">
        <div className="text-center">
          <div className="w-16 h-16 bg-primary-50 rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name="Mic" size={24} className="text-primary-600 animate-pulse" />
          </div>
          <div className="text-lg font-semibold text-text-primary mb-2">
            Checking Microphone Access
          </div>
          <div className="text-sm text-text-secondary">
            Please allow microphone access when prompted
          </div>
        </div>
      </div>
    );
  }

  if (microphoneAccess === 'denied') {
    return (
      <div className="bg-background border border-error-200 rounded-xl p-6 shadow-custom-md">
        <div className="text-center">
          <div className="w-16 h-16 bg-error-50 rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name="MicOff" size={24} className="text-error-600" />
          </div>
          <div className="text-lg font-semibold text-error-600 mb-2">
            Microphone Access Denied
          </div>
          <div className="text-sm text-text-secondary mb-4">
            Microphone access is required for the speaking test. Please enable it in your browser settings.
          </div>
          <Button
            variant="primary"
            iconName="RefreshCw"
            onClick={checkMicrophonePermission}
          >
            Try Again
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-background border border-border rounded-xl p-6 shadow-custom-md">
      {/* Header */}
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-success-50 rounded-lg flex items-center justify-center">
          <Icon name="Mic" size={20} className="text-success-600" />
        </div>
        <div>
          <div className="text-lg font-semibold text-text-primary">
            Audio Quality Check
          </div>
          <div className="text-sm text-text-secondary">
            Test your microphone before starting
          </div>
        </div>
      </div>

      {/* Audio Level Indicator */}
      <div className="mb-6">
        <div className="flex items-center justify-between text-sm text-text-secondary mb-2">
          <span>Microphone Level</span>
          <span>{audioLevel}%</span>
        </div>
        <div className="w-full bg-secondary-100 rounded-full h-3">
          <div 
            className={`h-3 rounded-full transition-all duration-150 ${getLevelColor()}`}
            style={{ width: `${audioLevel}%` }}
          />
        </div>
        <div className="flex justify-between text-xs text-text-muted mt-1">
          <span>Too Quiet</span>
          <span>Optimal</span>
          <span>Too Loud</span>
        </div>
      </div>

      {/* Quality Status */}
      <div className="mb-6">
        <div className={`flex items-center space-x-2 text-sm font-medium ${getQualityColor()}`}>
          <Icon name={getQualityIcon()} size={16} />
          <span>
            Audio Quality: {audioQuality === 'unknown' ? 'Not tested' : audioQuality.charAt(0).toUpperCase() + audioQuality.slice(1)}
          </span>
        </div>
      </div>

      {/* Test Controls */}
      <div className="flex items-center justify-center space-x-3 mb-6">
        {!isTestingAudio ? (
          <Button
            variant="primary"
            iconName="Play"
            onClick={startAudioTest}
          >
            Test Microphone
          </Button>
        ) : (
          <Button
            variant="secondary"
            iconName="Square"
            onClick={stopAudioTest}
          >
            Stop Test
          </Button>
        )}
        
        <Button
          variant="outline"
          iconName="Settings"
          onClick={() => {}}
        >
          Audio Settings
        </Button>
      </div>

      {/* Instructions */}
      <div className="bg-accent-50 border border-accent-200 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <Icon name="Info" size={20} className="text-accent-600 mt-0.5" />
          <div>
            <div className="text-sm font-medium text-accent-800 mb-1">
              Audio Test Instructions
            </div>
            <div className="text-sm text-accent-700 leading-relaxed">
              {!isTestingAudio ? (
                "Click 'Test Microphone' and speak normally. The level indicator should show green for optimal quality."
              ) : (
                "Speak clearly at normal volume. The microphone level should stay in the green zone for best results."
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Quality Recommendations */}
      {audioQuality !== 'unknown' && audioQuality !== 'excellent' && (
        <div className="mt-4 bg-warning-50 border border-warning-200 rounded-lg p-4">
          <div className="flex items-start space-x-3">
            <Icon name="AlertTriangle" size={20} className="text-warning-600 mt-0.5" />
            <div>
              <div className="text-sm font-medium text-warning-800 mb-1">
                Audio Quality Recommendations
              </div>
              <div className="text-sm text-warning-700 leading-relaxed">
                {audioQuality === 'poor' && (
                  "Consider moving to a quieter location or adjusting your microphone position for better audio quality."
                )}
                {audioQuality === 'good' && (
                  "Audio quality is acceptable. For best results, ensure you're in a quiet environment."
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AudioQualityChecker;