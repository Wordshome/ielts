import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import AdaptiveHeader from '../../components/ui/AdaptiveHeader';
import TestProgressBar from '../../components/ui/TestProgressBar';
import TestTimer from '../../components/ui/TestTimer';
import NavigationBreadcrumb from '../../components/ui/NavigationBreadcrumb';
import RecordingControls from './components/RecordingControls';
import QuestionPrompt from './components/QuestionPrompt';
import AudioQualityChecker from './components/AudioQualityChecker';
import SpeakingProgress from './components/SpeakingProgress';
import TestNavigation from './components/TestNavigation';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const SpeakingTestInterface = () => {
  const navigate = useNavigate();
  
  // Test state
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [isRecording, setIsRecording] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [hasRecording, setHasRecording] = useState(false);
  const [microphoneLevel, setMicrophoneLevel] = useState(0);
  const [testStarted, setTestStarted] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [audioQualityChecked, setAudioQualityChecked] = useState(false);
  const [permissionGranted, setPermissionGranted] = useState(false);
  
  // Timer state
  const [timeRemaining, setTimeRemaining] = useState(900); // 15 minutes total
  const [sectionProgress, setSectionProgress] = useState(0);

  // Mock questions data
  const questions = [
    {
      id: 1,
      title: "Personal Introduction",
      part: 1,
      content: `Let's talk about yourself and your background.\n\n• What's your name?\n• Where are you from?\n• What do you do for work or study?\n• What are your hobbies and interests?\n\nThis part will take about 4-5 minutes.`,
      preparationTime: 0,
      speakingTime: 300,
      type: "personal"
    },
    {
      id: 2,
      title: "Describe a Memorable Experience",
      part: 2,
      content: `Describe a memorable experience from your childhood.\n\nYou should say:\n• What the experience was\n• When and where it happened\n• Who was involved\n• Why it was memorable\n\nYou will have 1 minute to prepare and 2 minutes to speak.`,
      preparationTime: 60,
      speakingTime: 120,
      type: "long-turn"
    },
    {
      id: 3,
      title: "Discussion on Education",
      part: 3,
      content: `Let's discuss education and learning.\n\n• How has education changed in your country?\n• What role does technology play in modern education?\n• Do you think online learning is as effective as traditional classroom learning?\n• What skills do you think are most important for students to develop?\n\nThis discussion will take about 4-5 minutes.`,
      preparationTime: 0,
      speakingTime: 300,
      type: "discussion"
    }
  ];

  const completedQuestions = questions.slice(0, currentQuestion).map(q => q.id);

  // Recording timer effect
  useEffect(() => {
    let interval;
    if (isRecording) {
      interval = setInterval(() => {
        setRecordingTime(prev => prev + 1);
        setMicrophoneLevel(Math.random() * 100); // Simulate microphone level
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRecording]);

  // Progress calculation
  useEffect(() => {
    const progress = ((currentQuestion + (hasRecording ? 1 : 0)) / questions.length) * 100;
    setSectionProgress(Math.min(progress, 100));
  }, [currentQuestion, hasRecording]);

  // Recording handlers
  const handleStartRecording = () => {
    if (!testStarted) {
      setTestStarted(true);
    }
    setIsRecording(true);
    setRecordingTime(0);
    setHasRecording(false);
  };

  const handleStopRecording = () => {
    setIsRecording(false);
    setHasRecording(true);
    setMicrophoneLevel(0);
  };

  const handlePlayback = () => {
    setIsPlaying(!isPlaying);
    // Simulate playback duration
    if (!isPlaying) {
      setTimeout(() => setIsPlaying(false), recordingTime * 1000);
    }
  };

  // Navigation handlers
  const handleQuestionSelect = (questionIndex) => {
    if (questionIndex >= 0 && questionIndex < questions.length) {
      setCurrentQuestion(questionIndex);
      setIsRecording(false);
      setIsPlaying(false);
      setHasRecording(false);
      setRecordingTime(0);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      handleQuestionSelect(currentQuestion + 1);
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestion > 0) {
      handleQuestionSelect(currentQuestion - 1);
    }
  };

  // Test control handlers
  const handlePauseTest = () => {
    setIsPaused(!isPaused);
    if (isRecording) {
      setIsRecording(false);
    }
  };

  const handleExitTest = () => {
    navigate('/test-results-dashboard');
  };

  const handleSubmitTest = () => {
    navigate('/test-results-dashboard');
  };

  const handleTimeUp = () => {
    if (isRecording) {
      handleStopRecording();
    }
    alert('Time is up! Your speaking test has been completed.');
    navigate('/test-results-dashboard');
  };

  const handleTimeWarning = (timeLeft) => {
    if (timeLeft === 300) { // 5 minutes warning
      alert('5 minutes remaining in your speaking test.');
    } else if (timeLeft === 60) { // 1 minute warning
      alert('1 minute remaining in your speaking test.');
    }
  };

  const handlePreparationComplete = () => {
    // Automatically start recording after preparation time
    if (!isRecording) {
      handleStartRecording();
    }
  };

  const handleAudioQualityCheck = (quality) => {
    setAudioQualityChecked(true);
  };

  const handlePermissionGranted = (granted) => {
    setPermissionGranted(granted);
  };

  // Show audio quality checker if permission not granted or quality not checked
  if (!permissionGranted || !audioQualityChecked) {
    return (
      <div className="min-h-screen bg-surface">
        <AdaptiveHeader />
        <TestProgressBar 
          currentSection={3}
          totalSections={4}
          sectionProgress={0}
          timeRemaining={timeRemaining}
          totalTime={900}
        />
        
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-6">
            <NavigationBreadcrumb />
          </div>
          
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-primary-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Icon name="Mic" size={24} className="text-primary-600" />
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-text-primary mb-2">
              Speaking Test Setup
            </h1>
            <p className="text-text-secondary">
              Let's check your audio setup before starting the speaking test
            </p>
          </div>
          
          <div className="max-w-2xl mx-auto">
            <AudioQualityChecker 
              onQualityCheck={handleAudioQualityCheck}
              onPermissionGranted={handlePermissionGranted}
            />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-surface">
      <AdaptiveHeader />
      <TestProgressBar 
        currentSection={3}
        totalSections={4}
        sectionProgress={sectionProgress}
        timeRemaining={timeRemaining}
        totalTime={900}
      />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Header */}
        <div className="mb-6">
          <NavigationBreadcrumb />
          <div className="flex items-center justify-between mt-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-text-primary">
                IELTS Speaking Test
              </h1>
              <p className="text-text-secondary mt-1">
                Part {questions[currentQuestion]?.part} of 3 • {questions[currentQuestion]?.type}
              </p>
            </div>
            
            <div className="hidden md:block">
              <TestTimer 
                initialTime={timeRemaining}
                onTimeUp={handleTimeUp}
                onTimeWarning={handleTimeWarning}
                sectionName="Speaking Test"
                showControls={false}
              />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Question Prompt */}
            <QuestionPrompt 
              question={questions[currentQuestion]}
              preparationTime={questions[currentQuestion]?.preparationTime}
              speakingTime={questions[currentQuestion]?.speakingTime}
              onPreparationComplete={handlePreparationComplete}
              onTimeUp={handleTimeUp}
              isActive={testStarted && !isPaused}
            />
            
            {/* Recording Controls */}
            <RecordingControls 
              isRecording={isRecording}
              onStartRecording={handleStartRecording}
              onStopRecording={handleStopRecording}
              onPlayback={handlePlayback}
              isPlaying={isPlaying}
              recordingTime={recordingTime}
              hasRecording={hasRecording}
              disabled={isPaused}
              microphoneLevel={microphoneLevel}
            />
            
            {/* Navigation Controls */}
            <div className="flex items-center justify-between bg-background border border-border rounded-lg p-4">
              <Button
                variant="outline"
                iconName="ChevronLeft"
                onClick={handlePreviousQuestion}
                disabled={currentQuestion === 0 || isRecording}
              >
                Previous
              </Button>
              
              <div className="flex items-center space-x-2 text-sm text-text-secondary">
                <span>Question {currentQuestion + 1} of {questions.length}</span>
                {hasRecording && (
                  <div className="flex items-center space-x-1 text-success-600">
                    <Icon name="Check" size={14} />
                    <span>Recorded</span>
                  </div>
                )}
              </div>
              
              <Button
                variant="primary"
                iconName="ChevronRight"
                iconPosition="right"
                onClick={handleNextQuestion}
                disabled={currentQuestion === questions.length - 1 || isRecording}
              >
                Next
              </Button>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Mobile Timer */}
            <div className="lg:hidden">
              <TestTimer 
                initialTime={timeRemaining}
                onTimeUp={handleTimeUp}
                onTimeWarning={handleTimeWarning}
                sectionName="Speaking"
                showControls={false}
              />
            </div>
            
            {/* Progress Tracker */}
            <SpeakingProgress 
              currentQuestion={currentQuestion}
              totalQuestions={questions.length}
              completedQuestions={completedQuestions}
              onQuestionSelect={handleQuestionSelect}
              questions={questions.map((q, index) => ({
                ...q,
                status: index < currentQuestion ? 'completed' : 
                       index === currentQuestion ? 'current' : 'pending',
                hasRecording: index < currentQuestion || (index === currentQuestion && hasRecording)
              }))}
            />
            
            {/* Test Navigation */}
            <TestNavigation 
              onPauseTest={handlePauseTest}
              onExitTest={handleExitTest}
              onSubmitTest={handleSubmitTest}
              canSubmit={completedQuestions.length === questions.length}
              isPaused={isPaused}
              showSubmit={currentQuestion === questions.length - 1 && hasRecording}
            />
          </div>
        </div>

        {/* Bottom Actions */}
        <div className="mt-8 flex items-center justify-center space-x-4">
          <Button
            variant="outline"
            iconName="Save"
            onClick={() => {}}
          >
            Save Progress
          </Button>
          
          {currentQuestion === questions.length - 1 && hasRecording && (
            <Button
              variant="success"
              iconName="Send"
              onClick={handleSubmitTest}
            >
              Submit Speaking Test
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default SpeakingTestInterface;