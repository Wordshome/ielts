import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const QuestionPanel = ({ 
  questions = [], 
  currentQuestion = 0,
  answers = {},
  onAnswerChange,
  onQuestionChange,
  bookmarkedQuestions = [],
  onBookmarkToggle,
  showReviewMode = false
}) => {
  const [expandedQuestions, setExpandedQuestions] = useState(new Set([currentQuestion]));

  const questionTypes = {
    'multiple-choice': 'Multiple Choice',
    'true-false-not-given': 'True/False/Not Given',
    'matching-headings': 'Matching Headings',
    'short-answer': 'Short Answer',
    'sentence-completion': 'Sentence Completion',
    'summary-completion': 'Summary Completion'
  };

  const toggleQuestionExpansion = (questionIndex) => {
    const newExpanded = new Set(expandedQuestions);
    if (newExpanded.has(questionIndex)) {
      newExpanded.delete(questionIndex);
    } else {
      newExpanded.add(questionIndex);
    }
    setExpandedQuestions(newExpanded);
  };

  const handleAnswerSelect = (questionIndex, answer) => {
    onAnswerChange?.(questionIndex, answer);
  };

  const handleTextAnswer = (questionIndex, value) => {
    onAnswerChange?.(questionIndex, value);
  };

  const isQuestionAnswered = (questionIndex) => {
    return answers[questionIndex] !== undefined && answers[questionIndex] !== '';
  };

  const isQuestionBookmarked = (questionIndex) => {
    return bookmarkedQuestions.includes(questionIndex);
  };

  const getQuestionStatusIcon = (questionIndex) => {
    if (isQuestionBookmarked(questionIndex)) {
      return <Icon name="Bookmark" size={16} className="text-warning-600" />;
    }
    if (isQuestionAnswered(questionIndex)) {
      return <Icon name="CheckCircle" size={16} className="text-success-600" />;
    }
    return <Icon name="Circle" size={16} className="text-text-muted" />;
  };

  const renderMultipleChoice = (question, questionIndex) => (
    <div className="space-y-3">
      {question.options.map((option, optionIndex) => (
        <label
          key={optionIndex}
          className={`flex items-start space-x-3 p-3 rounded-lg border cursor-pointer transition-all hover:bg-surface ${
            answers[questionIndex] === option.value
              ? 'border-primary bg-primary-50 text-primary-700' :'border-border hover:border-primary-200'
          }`}
        >
          <input
            type="radio"
            name={`question-${questionIndex}`}
            value={option.value}
            checked={answers[questionIndex] === option.value}
            onChange={() => handleAnswerSelect(questionIndex, option.value)}
            className="mt-1 w-4 h-4 text-primary focus:ring-primary"
          />
          <div className="flex-1">
            <span className="text-sm font-medium">{option.label}</span>
            <p className="text-sm text-text-secondary mt-1">{option.text}</p>
          </div>
        </label>
      ))}
    </div>
  );

  const renderTrueFalseNotGiven = (question, questionIndex) => (
    <div className="space-y-2">
      {['TRUE', 'FALSE', 'NOT GIVEN'].map((option) => (
        <label
          key={option}
          className={`flex items-center space-x-3 p-3 rounded-lg border cursor-pointer transition-all hover:bg-surface ${
            answers[questionIndex] === option
              ? 'border-primary bg-primary-50 text-primary-700' :'border-border hover:border-primary-200'
          }`}
        >
          <input
            type="radio"
            name={`question-${questionIndex}`}
            value={option}
            checked={answers[questionIndex] === option}
            onChange={() => handleAnswerSelect(questionIndex, option)}
            className="w-4 h-4 text-primary focus:ring-primary"
          />
          <span className="text-sm font-medium">{option}</span>
        </label>
      ))}
    </div>
  );

  const renderShortAnswer = (question, questionIndex) => (
    <div className="space-y-3">
      <Input
        type="text"
        placeholder="Enter your answer..."
        value={answers[questionIndex] || ''}
        onChange={(e) => handleTextAnswer(questionIndex, e.target.value)}
        className="w-full"
        maxLength={question.maxLength || 100}
      />
      {question.maxLength && (
        <p className="text-xs text-text-secondary">
          Maximum {question.maxLength} characters
        </p>
      )}
    </div>
  );

  const renderMatchingHeadings = (question, questionIndex) => (
    <div className="space-y-3">
      <div className="bg-surface p-3 rounded-lg">
        <h4 className="text-sm font-medium text-text-primary mb-2">Available Headings:</h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm">
          {question.headings.map((heading, index) => (
            <div key={index} className="flex items-start space-x-2">
              <span className="font-medium text-primary">{String.fromCharCode(65 + index)}.</span>
              <span className="text-text-secondary">{heading}</span>
            </div>
          ))}
        </div>
      </div>
      
      <select
        value={answers[questionIndex] || ''}
        onChange={(e) => handleAnswerSelect(questionIndex, e.target.value)}
        className="w-full p-3 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
      >
        <option value="">Select a heading...</option>
        {question.headings.map((heading, index) => (
          <option key={index} value={String.fromCharCode(65 + index)}>
            {String.fromCharCode(65 + index)}. {heading}
          </option>
        ))}
      </select>
    </div>
  );

  const renderQuestion = (question, questionIndex) => {
    switch (question.type) {
      case 'multiple-choice':
        return renderMultipleChoice(question, questionIndex);
      case 'true-false-not-given':
        return renderTrueFalseNotGiven(question, questionIndex);
      case 'short-answer': case'sentence-completion': case'summary-completion':
        return renderShortAnswer(question, questionIndex);
      case 'matching-headings':
        return renderMatchingHeadings(question, questionIndex);
      default:
        return <p className="text-text-secondary">Question type not supported</p>;
    }
  };

  if (questions.length === 0) {
    return (
      <div className="flex items-center justify-center h-full bg-surface rounded-lg">
        <div className="text-center">
          <Icon name="HelpCircle" size={48} className="text-text-muted mx-auto mb-4" />
          <p className="text-text-secondary">No questions available</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full bg-background rounded-lg border border-border overflow-hidden">
      {/* Questions Header */}
      <div className="p-4 border-b border-border bg-surface">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-text-primary font-heading">
              Questions {questions[0]?.questionNumber || 1} - {questions[questions.length - 1]?.questionNumber || questions.length}
            </h3>
            <p className="text-sm text-text-secondary mt-1">
              {questions.filter((_, index) => isQuestionAnswered(index)).length} of {questions.length} answered
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              iconName="RotateCcw"
              onClick={() => {}}
              className="text-text-secondary hover:text-primary"
            />
            <Button
              variant="ghost"
              size="sm"
              iconName="Eye"
              onClick={() => {}}
              className="text-text-secondary hover:text-primary"
            />
          </div>
        </div>
      </div>

      {/* Questions List */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-4 space-y-4">
          {questions.map((question, questionIndex) => (
            <div
              key={questionIndex}
              className={`border rounded-lg transition-all ${
                questionIndex === currentQuestion
                  ? 'border-primary bg-primary-50' :'border-border bg-background hover:border-primary-200'
              }`}
            >
              {/* Question Header */}
              <div 
                className="p-4 cursor-pointer"
                onClick={() => {
                  onQuestionChange?.(questionIndex);
                  toggleQuestionExpansion(questionIndex);
                }}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3 flex-1">
                    {getQuestionStatusIcon(questionIndex)}
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <span className="text-sm font-medium text-primary">
                          Question {question.questionNumber || questionIndex + 1}
                        </span>
                        <span className="text-xs px-2 py-1 bg-secondary-100 text-secondary-700 rounded-full">
                          {questionTypes[question.type] || question.type}
                        </span>
                      </div>
                      <p className="text-sm text-text-primary font-medium">
                        {question.question}
                      </p>
                      {question.instruction && (
                        <p className="text-xs text-text-secondary mt-1 italic">
                          {question.instruction}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 ml-4">
                    <Button
                      variant="ghost"
                      size="xs"
                      iconName="Bookmark"
                      onClick={(e) => {
                        e.stopPropagation();
                        onBookmarkToggle?.(questionIndex);
                      }}
                      className={isQuestionBookmarked(questionIndex) ? 'text-warning-600' : 'text-text-muted'}
                    />
                    <Icon 
                      name={expandedQuestions.has(questionIndex) ? "ChevronUp" : "ChevronDown"} 
                      size={16} 
                      className="text-text-muted"
                    />
                  </div>
                </div>
              </div>

              {/* Question Content */}
              {expandedQuestions.has(questionIndex) && (
                <div className="px-4 pb-4 border-t border-border">
                  <div className="pt-4">
                    {renderQuestion(question, questionIndex)}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Question Navigation */}
      <div className="p-4 border-t border-border bg-surface">
        <div className="flex items-center justify-between">
          <Button
            variant="outline"
            size="sm"
            iconName="ChevronLeft"
            onClick={() => onQuestionChange?.(Math.max(0, currentQuestion - 1))}
            disabled={currentQuestion === 0}
          >
            Previous
          </Button>
          
          <div className="flex items-center space-x-2">
            <span className="text-sm text-text-secondary">
              {currentQuestion + 1} of {questions.length}
            </span>
          </div>
          
          <Button
            variant="outline"
            size="sm"
            iconName="ChevronRight"
            iconPosition="right"
            onClick={() => onQuestionChange?.(Math.min(questions.length - 1, currentQuestion + 1))}
            disabled={currentQuestion === questions.length - 1}
          >
            Next
          </Button>
        </div>
      </div>
    </div>
  );
};

export default QuestionPanel;