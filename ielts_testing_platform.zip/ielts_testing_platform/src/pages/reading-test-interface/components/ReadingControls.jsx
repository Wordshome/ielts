import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ReadingControls = ({
  fontSize = 'medium',
  lineSpacing = 'normal',
  onFontSizeChange,
  onLineSpacingChange,
  onToggleHighlights,
  showHighlights = true,
  onResetHighlights,
  highlightCount = 0,
  onToggleBookmarks,
  showBookmarks = true,
  bookmarkCount = 0
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const fontSizeOptions = [
    { value: 'small', label: 'Small', icon: 'Type' },
    { value: 'medium', label: 'Medium', icon: 'Type' },
    { value: 'large', label: 'Large', icon: 'Type' },
    { value: 'xlarge', label: 'X-Large', icon: 'Type' }
  ];

  const lineSpacingOptions = [
    { value: 'tight', label: 'Tight', icon: 'AlignJustify' },
    { value: 'normal', label: 'Normal', icon: 'AlignJustify' },
    { value: 'relaxed', label: 'Relaxed', icon: 'AlignJustify' },
    { value: 'loose', label: 'Loose', icon: 'AlignJustify' }
  ];

  return (
    <div className="bg-background border border-border rounded-lg shadow-custom-sm">
      {/* Mobile Toggle */}
      <div className="md:hidden">
        <Button
          variant="ghost"
          size="sm"
          iconName={isExpanded ? "ChevronUp" : "Settings"}
          onClick={() => setIsExpanded(!isExpanded)}
          fullWidth
          className="justify-between p-3"
        >
          <span>Reading Controls</span>
        </Button>
        
        {isExpanded && (
          <div className="border-t border-border p-3 space-y-4">
            {/* Mobile Font Size */}
            <div>
              <label className="text-sm font-medium text-text-primary mb-2 block">
                Font Size
              </label>
              <div className="grid grid-cols-2 gap-2">
                {fontSizeOptions.map((option) => (
                  <Button
                    key={option.value}
                    variant={fontSize === option.value ? "primary" : "outline"}
                    size="sm"
                    iconName={option.icon}
                    onClick={() => onFontSizeChange?.(option.value)}
                    className="justify-start"
                  >
                    {option.label}
                  </Button>
                ))}
              </div>
            </div>

            {/* Mobile Line Spacing */}
            <div>
              <label className="text-sm font-medium text-text-primary mb-2 block">
                Line Spacing
              </label>
              <div className="grid grid-cols-2 gap-2">
                {lineSpacingOptions.map((option) => (
                  <Button
                    key={option.value}
                    variant={lineSpacing === option.value ? "primary" : "outline"}
                    size="sm"
                    iconName={option.icon}
                    onClick={() => onLineSpacingChange?.(option.value)}
                    className="justify-start"
                  >
                    {option.label}
                  </Button>
                ))}
              </div>
            </div>

            {/* Mobile Highlight Controls */}
            <div className="flex items-center justify-between pt-2 border-t border-border">
              <Button
                variant={showHighlights ? "primary" : "outline"}
                size="sm"
                iconName="Highlighter"
                onClick={onToggleHighlights}
              >
                Highlights ({highlightCount})
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                iconName="Trash2"
                onClick={onResetHighlights}
                disabled={highlightCount === 0}
                className="text-error-600 hover:text-error-700"
              />
            </div>

            {/* Mobile Bookmark Controls */}
            <div className="flex items-center justify-between">
              <Button
                variant={showBookmarks ? "primary" : "outline"}
                size="sm"
                iconName="Bookmark"
                onClick={onToggleBookmarks}
              >
                Bookmarks ({bookmarkCount})
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Desktop Controls */}
      <div className="hidden md:block p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-text-primary font-heading">
            Reading Controls
          </h3>
          <Icon name="Settings" size={16} className="text-text-muted" />
        </div>

        <div className="space-y-4">
          {/* Font Size Control */}
          <div>
            <label className="text-sm font-medium text-text-primary mb-2 block">
              Font Size
            </label>
            <div className="grid grid-cols-2 gap-2">
              {fontSizeOptions.map((option) => (
                <Button
                  key={option.value}
                  variant={fontSize === option.value ? "primary" : "outline"}
                  size="xs"
                  iconName={option.icon}
                  onClick={() => onFontSizeChange?.(option.value)}
                  className="justify-start text-xs"
                >
                  {option.label}
                </Button>
              ))}
            </div>
          </div>

          {/* Line Spacing Control */}
          <div>
            <label className="text-sm font-medium text-text-primary mb-2 block">
              Line Spacing
            </label>
            <div className="grid grid-cols-2 gap-2">
              {lineSpacingOptions.map((option) => (
                <Button
                  key={option.value}
                  variant={lineSpacing === option.value ? "primary" : "outline"}
                  size="xs"
                  iconName={option.icon}
                  onClick={() => onLineSpacingChange?.(option.value)}
                  className="justify-start text-xs"
                >
                  {option.label}
                </Button>
              ))}
            </div>
          </div>

          {/* Highlight Controls */}
          <div className="pt-2 border-t border-border">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-text-primary">Highlights</span>
              <span className="text-xs text-text-secondary">{highlightCount} active</span>
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant={showHighlights ? "primary" : "outline"}
                size="xs"
                iconName="Eye"
                onClick={onToggleHighlights}
                className="flex-1"
              >
                {showHighlights ? 'Hide' : 'Show'}
              </Button>
              <Button
                variant="ghost"
                size="xs"
                iconName="Trash2"
                onClick={onResetHighlights}
                disabled={highlightCount === 0}
                className="text-error-600 hover:text-error-700"
              />
            </div>
          </div>

          {/* Bookmark Controls */}
          <div className="pt-2 border-t border-border">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-text-primary">Bookmarks</span>
              <span className="text-xs text-text-secondary">{bookmarkCount} saved</span>
            </div>
            <Button
              variant={showBookmarks ? "primary" : "outline"}
              size="xs"
              iconName="Bookmark"
              onClick={onToggleBookmarks}
              fullWidth
            >
              {showBookmarks ? 'Hide Bookmarks' : 'Show Bookmarks'}
            </Button>
          </div>

          {/* Quick Actions */}
          <div className="pt-2 border-t border-border">
            <div className="grid grid-cols-2 gap-2">
              <Button
                variant="ghost"
                size="xs"
                iconName="RotateCcw"
                onClick={() => {
                  onFontSizeChange?.('medium');
                  onLineSpacingChange?.('normal');
                }}
                className="text-text-secondary"
              >
                Reset
              </Button>
              <Button
                variant="ghost"
                size="xs"
                iconName="HelpCircle"
                onClick={() => {}}
                className="text-text-secondary"
              >
                Help
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReadingControls;