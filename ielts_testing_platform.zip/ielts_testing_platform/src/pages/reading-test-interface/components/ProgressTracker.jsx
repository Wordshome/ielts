import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ProgressTracker = ({
  currentPassage = 1,
  totalPassages = 3,
  currentQuestion = 1,
  totalQuestions = 40,
  answeredQuestions = 0,
  bookmarkedQuestions = 0,
  timeRemaining = 3600,
  onPassageChange,
  onReviewMode,
  showReviewButton = true
}) => {
  const passages = Array.from({ length: totalPassages }, (_, index) => ({
    id: index + 1,
    title: `Passage ${index + 1}`,
    questionsStart: index * Math.ceil(totalQuestions / totalPassages) + 1,
    questionsEnd: Math.min((index + 1) * Math.ceil(totalQuestions / totalPassages), totalQuestions),
    isActive: index + 1 === currentPassage,
    isCompleted: false // This would be calculated based on answered questions
  }));

  const formatTime = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getTimeColor = () => {
    const percentage = (timeRemaining / 3600) * 100;
    if (percentage <= 10) return 'text-error-600';
    if (percentage <= 25) return 'text-warning-600';
    return 'text-success-600';
  };

  const getProgressPercentage = () => {
    return (answeredQuestions / totalQuestions) * 100;
  };

  const getProgressColor = () => {
    const percentage = getProgressPercentage();
    if (percentage >= 80) return 'bg-success-500';
    if (percentage >= 60) return 'bg-primary-500';
    if (percentage >= 40) return 'bg-accent-500';
    if (percentage >= 20) return 'bg-warning-500';
    return 'bg-error-500';
  };

  return (
    <div className="bg-background border border-border rounded-lg shadow-custom-sm">
      {/* Mobile Progress */}
      <div className="md:hidden p-3">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <Icon name="Clock" size={16} className={getTimeColor()} />
            <span className={`text-sm font-data font-semibold ${getTimeColor()}`}>
              {formatTime(timeRemaining)}
            </span>
          </div>
          <div className="text-sm text-text-secondary">
            {answeredQuestions}/{totalQuestions} answered
          </div>
        </div>
        
        {/* Mobile Progress Bar */}
        <div className="w-full bg-secondary-100 rounded-full h-2 mb-3">
          <div 
            className={`h-2 rounded-full transition-all duration-300 ${getProgressColor()}`}
            style={{ width: `${getProgressPercentage()}%` }}
          />
        </div>
        
        {/* Mobile Passage Navigation */}
        <div className="flex items-center space-x-1 mb-3">
          {passages.map((passage) => (
            <button
              key={passage.id}
              onClick={() => onPassageChange?.(passage.id)}
              className={`flex-1 py-2 px-3 text-xs rounded-md transition-all ${
                passage.isActive
                  ? 'bg-primary-500 text-white'
                  : passage.isCompleted
                  ? 'bg-success-100 text-success-700 border border-success-200' :'bg-surface text-text-secondary border border-border hover:border-primary-200'
              }`}
            >
              P{passage.id}
            </button>
          ))}
        </div>
        
        {showReviewButton && (
          <Button
            variant="outline"
            size="sm"
            iconName="Eye"
            onClick={onReviewMode}
            fullWidth
            className="text-xs"
          >
            Review Answers
          </Button>
        )}
      </div>

      {/* Desktop Progress */}
      <div className="hidden md:block p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-text-primary font-heading">
            Test Progress
          </h3>
          <div className={`text-lg font-data font-semibold ${getTimeColor()}`}>
            {formatTime(timeRemaining)}
          </div>
        </div>

        {/* Overall Progress */}
        <div className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-text-secondary">Overall Progress</span>
            <span className="text-sm font-medium text-text-primary">
              {Math.round(getProgressPercentage())}%
            </span>
          </div>
          <div className="w-full bg-secondary-100 rounded-full h-2">
            <div 
              className={`h-2 rounded-full transition-all duration-300 ${getProgressColor()}`}
              style={{ width: `${getProgressPercentage()}%` }}
            />
          </div>
        </div>

        {/* Statistics */}
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="text-center p-3 bg-surface rounded-lg">
            <div className="text-lg font-semibold text-text-primary">
              {answeredQuestions}
            </div>
            <div className="text-xs text-text-secondary">Answered</div>
          </div>
          <div className="text-center p-3 bg-surface rounded-lg">
            <div className="text-lg font-semibold text-warning-600">
              {bookmarkedQuestions}
            </div>
            <div className="text-xs text-text-secondary">Bookmarked</div>
          </div>
        </div>

        {/* Passage Navigation */}
        <div className="mb-4">
          <label className="text-sm font-medium text-text-primary mb-2 block">
            Passages
          </label>
          <div className="space-y-2">
            {passages.map((passage) => (
              <button
                key={passage.id}
                onClick={() => onPassageChange?.(passage.id)}
                className={`w-full p-3 rounded-lg border text-left transition-all hover:border-primary-200 ${
                  passage.isActive
                    ? 'border-primary bg-primary-50 text-primary-700'
                    : passage.isCompleted
                    ? 'border-success-200 bg-success-50 text-success-700' :'border-border bg-background text-text-primary'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm font-medium">{passage.title}</div>
                    <div className="text-xs text-text-secondary">
                      Questions {passage.questionsStart}-{passage.questionsEnd}
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    {passage.isCompleted && (
                      <Icon name="CheckCircle" size={16} className="text-success-600" />
                    )}
                    {passage.isActive && (
                      <Icon name="Play" size={16} className="text-primary-600" />
                    )}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Current Question Info */}
        <div className="mb-4 p-3 bg-surface rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-medium text-text-primary">
                Current Question
              </div>
              <div className="text-xs text-text-secondary">
                Question {currentQuestion} of {totalQuestions}
              </div>
            </div>
            <div className="text-right">
              <div className="text-sm font-medium text-text-primary">
                Passage {currentPassage}
              </div>
              <div className="text-xs text-text-secondary">
                {totalQuestions - answeredQuestions} remaining
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2">
          {showReviewButton && (
            <Button
              variant="outline"
              size="sm"
              iconName="Eye"
              onClick={onReviewMode}
              fullWidth
            >
              Review Answers
            </Button>
          )}
          
          <Button
            variant="ghost"
            size="sm"
            iconName="HelpCircle"
            onClick={() => {}}
            fullWidth
            className="text-text-secondary"
          >
            Instructions
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ProgressTracker;