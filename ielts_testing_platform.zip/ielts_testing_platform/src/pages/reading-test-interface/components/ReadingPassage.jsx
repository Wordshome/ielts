import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ReadingPassage = ({ 
  passage, 
  currentPassage, 
  onHighlight, 
  highlights = [],
  fontSize = 'medium',
  lineSpacing = 'normal'
}) => {
  const [selectedText, setSelectedText] = useState('');
  const [showHighlightMenu, setShowHighlightMenu] = useState(false);
  const [menuPosition, setMenuPosition] = useState({ x: 0, y: 0 });

  const fontSizeClasses = {
    small: 'text-sm',
    medium: 'text-base',
    large: 'text-lg',
    xlarge: 'text-xl'
  };

  const lineSpacingClasses = {
    tight: 'leading-tight',
    normal: 'leading-normal',
    relaxed: 'leading-relaxed',
    loose: 'leading-loose'
  };

  const handleTextSelection = () => {
    const selection = window.getSelection();
    const text = selection.toString().trim();
    
    if (text.length > 0) {
      const range = selection.getRangeAt(0);
      const rect = range.getBoundingClientRect();
      
      setSelectedText(text);
      setMenuPosition({
        x: rect.left + rect.width / 2,
        y: rect.top - 10
      });
      setShowHighlightMenu(true);
    } else {
      setShowHighlightMenu(false);
    }
  };

  const handleHighlight = (color) => {
    if (selectedText) {
      onHighlight?.({
        text: selectedText,
        color,
        passageId: currentPassage,
        timestamp: Date.now()
      });
      setShowHighlightMenu(false);
      window.getSelection().removeAllRanges();
    }
  };

  const highlightColors = [
    { name: 'Yellow', class: 'bg-yellow-200', value: 'yellow' },
    { name: 'Blue', class: 'bg-blue-200', value: 'blue' },
    { name: 'Green', class: 'bg-green-200', value: 'green' },
    { name: 'Pink', class: 'bg-pink-200', value: 'pink' }
  ];

  const renderHighlightedText = (text) => {
    let highlightedText = text;
    
    highlights.forEach((highlight, index) => {
      const colorClass = highlightColors.find(c => c.value === highlight.color)?.class || 'bg-yellow-200';
      highlightedText = highlightedText.replace(
        highlight.text,
        `<mark class="${colorClass} px-1 rounded" data-highlight="${index}">${highlight.text}</mark>`
      );
    });
    
    return highlightedText;
  };

  useEffect(() => {
    const handleClickOutside = () => {
      setShowHighlightMenu(false);
    };

    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  if (!passage) {
    return (
      <div className="flex items-center justify-center h-full bg-surface rounded-lg">
        <div className="text-center">
          <Icon name="FileText" size={48} className="text-text-muted mx-auto mb-4" />
          <p className="text-text-secondary">No passage selected</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full bg-background rounded-lg border border-border overflow-hidden">
      {/* Passage Header */}
      <div className="p-4 border-b border-border bg-surface">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-text-primary font-heading">
              {passage.title}
            </h2>
            <p className="text-sm text-text-secondary mt-1">
              Passage {currentPassage} • {passage.wordCount} words • Reading time: ~{Math.ceil(passage.wordCount / 200)} minutes
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              iconName="Bookmark"
              onClick={() => {}}
              className="text-text-secondary hover:text-primary"
            />
            <Button
              variant="ghost"
              size="sm"
              iconName="Share"
              onClick={() => {}}
              className="text-text-secondary hover:text-primary"
            />
          </div>
        </div>
      </div>

      {/* Passage Content */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-6">
          <div 
            className={`prose max-w-none ${fontSizeClasses[fontSize]} ${lineSpacingClasses[lineSpacing]} text-text-primary`}
            onMouseUp={handleTextSelection}
            dangerouslySetInnerHTML={{ 
              __html: renderHighlightedText(passage.content) 
            }}
          />
        </div>
      </div>

      {/* Highlight Menu */}
      {showHighlightMenu && (
        <div 
          className="fixed z-50 bg-background border border-border rounded-lg shadow-custom-lg p-2"
          style={{
            left: `${menuPosition.x}px`,
            top: `${menuPosition.y}px`,
            transform: 'translateX(-50%) translateY(-100%)'
          }}
        >
          <div className="flex items-center space-x-1">
            <span className="text-xs text-text-secondary px-2">Highlight:</span>
            {highlightColors.map((color) => (
              <button
                key={color.value}
                onClick={() => handleHighlight(color.value)}
                className={`w-6 h-6 rounded ${color.class} border border-border hover:scale-110 transition-transform focus-ring`}
                title={`Highlight in ${color.name}`}
              />
            ))}
            <Button
              variant="ghost"
              size="xs"
              iconName="X"
              onClick={() => setShowHighlightMenu(false)}
              className="ml-2"
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default ReadingPassage;