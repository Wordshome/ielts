import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ReviewModal = ({ 
  isOpen, 
  onClose, 
  questions = [], 
  answers = {},
  bookmarkedQuestions = [],
  onQuestionJump,
  onSubmitTest
}) => {
  const [activeTab, setActiveTab] = useState('all');
  const [showConfirmSubmit, setShowConfirmSubmit] = useState(false);

  if (!isOpen) return null;

  const getQuestionStatus = (questionIndex) => {
    const isAnswered = answers[questionIndex] !== undefined && answers[questionIndex] !== '';
    const isBookmarked = bookmarkedQuestions.includes(questionIndex);
    
    if (isAnswered && isBookmarked) return 'answered-bookmarked';
    if (isAnswered) return 'answered';
    if (isBookmarked) return 'bookmarked';
    return 'unanswered';
  };

  const getFilteredQuestions = () => {
    return questions.map((question, index) => ({
      ...question,
      index,
      status: getQuestionStatus(index)
    })).filter(question => {
      switch (activeTab) {
        case 'answered':
          return question.status.includes('answered');
        case 'unanswered':
          return question.status === 'unanswered';
        case 'bookmarked':
          return question.status.includes('bookmarked');
        default:
          return true;
      }
    });
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'answered-bookmarked':
        return <Icon name="CheckCircle" size={16} className="text-success-600" />;
      case 'answered':
        return <Icon name="CheckCircle" size={16} className="text-success-600" />;
      case 'bookmarked':
        return <Icon name="Bookmark" size={16} className="text-warning-600" />;
      default:
        return <Icon name="Circle" size={16} className="text-text-muted" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'answered-bookmarked':
        return 'border-success-200 bg-success-50';
      case 'answered':
        return 'border-success-200 bg-success-50';
      case 'bookmarked':
        return 'border-warning-200 bg-warning-50';
      default:
        return 'border-border bg-background';
    }
  };

  const answeredCount = questions.filter((_, index) => getQuestionStatus(index).includes('answered')).length;
  const unansweredCount = questions.length - answeredCount;
  const bookmarkedCount = bookmarkedQuestions.length;

  const tabs = [
    { id: 'all', label: 'All Questions', count: questions.length, icon: 'List' },
    { id: 'answered', label: 'Answered', count: answeredCount, icon: 'CheckCircle' },
    { id: 'unanswered', label: 'Unanswered', count: unansweredCount, icon: 'Circle' },
    { id: 'bookmarked', label: 'Bookmarked', count: bookmarkedCount, icon: 'Bookmark' }
  ];

  const handleQuestionClick = (questionIndex) => {
    onQuestionJump?.(questionIndex);
    onClose();
  };

  const handleSubmitClick = () => {
    if (unansweredCount > 0) {
      setShowConfirmSubmit(true);
    } else {
      onSubmitTest?.();
    }
  };

  const filteredQuestions = getFilteredQuestions();

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
        {/* Backdrop */}
        <div 
          className="fixed inset-0 transition-opacity bg-black bg-opacity-50"
          onClick={onClose}
        />

        {/* Modal */}
        <div className="inline-block w-full max-w-4xl my-8 overflow-hidden text-left align-middle transition-all transform bg-background shadow-custom-lg rounded-lg">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-border">
            <div>
              <h2 className="text-xl font-semibold text-text-primary font-heading">
                Review Your Answers
              </h2>
              <p className="text-sm text-text-secondary mt-1">
                {answeredCount} of {questions.length} questions answered
              </p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              iconName="X"
              onClick={onClose}
              className="text-text-muted hover:text-text-primary"
            />
          </div>

          {/* Tabs */}
          <div className="border-b border-border">
            <div className="flex overflow-x-auto">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                    activeTab === tab.id
                      ? 'border-primary text-primary bg-primary-50' :'border-transparent text-text-secondary hover:text-text-primary hover:border-secondary-300'
                  }`}
                >
                  <Icon name={tab.icon} size={16} />
                  <span>{tab.label}</span>
                  <span className={`px-2 py-1 text-xs rounded-full ${
                    activeTab === tab.id
                      ? 'bg-primary text-white' :'bg-secondary-100 text-secondary-700'
                  }`}>
                    {tab.count}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Content */}
          <div className="p-6 max-h-96 overflow-y-auto">
            {filteredQuestions.length === 0 ? (
              <div className="text-center py-8">
                <Icon name="Search" size={48} className="text-text-muted mx-auto mb-4" />
                <p className="text-text-secondary">No questions found for this filter</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredQuestions.map((question) => (
                  <div
                    key={question.index}
                    className={`p-4 rounded-lg border cursor-pointer transition-all hover:shadow-custom-sm ${getStatusColor(question.status)}`}
                    onClick={() => handleQuestionClick(question.index)}
                  >
                    <div className="flex items-start space-x-3">
                      {getStatusIcon(question.status)}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center space-x-2 mb-2">
                          <span className="text-sm font-medium text-primary">
                            Question {question.questionNumber || question.index + 1}
                          </span>
                          <span className="text-xs px-2 py-1 bg-secondary-100 text-secondary-700 rounded-full">
                            {question.type}
                          </span>
                        </div>
                        <p className="text-sm text-text-primary line-clamp-2 mb-2">
                          {question.question}
                        </p>
                        {answers[question.index] && (
                          <div className="text-xs text-text-secondary">
                            <span className="font-medium">Answer:</span> {answers[question.index]}
                          </div>
                        )}
                      </div>
                      <Icon name="ChevronRight" size={16} className="text-text-muted flex-shrink-0" />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="flex items-center justify-between p-6 border-t border-border bg-surface">
            <div className="text-sm text-text-secondary">
              {unansweredCount > 0 && (
                <span className="text-warning-600 font-medium">
                  {unansweredCount} questions still need answers
                </span>
              )}
            </div>
            <div className="flex items-center space-x-3">
              <Button
                variant="outline"
                size="sm"
                onClick={onClose}
              >
                Continue Test
              </Button>
              <Button
                variant="primary"
                size="sm"
                iconName="Send"
                onClick={handleSubmitClick}
              >
                Submit Test
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Confirm Submit Modal */}
      {showConfirmSubmit && (
        <div className="fixed inset-0 z-60 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity bg-black bg-opacity-50" />
            
            <div className="inline-block w-full max-w-md my-8 overflow-hidden text-left align-middle transition-all transform bg-background shadow-custom-lg rounded-lg">
              <div className="p-6">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-10 h-10 bg-warning-100 rounded-full flex items-center justify-center">
                    <Icon name="AlertTriangle" size={20} className="text-warning-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-text-primary font-heading">
                      Submit Test?
                    </h3>
                    <p className="text-sm text-text-secondary">
                      You have {unansweredCount} unanswered questions
                    </p>
                  </div>
                </div>
                
                <p className="text-sm text-text-secondary mb-6">
                  Are you sure you want to submit your test? You won't be able to make changes after submission.
                </p>
                
                <div className="flex items-center justify-end space-x-3">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowConfirmSubmit(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    variant="primary"
                    size="sm"
                    onClick={() => {
                      setShowConfirmSubmit(false);
                      onSubmitTest?.();
                    }}
                  >
                    Submit Anyway
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ReviewModal;