import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import AdaptiveHeader from '../../components/ui/AdaptiveHeader';
import TestProgressBar from '../../components/ui/TestProgressBar';
import TestTimer from '../../components/ui/TestTimer';
import NavigationBreadcrumb from '../../components/ui/NavigationBreadcrumb';
import ReadingPassage from './components/ReadingPassage';
import QuestionPanel from './components/QuestionPanel';
import ReadingControls from './components/ReadingControls';
import ProgressTracker from './components/ProgressTracker';
import ReviewModal from './components/ReviewModal';

import Button from '../../components/ui/Button';

const ReadingTestInterface = () => {
  const navigate = useNavigate();
  
  // Test state
  const [currentPassage, setCurrentPassage] = useState(0);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState({});
  const [bookmarkedQuestions, setBookmarkedQuestions] = useState([]);
  const [highlights, setHighlights] = useState([]);
  const [timeRemaining, setTimeRemaining] = useState(3600); // 60 minutes
  const [isTestStarted, setIsTestStarted] = useState(true);
  const [showReviewModal, setShowReviewModal] = useState(false);
  
  // UI state
  const [fontSize, setFontSize] = useState('medium');
  const [lineSpacing, setLineSpacing] = useState('normal');
  const [showHighlights, setShowHighlights] = useState(true);
  const [showBookmarks, setShowBookmarks] = useState(true);
  const [isMobileView, setIsMobileView] = useState(false);
  const [showSidebar, setShowSidebar] = useState(true);

  // Mock data
  const passages = [
    {
      id: 1,
      title: "The Evolution of Urban Transportation",
      wordCount: 850,
      content: `The transformation of urban transportation systems has been one of the most significant developments in modern city planning. From the horse-drawn carriages of the 19th century to the electric vehicles and autonomous systems of today, cities have continuously adapted their transportation infrastructure to meet the growing demands of urban populations.\n\nThe Industrial Revolution marked a pivotal moment in transportation history. Steam-powered trains and trams revolutionized how people moved within cities, enabling the development of suburbs and the expansion of urban boundaries. This period saw the birth of public transportation systems that would become the backbone of modern cities.\n\nIn the 20th century, the automobile transformed urban landscapes dramatically. Cities redesigned their infrastructure to accommodate cars, leading to the construction of highways, parking facilities, and suburban developments. However, this car-centric approach also brought challenges including traffic congestion, air pollution, and social inequality in transportation access.\n\nToday, cities are embracing sustainable transportation solutions. Electric buses, bike-sharing programs, and pedestrian-friendly infrastructure are becoming standard features of modern urban planning. Smart traffic management systems use real-time data to optimize traffic flow and reduce emissions.\n\nThe future of urban transportation lies in integrated, multimodal systems that combine various forms of transport seamlessly. Autonomous vehicles, hyperloop technology, and advanced public transit systems promise to create more efficient, sustainable, and accessible urban mobility solutions.`
    },
    {
      id: 2,
      title: "Climate Change and Arctic Wildlife",
      wordCount: 920,
      content: `The Arctic region, often described as the Earth's refrigerator, is experiencing unprecedented changes due to global climate change. These transformations are having profound effects on the wildlife that has adapted to this harsh but stable environment over thousands of years.\n\nPolar bears, perhaps the most iconic Arctic species, face significant challenges as sea ice diminishes. These magnificent predators depend on sea ice platforms to hunt seals, their primary food source. As ice-free periods extend longer each year, polar bears must travel greater distances to find food, leading to decreased body condition and reduced reproductive success.\n\nThe Arctic fox, another species uniquely adapted to polar conditions, is experiencing habitat shifts and increased competition. As temperatures rise, red foxes are expanding their range northward, competing with Arctic foxes for territory and resources. The Arctic fox's white winter coat, once perfect camouflage against snow, becomes a disadvantage as snow-free periods lengthen.\n\nMarine ecosystems are equally affected. Walruses, which traditionally rest on sea ice between feeding sessions, are forced to crowd onto land-based haul-outs. This behavioral change leads to increased stress, trampling of young, and reduced access to feeding areas.\n\nSeabirds such as guillemots and puffins face challenges as changing ocean temperatures affect fish populations. The timing of fish availability no longer aligns with breeding seasons, resulting in reduced chick survival rates.\n\nConservation efforts are focusing on protecting critical habitats, establishing marine protected areas, and reducing human disturbances. International cooperation is essential as Arctic wildlife populations cross national boundaries and require coordinated conservation strategies.`
    },
    {
      id: 3,
      title: "The Digital Revolution in Education",
      wordCount: 780,
      content: `The integration of digital technology in education has fundamentally transformed how students learn and teachers instruct. This digital revolution has accelerated dramatically in recent years, reshaping educational practices and creating new opportunities for personalized learning.\n\nOnline learning platforms have democratized access to education, allowing students from remote areas to access high-quality courses and resources. Massive Open Online Courses (MOOCs) have made university-level education available to millions worldwide, breaking down traditional barriers to higher education.\n\nArtificial intelligence and machine learning are personalizing the learning experience. Adaptive learning systems analyze student performance in real-time, adjusting content difficulty and pacing to match individual learning needs. This personalized approach helps students learn more effectively and efficiently.\n\nVirtual and augmented reality technologies are creating immersive learning experiences. Students can explore ancient civilizations, conduct virtual science experiments, or practice surgical procedures in safe, controlled environments. These technologies make abstract concepts tangible and engaging.\n\nHowever, the digital divide remains a significant challenge. Not all students have equal access to technology and high-speed internet, creating disparities in educational opportunities. Schools and governments are working to address these inequalities through device lending programs and infrastructure improvements.\n\nThe COVID-19 pandemic accelerated digital adoption in education, forcing institutions to rapidly implement remote learning solutions. This experience highlighted both the potential and limitations of digital education, leading to hybrid models that combine online and in-person instruction.\n\nAs we move forward, the focus is on developing digital literacy skills and ensuring that technology enhances rather than replaces human interaction in education.`
    }
  ];

  const questions = [
    // Passage 1 Questions (1-13)
    {
      questionNumber: 1,
      type: 'multiple-choice',
      question: 'According to the passage, what marked a pivotal moment in transportation history?',
      instruction: 'Choose the correct answer from the options below.',
      options: [
        { value: 'A', label: 'A', text: 'The invention of the automobile' },
        { value: 'B', label: 'B', text: 'The Industrial Revolution' },
        { value: 'C', label: 'C', text: 'The development of electric vehicles' },
        { value: 'D', label: 'D', text: 'The construction of highways' }
      ],
      passageId: 1
    },
    {
      questionNumber: 2,
      type: 'true-false-not-given',
      question: 'Steam-powered trains enabled the development of suburbs.',
      instruction: 'Choose TRUE if the statement agrees with the information, FALSE if it contradicts, or NOT GIVEN if there is no information.',
      passageId: 1
    },
    {
      questionNumber: 3,
      type: 'multiple-choice',
      question: 'What challenges did the car-centric approach bring to cities?',
      instruction: 'Choose the correct answer.',
      options: [
        { value: 'A', label: 'A', text: 'Only traffic congestion' },
        { value: 'B', label: 'B', text: 'Traffic congestion, air pollution, and social inequality' },
        { value: 'C', label: 'C', text: 'Only air pollution' },
        { value: 'D', label: 'D', text: 'Increased public transportation usage' }
      ],
      passageId: 1
    },
    {
      questionNumber: 4,
      type: 'short-answer',
      question: 'What type of systems use real-time data to optimize traffic flow?',
      instruction: 'Write your answer in NO MORE THAN THREE WORDS.',
      maxLength: 50,
      passageId: 1
    },
    {
      questionNumber: 5,
      type: 'matching-headings',
      question: 'Choose the most suitable heading for the final paragraph.',
      instruction: 'Select the heading that best summarizes the content.',
      headings: [
        'The Problems of Modern Transportation',
        'Historical Transportation Methods',
        'Future Integrated Transportation Systems',
        'Environmental Impact of Vehicles',
        'Public vs Private Transportation'
      ],
      passageId: 1
    },
    
    // Passage 2 Questions (6-18)
    {
      questionNumber: 6,
      type: 'multiple-choice',
      question: 'Why are polar bears facing significant challenges?',
      instruction: 'Choose the correct answer.',
      options: [
        { value: 'A', label: 'A', text: 'Due to hunting pressure' },
        { value: 'B', label: 'B', text: 'Because of diminishing sea ice' },
        { value: 'C', label: 'C', text: 'Due to food scarcity in general' },
        { value: 'D', label: 'D', text: 'Because of habitat destruction' }
      ],
      passageId: 2
    },
    {
      questionNumber: 7,
      type: 'true-false-not-given',
      question: 'Red foxes are moving northward due to climate change.',
      instruction: 'Choose TRUE, FALSE, or NOT GIVEN.',
      passageId: 2
    },
    {
      questionNumber: 8,
      type: 'short-answer',
      question: 'What is the primary food source of polar bears?',
      instruction: 'Write your answer in NO MORE THAN ONE WORD.',
      maxLength: 20,
      passageId: 2
    },
    {
      questionNumber: 9,
      type: 'multiple-choice',
      question: 'What problem do walruses face due to reduced sea ice?',
      instruction: 'Choose the correct answer.',
      options: [
        { value: 'A', label: 'A', text: 'They cannot find food' },
        { value: 'B', label: 'B', text: 'They are forced to crowd onto land-based areas' },
        { value: 'C', label: 'C', text: 'They cannot reproduce' },
        { value: 'D', label: 'D', text: 'They are hunted more frequently' }
      ],
      passageId: 2
    },
    {
      questionNumber: 10,
      type: 'true-false-not-given',
      question: 'Arctic foxes are better adapted to warmer temperatures than red foxes.',
      instruction: 'Choose TRUE, FALSE, or NOT GIVEN.',
      passageId: 2
    },
    
    // Passage 3 Questions (11-20)
    {
      questionNumber: 11,
      type: 'multiple-choice',
      question: 'What has democratized access to education according to the passage?',
      instruction: 'Choose the correct answer.',
      options: [
        { value: 'A', label: 'A', text: 'Traditional classrooms' },
        { value: 'B', label: 'B', text: 'Online learning platforms' },
        { value: 'C', label: 'C', text: 'Government funding' },
        { value: 'D', label: 'D', text: 'Private tutoring' }
      ],
      passageId: 3
    },
    {
      questionNumber: 12,
      type: 'short-answer',
      question: 'What do adaptive learning systems analyze to personalize education?',
      instruction: 'Write your answer in NO MORE THAN TWO WORDS.',
      maxLength: 30,
      passageId: 3
    },
    {
      questionNumber: 13,
      type: 'true-false-not-given',
      question: 'All students have equal access to technology and high-speed internet.',
      instruction: 'Choose TRUE, FALSE, or NOT GIVEN.',
      passageId: 3
    }
  ];

  // Auto-save functionality
  useEffect(() => {
    const saveInterval = setInterval(() => {
      localStorage.setItem('reading-test-answers', JSON.stringify(answers));
      localStorage.setItem('reading-test-bookmarks', JSON.stringify(bookmarkedQuestions));
      localStorage.setItem('reading-test-highlights', JSON.stringify(highlights));
    }, 30000); // Save every 30 seconds

    return () => clearInterval(saveInterval);
  }, [answers, bookmarkedQuestions, highlights]);

  // Load saved data on mount
  useEffect(() => {
    const savedAnswers = localStorage.getItem('reading-test-answers');
    const savedBookmarks = localStorage.getItem('reading-test-bookmarks');
    const savedHighlights = localStorage.getItem('reading-test-highlights');

    if (savedAnswers) setAnswers(JSON.parse(savedAnswers));
    if (savedBookmarks) setBookmarkedQuestions(JSON.parse(savedBookmarks));
    if (savedHighlights) setHighlights(JSON.parse(savedHighlights));
  }, []);

  // Responsive handling
  useEffect(() => {
    const handleResize = () => {
      setIsMobileView(window.innerWidth < 1024);
      if (window.innerWidth >= 1024) {
        setShowSidebar(true);
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Timer handlers
  const handleTimeUp = useCallback(() => {
    alert('Time is up! Your test will be submitted automatically.');
    handleSubmitTest();
  }, []);

  const handleTimeWarning = useCallback((timeLeft) => {
    if (timeLeft === 300) {
      alert('5 minutes remaining!');
    } else if (timeLeft === 60) {
      alert('1 minute remaining!');
    }
  }, []);

  // Answer handling
  const handleAnswerChange = (questionIndex, answer) => {
    setAnswers(prev => ({
      ...prev,
      [questionIndex]: answer
    }));
  };

  // Question navigation
  const handleQuestionChange = (questionIndex) => {
    setCurrentQuestion(questionIndex);
    
    // Auto-switch passage if needed
    const question = questions[questionIndex];
    if (question && question.passageId) {
      const passageIndex = passages.findIndex(p => p.id === question.passageId);
      if (passageIndex !== -1 && passageIndex !== currentPassage) {
        setCurrentPassage(passageIndex);
      }
    }
  };

  // Passage navigation
  const handlePassageChange = (passageIndex) => {
    setCurrentPassage(passageIndex);
    
    // Find first question for this passage
    const firstQuestionIndex = questions.findIndex(q => q.passageId === passages[passageIndex].id);
    if (firstQuestionIndex !== -1) {
      setCurrentQuestion(firstQuestionIndex);
    }
  };

  // Bookmark handling
  const handleBookmarkToggle = (questionIndex) => {
    setBookmarkedQuestions(prev => {
      if (prev.includes(questionIndex)) {
        return prev.filter(q => q !== questionIndex);
      } else {
        return [...prev, questionIndex];
      }
    });
  };

  // Highlight handling
  const handleHighlight = (highlight) => {
    setHighlights(prev => [...prev, highlight]);
  };

  const handleResetHighlights = () => {
    setHighlights([]);
  };

  // Test submission
  const handleSubmitTest = () => {
    localStorage.removeItem('reading-test-answers');
    localStorage.removeItem('reading-test-bookmarks');
    localStorage.removeItem('reading-test-highlights');
    navigate('/test-results-dashboard');
  };

  // Get current passage questions
  const getCurrentPassageQuestions = () => {
    return questions.filter(q => q.passageId === passages[currentPassage]?.id);
  };

  const currentPassageQuestions = getCurrentPassageQuestions();
  const answeredCount = Object.keys(answers).length;
  const totalQuestions = questions.length;

  return (
    <div className="min-h-screen bg-surface">
      <AdaptiveHeader />
      
      <TestProgressBar 
        currentSection={1}
        totalSections={4}
        sectionProgress={(answeredCount / totalQuestions) * 100}
        timeRemaining={timeRemaining}
        totalTime={3600}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <NavigationBreadcrumb />

        {/* Test Header */}
        <div className="mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-text-primary font-heading">
                IELTS Reading Test
              </h1>
              <p className="text-text-secondary mt-1">
                Section 1: Academic Reading • 60 minutes • 40 questions
              </p>
            </div>
            
            <div className="flex items-center space-x-3">
              {isMobileView && (
                <Button
                  variant="outline"
                  size="sm"
                  iconName="Menu"
                  onClick={() => setShowSidebar(!showSidebar)}
                  className="lg:hidden"
                />
              )}
              
              <Button
                variant="primary"
                size="sm"
                iconName="Eye"
                onClick={() => setShowReviewModal(true)}
              >
                Review
              </Button>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar - Controls & Progress */}
          {(!isMobileView || showSidebar) && (
            <div className={`lg:col-span-1 space-y-6 ${isMobileView ? 'fixed inset-0 z-40 bg-surface p-4 overflow-y-auto' : ''}`}>
              {isMobileView && (
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-semibold text-text-primary">Test Controls</h2>
                  <Button
                    variant="ghost"
                    size="sm"
                    iconName="X"
                    onClick={() => setShowSidebar(false)}
                  />
                </div>
              )}
              
              <TestTimer
                initialTime={3600}
                onTimeUp={handleTimeUp}
                onTimeWarning={handleTimeWarning}
                warningThreshold={300}
                criticalThreshold={60}
                sectionName="Reading Test"
              />
              
              <ProgressTracker
                currentPassage={currentPassage + 1}
                totalPassages={passages.length}
                currentQuestion={currentQuestion + 1}
                totalQuestions={totalQuestions}
                answeredQuestions={answeredCount}
                bookmarkedQuestions={bookmarkedQuestions.length}
                timeRemaining={timeRemaining}
                onPassageChange={(passageNum) => handlePassageChange(passageNum - 1)}
                onReviewMode={() => setShowReviewModal(true)}
              />
              
              <ReadingControls
                fontSize={fontSize}
                lineSpacing={lineSpacing}
                onFontSizeChange={setFontSize}
                onLineSpacingChange={setLineSpacing}
                onToggleHighlights={() => setShowHighlights(!showHighlights)}
                showHighlights={showHighlights}
                onResetHighlights={handleResetHighlights}
                highlightCount={highlights.length}
                onToggleBookmarks={() => setShowBookmarks(!showBookmarks)}
                showBookmarks={showBookmarks}
                bookmarkCount={bookmarkedQuestions.length}
              />
            </div>
          )}

          {/* Main Content Area */}
          <div className="lg:col-span-3">
            {/* Mobile Layout */}
            <div className="lg:hidden space-y-6">
              <ReadingPassage
                passage={passages[currentPassage]}
                currentPassage={currentPassage + 1}
                onHighlight={handleHighlight}
                highlights={showHighlights ? highlights : []}
                fontSize={fontSize}
                lineSpacing={lineSpacing}
              />
              
              <QuestionPanel
                questions={currentPassageQuestions}
                currentQuestion={currentQuestion}
                answers={answers}
                onAnswerChange={handleAnswerChange}
                onQuestionChange={handleQuestionChange}
                bookmarkedQuestions={bookmarkedQuestions}
                onBookmarkToggle={handleBookmarkToggle}
              />
            </div>

            {/* Desktop Layout */}
            <div className="hidden lg:grid lg:grid-cols-2 lg:gap-6 lg:h-[calc(100vh-300px)]">
              <ReadingPassage
                passage={passages[currentPassage]}
                currentPassage={currentPassage + 1}
                onHighlight={handleHighlight}
                highlights={showHighlights ? highlights : []}
                fontSize={fontSize}
                lineSpacing={lineSpacing}
              />
              
              <QuestionPanel
                questions={currentPassageQuestions}
                currentQuestion={currentQuestion}
                answers={answers}
                onAnswerChange={handleAnswerChange}
                onQuestionChange={handleQuestionChange}
                bookmarkedQuestions={bookmarkedQuestions}
                onBookmarkToggle={handleBookmarkToggle}
              />
            </div>
          </div>
        </div>

        {/* Bottom Actions */}
        <div className="mt-8 flex items-center justify-between p-4 bg-background border border-border rounded-lg">
          <div className="text-sm text-text-secondary">
            Auto-saved • {answeredCount} of {totalQuestions} questions completed
          </div>
          
          <div className="flex items-center space-x-3">
            <Button
              variant="outline"
              size="sm"
              iconName="Save"
              onClick={() => {
                localStorage.setItem('reading-test-answers', JSON.stringify(answers));
                alert('Progress saved successfully!');
              }}
            >
              Save Progress
            </Button>
            
            <Button
              variant="primary"
              size="sm"
              iconName="Send"
              onClick={() => setShowReviewModal(true)}
            >
              Finish Section
            </Button>
          </div>
        </div>
      </div>

      {/* Review Modal */}
      <ReviewModal
        isOpen={showReviewModal}
        onClose={() => setShowReviewModal(false)}
        questions={questions}
        answers={answers}
        bookmarkedQuestions={bookmarkedQuestions}
        onQuestionJump={handleQuestionChange}
        onSubmitTest={handleSubmitTest}
      />
    </div>
  );
};

export default ReadingTestInterface;