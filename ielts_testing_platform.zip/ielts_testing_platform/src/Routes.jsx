import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
// Add your imports here
import ListeningTestInterface from "pages/listening-test-interface";
import WritingTestInterface from "pages/writing-test-interface";
import SpeakingTestInterface from "pages/speaking-test-interface";
import TestResultsDashboard from "pages/test-results-dashboard";
import ReadingTestInterface from "pages/reading-test-interface";
import UserProfileSettings from "pages/user-profile-settings";
import NotFound from "pages/NotFound";

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Define your routes here */}
        <Route path="/" element={<TestResultsDashboard />} />
        <Route path="/listening-test-interface" element={<ListeningTestInterface />} />
        <Route path="/writing-test-interface" element={<WritingTestInterface />} />
        <Route path="/speaking-test-interface" element={<SpeakingTestInterface />} />
        <Route path="/test-results-dashboard" element={<TestResultsDashboard />} />
        <Route path="/reading-test-interface" element={<ReadingTestInterface />} />
        <Route path="/user-profile-settings" element={<UserProfileSettings />} />
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;